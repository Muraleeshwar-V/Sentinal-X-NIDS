"""
Sentinel-X: Detection Pipeline Coordinator
Integrates Preprocessing -> Flow Classifier -> Baseline Anomaly Detector
-> False-Positive Filter -> Threat Scoring -> Explainability -> Database Storage.
Executes batch and real-time network flow inspection.
"""

import json
import logging
from typing import Any
import numpy as np

from app.model_manager import model_manager
from app.preprocessing import records_to_feature_matrix, record_to_feature_vector, FEATURE_COLUMNS
from app.anomaly import calculate_anomaly_score
from app.scoring import evaluate_threat
from app.explanation import explain_detection
from app.fp_filter import fp_filter, apply_verdict_to_score
from app.database import db_manager
from app.config import THREAT_SCORE_THRESHOLD

logger = logging.getLogger("sentinel_x.detection")


class DetectionEngine:
    """Core Intrusion Detection Engine."""

    def __init__(self):
        if not model_manager.are_models_loaded():
            model_manager.load_models()

    def analyze_flow(self, flow_record: dict, persist: bool = True) -> dict[str, Any]:
        """
        Analyze a single flow record through the complete detection pipeline.
        """
        results = self.analyze_flows([flow_record], persist=persist)
        return results[0] if results else {}

    def analyze_flows(self, flow_records: list[dict], persist: bool = True) -> list[dict[str, Any]]:
        """
        Analyze a batch of network flow records.
        """
        if not flow_records:
            return []

        if not model_manager.are_models_loaded():
            model_manager.load_models()

        # 1. Preprocessing into structured feature matrix
        feature_df = records_to_feature_matrix(flow_records)

        # 2. Multi-class flow classification
        if model_manager.classifier:
            predictions = model_manager.classifier.predict(feature_df)
            probas = model_manager.classifier.predict_proba(feature_df)
            classes = list(model_manager.classifier.classes_)
        else:
            predictions = ["Normal"] * len(flow_records)
            probas = np.ones((len(flow_records), 1))
            classes = ["Normal"]

        # 3. Baseline-deviation anomaly scoring
        _, anomaly_scores = calculate_anomaly_score(feature_df)

        detection_results = []

        for i, flow in enumerate(flow_records):
            attack_type = str(predictions[i])
            class_idx = classes.index(attack_type) if attack_type in classes else 0
            confidence = float(probas[i][class_idx])
            anomaly_score = float(anomaly_scores[i])

            # 4. Threat Scoring & Severity
            threat_score, severity = evaluate_threat(
                attack_type=attack_type,
                confidence=confidence,
                anomaly_score=anomaly_score
            )

            # 5. False-Positive Filter
            feature_row = feature_df[i].astype(float, copy=False)
            fp_verdict, fp_score, fp_details = fp_filter.evaluate(
                attack_type=attack_type,
                confidence=confidence,
                anomaly_score=anomaly_score,
                rf_probas=probas[i],
                feature_row=feature_row,
                flow_record=flow,
            )

            # Adjust score and severity based on verdict
            threat_score, severity, is_alert_fp = apply_verdict_to_score(
                fp_verdict, threat_score, severity
            )

            # 6. Explanation Generation
            explanation, top_features = explain_detection(
                flow_record=flow,
                attack_type=attack_type,
                threat_score=threat_score,
                severity=severity
            )

            # 7. Final alert decision
            # For Normal-classified traffic use original threshold logic;
            # for attack-classified traffic honour the FP filter verdict.
            if attack_type == "Normal":
                is_alert = threat_score >= THREAT_SCORE_THRESHOLD
            else:
                is_alert = is_alert_fp

            # 8. Database Storage
            traffic_id = None
            alert_id = None

            if persist:
                try:
                    traffic_id = db_manager.insert_traffic_record(flow)
                except Exception as e:
                    logger.error(f"Failed to persist traffic record: {e}")

                if is_alert:
                    try:
                        alert_dict = {
                            "traffic_id": traffic_id,
                            "attack_type": attack_type,
                            "threat_score": threat_score,
                            "severity": severity,
                            "confidence": confidence,
                            "anomaly_score": anomaly_score,
                            "status": "NEW",
                            "explanation": explanation,
                            "top_features_json": top_features,
                            "src_ip": flow.get("src_ip", "0.0.0.0"),
                            "dst_ip": flow.get("dst_ip", "0.0.0.0"),
                            "dst_port": int(flow.get("dst_port", 0) or 0),
                            "protocol": flow.get("protocol", "TCP"),
                            "fp_verdict": fp_verdict,
                            "fp_score": round(fp_score, 4),
                        }
                        alert_id = db_manager.insert_alert(alert_dict)
                    except Exception as e:
                        logger.error(f"Failed to persist alert: {e}")

            result = {
                "traffic_id":    traffic_id,
                "alert_id":      alert_id,
                "is_alert":      is_alert,
                "attack_type":   attack_type,
                "confidence":    round(confidence, 4),
                "anomaly_score": round(anomaly_score, 4),
                "threat_score":  threat_score,
                "severity":      severity,
                "fp_verdict":    fp_verdict,
                "fp_score":      round(fp_score, 4),
                "explanation":   explanation,
                "top_features":  top_features,
                "flow":          flow,
            }
            detection_results.append(result)

        return detection_results


# Global singleton instance
detection_engine = DetectionEngine()
