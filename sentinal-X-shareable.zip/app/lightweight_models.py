"""NumPy-only inference models used when native ML extensions are unavailable."""

from __future__ import annotations

import numpy as np

from app.preprocessing import FEATURE_COLUMNS
from app.training import predict_softmax


class LightweightClassifier:
    """Interpretable flow classifier for the project's five traffic classes."""

    classes_ = np.array(["BruteForce", "DDoS", "Malware/C2", "Normal", "PortScan"])

    def __init__(self, trained_model: dict | None = None):
        self.trained_model = trained_model
        if trained_model and trained_model.get("classes"):
            self.classes_ = np.asarray(trained_model["classes"], dtype=str)

    def _scores(self, rows: np.ndarray) -> np.ndarray:
        x = np.atleast_2d(np.asarray(rows, dtype=float))
        idx = {name: i for i, name in enumerate(FEATURE_COLUMNS)}
        packet_count = x[:, idx["packet_count"]]
        packet_rate = x[:, idx["packet_rate"]]
        duration = x[:, idx["flow_duration"]]
        avg_size = x[:, idx["avg_packet_size"]]
        dst_port = x[:, idx["dst_port"]]
        ack = x[:, idx["flag_ack"]]
        fin = x[:, idx["flag_fin"]] >= 0.5
        rst = x[:, idx["flag_rst"]] >= 0.5

        scores = np.full((len(x), len(self.classes_)), 0.02, dtype=float)
        # Scores combine multiple independent flow indicators so a single
        # unusual field does not determine the predicted class.
        scores[:, 1] += (
            (packet_count >= 300) * 0.34
            + (packet_rate >= 200) * 0.30
            + (avg_size <= 400) * 0.22
            + (duration <= 1.2) * 0.14
        )
        scores[:, 4] += (
            (packet_count <= 10) * 0.32
            + (avg_size < 64) * 0.27
            + (duration <= 0.5) * 0.22
            + (ack < 0.5) * 0.19
            - (avg_size >= 64) * 0.30
        )
        auth_port = np.isin(dst_port, [21, 22, 445, 3389])
        scores[:, 0] += (
            auth_port * 0.30
            + ((packet_count >= 15) & (packet_count <= 100)) * 0.24
            + ((duration >= 0.5) & (duration <= 6)) * 0.20
            + (ack >= 0.5) * 0.26
            + (avg_size <= 400) * 0.18
            - (avg_size > 400) * 0.30
            - (fin & ~rst) * 0.25
        )
        scores[:, 2] += (
            (duration >= 10) * 0.36
            + (packet_rate <= 5) * 0.30
            + (packet_count <= 30) * 0.18
            + (~np.isin(dst_port, [21, 22, 53, 80, 123, 443, 445, 3389, 8080, 8443])) * 0.16
        )
        # Normal is the default, with evidence from ordinary ports, packet
        # sizes, and non-extreme rates increasing its relative probability.
        common_port = np.isin(dst_port, [21, 22, 53, 80, 123, 443, 445, 3389, 8080, 8443])
        scores[:, 3] += (
            common_port * 0.32
            + ((avg_size >= 64) & (avg_size <= 1500)) * 0.28
            + (packet_rate < 200) * 0.24
            + (packet_count < 300) * 0.16
            + (fin & ~rst) * 0.30
        )
        return scores

    def predict_proba(self, rows: np.ndarray) -> np.ndarray:
        if self.trained_model:
            _, probabilities = predict_softmax(self.trained_model, rows)
            return probabilities
        scores = self._scores(rows)
        # Smooth class evidence into a normalized probability distribution.
        logits = scores * 5.0
        logits -= logits.max(axis=1, keepdims=True)
        exp = np.exp(logits)
        return exp / exp.sum(axis=1, keepdims=True)

    def predict(self, rows: np.ndarray) -> np.ndarray:
        probs = self.predict_proba(rows)
        return self.classes_[np.argmax(probs, axis=1)]


class LightweightAnomalyDetector:
    """Baseline z-distance scorer exposing IsolationForest's inference API."""

    def __init__(self, baseline_stats: dict[str, dict]):
        self.medians = np.array(
            [float(baseline_stats.get(name, {}).get("median", 0.0)) for name in FEATURE_COLUMNS],
            dtype=float,
        )
        self.scales = np.array(
            [max(abs(float(baseline_stats.get(name, {}).get("std", 1.0))), 1e-6) for name in FEATURE_COLUMNS],
            dtype=float,
        )

    def decision_function(self, rows: np.ndarray) -> np.ndarray:
        x = np.atleast_2d(np.asarray(rows, dtype=float))
        z = np.abs((x - self.medians) / self.scales)
        # Positive values indicate baseline-like flows; large deviations
        # become negative, matching IsolationForest's documented direction.
        return 0.15 - np.maximum(0.0, np.max(z, axis=1) - 2.0) * 0.10
