"""
Sentinel-X: Threat Scoring & Severity Classification Module
Computes unified 0–100 risk score combining classifier confidence and baseline anomaly severity.
Maps scores to strict severity thresholds:
- 0–29: LOW
- 30–59: MEDIUM
- 60–79: HIGH
- 80–100: CRITICAL
"""

from typing import Literal

SeverityLevel = Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]


def calculate_threat_score(
    attack_type: str,
    confidence: float,
    anomaly_score: float
) -> int:
    """
    Calculate 0–100 risk score based on classifier confidence and anomaly score.

    Formula rationale:
    - If attack_type == 'Normal':
        Threat score reflects anomalous behavior score primarily (capped at 55 if confidence is high normal).
        If anomaly score is extreme (> 0.8), can reach up to 65 (HIGH anomaly alert).
    - If attack_type in ('DDoS', 'PortScan', 'BruteForce', 'Malware/C2'):
        Confidence weight = 60%, Anomaly score weight = 40%, with base attack penalty.
        DDoS: base 25, weight high volume attacks.
        PortScan / BruteForce / Malware: base 20.
    """
    conf = max(0.0, min(1.0, float(confidence)))
    anom = max(0.0, min(1.0, float(anomaly_score)))

    if attack_type == "Normal":
        # Normal traffic has low baseline threat score
        # Elevated only if anomaly detector flags strong outlier behavior
        score = int(anom * 45.0 + (1.0 - conf) * 15.0)
        return max(0, min(59, score))

    # Known attack categories
    attack_weights = {
        "DDoS": 25,
        "Malware/C2": 30,
        "BruteForce": 20,
        "PortScan": 18,
    }
    base_penalty = attack_weights.get(attack_type, 15)

    # Combined formula: Base penalty + (conf * 50) + (anom * 35)
    raw_score = base_penalty + (conf * 50.0) + (anom * 35.0)
    score = int(round(raw_score))

    return max(0, min(100, score))


def determine_severity(threat_score: int) -> SeverityLevel:
    """
    Assign severity category based on strict numerical bounds:
    0–29   : LOW
    30–59  : MEDIUM
    60–79  : HIGH
    80–100 : CRITICAL
    """
    score = max(0, min(100, int(threat_score)))
    if score >= 80:
        return "CRITICAL"
    elif score >= 60:
        return "HIGH"
    elif score >= 30:
        return "MEDIUM"
    else:
        return "LOW"


def evaluate_threat(
    attack_type: str,
    confidence: float,
    anomaly_score: float
) -> tuple[int, SeverityLevel]:
    """Calculate both threat score and severity level."""
    score = calculate_threat_score(attack_type, confidence, anomaly_score)
    severity = determine_severity(score)
    return score, severity
