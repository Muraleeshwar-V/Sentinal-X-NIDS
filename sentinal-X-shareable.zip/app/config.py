"""
Sentinel-X: Configuration Management Module
Loads configuration from .env using python-dotenv.
All path resolutions are strictly cross-platform using pathlib.Path.
Zero hardcoded OS-specific paths.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Resolve project directories dynamically relative to this file
APP_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = APP_DIR.parent

# Load environment variables from .env file if present
ENV_PATH = PROJECT_ROOT / ".env"
if ENV_PATH.exists():
    load_dotenv(dotenv_path=ENV_PATH)
else:
    load_dotenv()

# Database Settings
DATABASE_HOST = os.getenv("DATABASE_HOST", "localhost")
DATABASE_PORT = int(os.getenv("DATABASE_PORT", "3306"))
DATABASE_NAME = os.getenv("DATABASE_NAME", "sentinel_x")
DATABASE_USER = os.getenv("DATABASE_USER", "sentinel_user")
DATABASE_PASSWORD = os.getenv("DATABASE_PASSWORD", "sentinel_password")

# API Server Settings
API_HOST = os.getenv("API_HOST", "127.0.0.1")
API_PORT = int(os.getenv("API_PORT", "8000"))

# Directory Paths
_model_dir_env = os.getenv("MODEL_DIRECTORY", "").strip()
MODEL_DIR = Path(_model_dir_env).resolve() if _model_dir_env else (PROJECT_ROOT / "models")
MODEL_DIR.mkdir(parents=True, exist_ok=True)

_data_dir_env = os.getenv("DATA_DIRECTORY", "").strip()
DATA_DIR = Path(_data_dir_env).resolve() if _data_dir_env else (PROJECT_ROOT / "data")
DATA_DIR.mkdir(parents=True, exist_ok=True)

UPLOADS_DIR = DATA_DIR / "uploads"
PROCESSED_DIR = DATA_DIR / "processed"
CAPTURES_DIR = DATA_DIR / "captures"
for d in (UPLOADS_DIR, PROCESSED_DIR, CAPTURES_DIR):
    d.mkdir(parents=True, exist_ok=True)

_sqlite_path_env = os.getenv("DATABASE_SQLITE_PATH", "").strip()
if _sqlite_path_env:
    _sqlite_path = Path(_sqlite_path_env)
    DATABASE_SQLITE_PATH = _sqlite_path.resolve() if _sqlite_path.is_absolute() else (PROJECT_ROOT / _sqlite_path).resolve()
else:
    DATABASE_SQLITE_PATH = DATA_DIR / "sentinel_x.sqlite3"

_log_dir_env = os.getenv("LOG_DIRECTORY", "").strip()
LOG_DIR = Path(_log_dir_env).resolve() if _log_dir_env else (PROJECT_ROOT / "logs")
LOG_DIR.mkdir(parents=True, exist_ok=True)

TEMPLATES_DIR = APP_DIR / "templates"
STATIC_DIR = APP_DIR / "static"

# Model & Detection Hyperparameters
ANOMALY_CONTAMINATION = float(os.getenv("ANOMALY_CONTAMINATION", "0.05"))
THREAT_SCORE_THRESHOLD = int(os.getenv("THREAT_SCORE_THRESHOLD", "60"))

# Active Model Paths
CLASSIFIER_MODEL_PATH = MODEL_DIR / "random_forest_classifier.joblib"
ANOMALY_MODEL_PATH = MODEL_DIR / "isolation_forest_anomaly.joblib"
PREPROCESSOR_METADATA_PATH = MODEL_DIR / "preprocessor_meta.joblib"
