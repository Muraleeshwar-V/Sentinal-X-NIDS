"""
Sentinel-X: Explainability & Alert Attribution Engine
Derives human-understandable alert explanations and top contributing features
using active classifier feature weights coupled with feature distribution divergence.
Strictly zero external XAI frameworks (no SHAP or LIME required).
"""

from typing import Any
from app.model_manager import model_manager
from app.preprocessing import FEATURE_COLUMNS


def get_top_contributing_features(
    flow_record: dict,
    attack_type: str,
    top_k: int = 5
) -> list[dict[str, Any]]:
    """
    Calculate feature attribution scores by weighting the classifier feature importance
    with the feature's relative deviation from the normal traffic baseline.
    """
    importances = model_manager.get_feature_importances()
    baseline = model_manager.get_baseline_stats()

    contributions = []

    for feat in FEATURE_COLUMNS:
        global_imp = importances.get(feat, 0.0)
        curr_val = float(flow_record.get(feat, 0.0) or 0.0)
        base_stat = baseline.get(feat, {})
        base_median = float(base_stat.get("median", 0.0))
        base_std = float(base_stat.get("std", 1.0)) or 1.0

        # Z-score / standardized deviation from normal baseline
        deviation = abs(curr_val - base_median) / base_std

        # Combined attribution score = global importance * min(deviation, 10.0)
        impact = global_imp * (1.0 + min(deviation, 10.0))

        contributions.append({
            "feature": feat,
            "global_importance": round(global_imp, 4),
            "current_value": round(curr_val, 2),
            "baseline_median": round(base_median, 2),
            "deviation": round(deviation, 2),
            "impact_score": round(impact, 4),
        })

    # Sort descending by impact score
    contributions.sort(key=lambda x: x["impact_score"], reverse=True)
    return contributions[:top_k]


def generate_explanation_text(
    attack_type: str,
    threat_score: int,
    severity: str,
    top_features: list[dict],
    src_ip: str,
    dst_ip: str,
    dst_port: int,
    protocol: str
) -> str:
    """
    Construct clear, professional security analyst explanation summarizing the detection.
    """
    top_names = [f"{f['feature']} ({f['current_value']})" for f in top_features[:3]]
    drivers_str = ", ".join(top_names)

    if attack_type == "DDoS":
        text = (
            f"High-volume Denial of Service pattern identified from {src_ip} targeting {dst_ip}:{dst_port} ({protocol}). "
            f"Threat score assessed at {threat_score}/100 ({severity}). "
            f"Key driving indicators: {drivers_str} displaying abnormal flood characteristics."
        )
    elif attack_type == "PortScan":
        text = (
            f"Reconnaissance port scanning activity detected originating from {src_ip} towards {dst_ip}:{dst_port}. "
            f"Threat score assessed at {threat_score}/100 ({severity}). "
            f"Key driving indicators: {drivers_str} displaying rapid sequential probing behavior."
        )
    elif attack_type == "BruteForce":
        text = (
            f"Credential brute-force attack signature observed against {dst_ip}:{dst_port} from {src_ip}. "
            f"Threat score assessed at {threat_score}/100 ({severity}). "
            f"Key driving indicators: {drivers_str} indicating repeated interactive connection cycles."
        )
    elif attack_type == "Malware/C2":
        text = (
            f"Suspicious command-and-control (C2) beaconing detected between {src_ip} and {dst_ip}:{dst_port}. "
            f"Threat score assessed at {threat_score}/100 ({severity}). "
            f"Key driving indicators: {drivers_str} showing persistent low-throughput interval communication."
        )
    elif attack_type == "Normal":
        text = (
            f"Traffic between {src_ip} and {dst_ip}:{dst_port} conforms to normal operational profiles. "
            f"Threat score: {threat_score}/100 ({severity}). No hostile patterns detected."
        )
    else:
        text = (
            f"Anomalous network activity detected from {src_ip} targeting {dst_ip}:{dst_port}. "
            f"Threat score: {threat_score}/100 ({severity}). "
            f"Top contributing features: {drivers_str}."
        )

    return text


def explain_detection(
    flow_record: dict,
    attack_type: str,
    threat_score: int,
    severity: str
) -> tuple[str, list[dict]]:
    """Derive full explanation package: narrative text and top features breakdown."""
    top_feats = get_top_contributing_features(flow_record, attack_type, top_k=5)
    text = generate_explanation_text(
        attack_type=attack_type,
        threat_score=threat_score,
        severity=severity,
        top_features=top_feats,
        src_ip=flow_record.get("src_ip", "0.0.0.0"),
        dst_ip=flow_record.get("dst_ip", "0.0.0.0"),
        dst_port=int(flow_record.get("dst_port", 0) or 0),
        protocol=flow_record.get("protocol", "TCP")
    )
    return text, top_feats
