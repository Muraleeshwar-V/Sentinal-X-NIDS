"""
Sentinel-X: Data & Feature Drift Monitoring Engine
Computes distribution shift and statistical distance between current traffic batches
and the baseline training distribution using pure NumPy and Pandas.
Zero external drift frameworks.
"""

import logging
from datetime import datetime, timezone
from typing import Any
import numpy as np

from app.model_manager import model_manager
from app.preprocessing import records_to_feature_matrix, FEATURE_COLUMNS
from app.database import db_manager

logger = logging.getLogger("sentinel_x.drift")


def compute_population_stability_index(expected: np.ndarray, actual: np.ndarray, num_bins: int = 5) -> float:
    """
    Calculate Population Stability Index (PSI) between baseline (expected) and current (actual).
    PSI < 0.10: No significant change / Stable.
    0.10 <= PSI < 0.25: Moderate drift.
    PSI >= 0.25: Significant population drift.
    """
    if len(expected) == 0 or len(actual) == 0:
        return 0.0

    # Define quantile bin boundaries on expected baseline
    quantiles = np.linspace(0, 100, num_bins + 1)
    bin_edges = np.percentile(expected, quantiles)
    bin_edges = np.unique(bin_edges)
    if len(bin_edges) < 2:
        # Uniform feature values, calculate relative mean difference
        exp_mean = float(np.mean(expected))
        act_mean = float(np.mean(actual))
        return min(1.0, abs(act_mean - exp_mean) / max(abs(exp_mean), 1.0))

    # Add small epsilon to boundaries
    bin_edges[0] -= 1e-5
    bin_edges[-1] += 1e-5

    # Compute frequency proportions
    exp_counts, _ = np.histogram(expected, bins=bin_edges)
    act_counts, _ = np.histogram(actual, bins=bin_edges)

    exp_pct = exp_counts / max(np.sum(exp_counts), 1)
    act_pct = act_counts / max(np.sum(act_counts), 1)

    # Avoid zero division
    eps = 1e-4
    exp_pct = np.clip(exp_pct, eps, 1.0)
    act_pct = np.clip(act_pct, eps, 1.0)

    psi = np.sum((act_pct - exp_pct) * np.log(act_pct / exp_pct))
    return float(np.clip(psi, 0.0, 2.0))


def calculate_feature_drift(flow_records: list[dict], persist: bool = True) -> dict[str, Any]:
    """
    Analyze incoming flow records for statistical drift against the baseline model distribution.
    Records drift events in database and returns diagnostic report.
    """
    if not flow_records:
        return {"status": "NO_TRAFFIC", "drift_events": [], "max_drift_score": 0.0}

    baseline = model_manager.get_baseline_stats()
    feature_matrix = records_to_feature_matrix(flow_records)

    drift_events = []
    max_score = 0.0

    for index, feat in enumerate(FEATURE_COLUMNS):
        curr_vals = feature_matrix[:, index].astype(float, copy=False)
        curr_mean = float(np.mean(curr_vals))
        curr_median = float(np.median(curr_vals))

        base_stat = baseline.get(feat, {})
        base_median = float(base_stat.get("median", 0.0))
        base_std = float(base_stat.get("std", 1.0)) or 1.0

        # Calculate normalized distribution deviation
        # Using normalized median shift & z-score
        std_shift = abs(curr_median - base_median) / base_std
        drift_score = min(1.0, round(float(std_shift / 3.0), 4))

        if drift_score >= 0.25:
            status = "SIGNIFICANT_DRIFT"
        elif drift_score >= 0.10:
            status = "MODERATE_DRIFT"
        else:
            status = "NO_DRIFT"

        max_score = max(max_score, drift_score)

        event = {
            "feature_name": feat,
            "baseline_value": round(base_median, 2),
            "current_value": round(curr_median, 2),
            "drift_score": drift_score,
            "status": status,
            "created_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        }
        drift_events.append(event)

        if persist and status in ("MODERATE_DRIFT", "SIGNIFICANT_DRIFT"):
            try:
                db_manager.insert_drift_event(event)
            except Exception as e:
                logger.error(f"Error persisting drift event: {e}")

    overall_status = "STABLE"
    if max_score >= 0.25:
        overall_status = "SIGNIFICANT_DRIFT"
    elif max_score >= 0.10:
        overall_status = "MODERATE_DRIFT"

    return {
        "overall_status": overall_status,
        "max_drift_score": round(max_score, 4),
        "features_evaluated": len(FEATURE_COLUMNS),
        "drift_events": drift_events,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
