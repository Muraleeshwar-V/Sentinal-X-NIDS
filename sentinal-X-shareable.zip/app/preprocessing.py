"""
Sentinel-X: Traffic Preprocessing & Feature Engineering Module
Transforms raw flow records into numerical feature matrices for classification
and baseline anomaly detection.
Handles missing values, column mapping, and protocol/flag encoding.
"""

import numpy as np
from typing import Any

# Standard feature column order used across training and inference
FEATURE_COLUMNS = [
    "dst_port",
    "protocol_num",
    "packet_count",
    "byte_count",
    "flow_duration",
    "packet_rate",
    "byte_rate",
    "avg_packet_size",
    "flag_syn",
    "flag_ack",
    "flag_fin",
    "flag_rst",
]

# Protocol mapping to integer codes
PROTOCOL_MAP = {
    "TCP": 6,
    "UDP": 17,
    "ICMP": 1,
    "6": 6,
    "17": 17,
    "1": 1,
}


def encode_protocol(proto: Any) -> int:
    """Safely map protocol string or number to standard integer."""
    if proto is None:
        return 6
    p_str = str(proto).strip().upper()
    if p_str in PROTOCOL_MAP:
        return PROTOCOL_MAP[p_str]
    try:
        numeric_value = float(p_str)
        if not np.isfinite(numeric_value) or not numeric_value.is_integer():
            return 0
        numeric_protocol = str(int(numeric_value))
        return PROTOCOL_MAP.get(numeric_protocol, 0)
    except (TypeError, ValueError, OverflowError):
        return 0


def parse_tcp_flags(flags_val: Any) -> tuple[int, int, int, int]:
    """
    Parse TCP flags from string or integer mask into binary indicators:
    (SYN, ACK, FIN, RST).
    """
    syn, ack, fin, rst = 0, 0, 0, 0
    if flags_val is None:
        return syn, ack, fin, rst

    if isinstance(flags_val, (int, float)):
        if not np.isfinite(flags_val):
            return syn, ack, fin, rst
        val = int(flags_val)
        fin = 1 if (val & 0x01) else 0
        syn = 1 if (val & 0x02) else 0
        rst = 1 if (val & 0x04) else 0
        ack = 1 if (val & 0x10) else 0
        return syn, ack, fin, rst

    f_str = str(flags_val).strip().upper()
    # Some exporters provide the TCP bit mask as text, while others provide
    # compact Scapy values ("SA") or names ("SYN,ACK"). Parse those forms
    # explicitly instead of substring matching arbitrary labels.
    try:
        if f_str.isdigit():
            return parse_tcp_flags(int(f_str))
    except (TypeError, ValueError):
        pass

    tokens = {
        token for token in f_str.replace("|", ",").replace("/", ",").replace(" ", ",").split(",") if token
    }
    compact_value = next(iter(tokens)) if len(tokens) == 1 else ""
    compact = bool(compact_value) and compact_value not in {"SYN", "ACK", "FIN", "RST"}
    if compact and set(compact_value) <= set("SAFRPUCE"):
        tokens = set(compact_value)
    elif compact:
        tokens = set()
    syn = int(bool(tokens & {"S", "SYN"}))
    ack = int(bool(tokens & {"A", "ACK"}))
    fin = int(bool(tokens & {"F", "FIN"}))
    rst = int(bool(tokens & {"R", "RST"}))

    return syn, ack, fin, rst


def record_to_feature_vector(record: dict) -> np.ndarray:
    """
    Convert a single standardized flow dictionary into a 1D float numpy feature vector.
    """
    def safe_number(value: Any, default: float = 0.0) -> float:
        try:
            number = float(value)
            return max(0.0, number) if np.isfinite(number) else default
        except (TypeError, ValueError, OverflowError):
            return default

    dst_port = safe_number(record.get("dst_port", 0))
    proto_num = float(encode_protocol(record.get("protocol", "TCP")))
    packet_count = max(safe_number(record.get("packet_count", 1), 1), 1.0)
    byte_count = safe_number(record.get("byte_count", 0))
    flow_duration = safe_number(record.get("flow_duration", 0.0))

    # Derived rates if missing or zero
    packet_rate = safe_number(record.get("packet_rate"))
    if packet_rate <= 0.0:
        dur = max(flow_duration, 0.001)
        packet_rate = packet_count / dur

    byte_rate = safe_number(record.get("byte_rate"))
    if byte_rate <= 0.0:
        dur = max(flow_duration, 0.001)
        byte_rate = byte_count / dur

    avg_pkt_size = safe_number(record.get("avg_packet_size"))
    if avg_pkt_size <= 0.0:
        avg_pkt_size = byte_count / max(packet_count, 1.0)

    syn, ack, fin, rst = parse_tcp_flags(record.get("tcp_flags", ""))

    vec = [
        dst_port,
        proto_num,
        packet_count,
        byte_count,
        flow_duration,
        packet_rate,
        byte_rate,
        avg_pkt_size,
        float(syn),
        float(ack),
        float(fin),
        float(rst),
    ]
    return np.array(vec, dtype=np.float32)


def records_to_feature_matrix(records: list[dict]) -> np.ndarray:
    """
    Convert standardized flow dictionaries into a numeric feature matrix.
    """
    rows = [record_to_feature_vector(r) for r in records]
    if not rows:
        return np.empty((0, len(FEATURE_COLUMNS)), dtype=np.float32)
    return np.stack(rows).astype(np.float32, copy=False)
