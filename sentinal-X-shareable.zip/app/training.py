"""Small supervised trainer for labeled network-flow datasets (NumPy only)."""

from __future__ import annotations

from typing import Any

import numpy as np

from app.preprocessing import FEATURE_COLUMNS

LOG_FEATURES = (0, 2, 3, 4, 5, 6, 7)


def transform_training_features(rows: np.ndarray) -> np.ndarray:
    """Reduce heavy-tailed flow counters before standardization."""
    values = np.asarray(rows, dtype=np.float64).copy()
    if values.ndim != 2 or values.shape[1] != len(FEATURE_COLUMNS):
        raise ValueError(f"Expected a 2D matrix with {len(FEATURE_COLUMNS)} features")
    values[:, LOG_FEATURES] = np.log1p(np.maximum(values[:, LOG_FEATURES], 0.0))
    return values


def train_softmax_classifier(
    rows: np.ndarray,
    labels: list[str] | np.ndarray,
    *,
    epochs: int = 500,
    learning_rate: float = 0.3,
    regularization: float = 0.002,
) -> dict[str, Any]:
    """Fit a regularized multiclass linear model and return portable parameters."""
    x = transform_training_features(rows)
    y = np.asarray(labels, dtype=str)
    if len(x) != len(y) or len(y) < 10:
        raise ValueError("Training rows and labels must match and contain at least 10 samples")
    classes, encoded = np.unique(y, return_inverse=True)
    if len(classes) < 2:
        raise ValueError("Training data must contain at least two traffic classes")

    means = x.mean(axis=0)
    scales = x.std(axis=0)
    scales[scales < 1e-8] = 1.0
    x = np.clip((x - means) / scales, -8.0, 8.0)

    counts = np.bincount(encoded, minlength=len(classes)).astype(float)
    class_weights = len(y) / (len(classes) * counts)
    sample_weights = class_weights[encoded]
    sample_weights /= sample_weights.mean()
    targets = np.eye(len(classes), dtype=np.float64)[encoded]
    weights = np.zeros((x.shape[1], len(classes)), dtype=np.float64)
    bias = np.log(counts / counts.sum())

    # Backtracking makes training stable across very different labeled data sets.
    step = learning_rate
    previous_loss = float("inf")
    for epoch in range(epochs):
        logits = np.clip(x @ weights + bias, -40.0, 40.0)
        logits -= logits.max(axis=1, keepdims=True)
        exp_logits = np.exp(logits)
        probs = exp_logits / exp_logits.sum(axis=1, keepdims=True)
        loss = -np.sum(sample_weights * np.log(np.maximum(probs[np.arange(len(y)), encoded], 1e-12))) / len(y)
        loss += 0.5 * regularization * float(np.sum(weights * weights))
        if loss > previous_loss + 1e-9:
            step *= 0.5
        previous_loss = loss
        residual = (probs - targets) * sample_weights[:, None]
        grad_w = (x.T @ residual) / len(y) + regularization * weights
        grad_b = residual.mean(axis=0)
        weights -= step * grad_w
        bias -= step * grad_b

    return {
        "classes": classes.tolist(),
        "weights": weights.tolist(),
        "bias": bias.tolist(),
        "means": means.tolist(),
        "scales": scales.tolist(),
        "log_features": list(LOG_FEATURES),
        "epochs": epochs,
        "training_samples": int(len(y)),
    }


def predict_softmax(model: dict[str, Any], rows: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Return class predictions and probability estimates for a fitted model."""
    x = transform_training_features(rows)
    means = np.asarray(model["means"], dtype=float)
    scales = np.asarray(model["scales"], dtype=float)
    x = np.clip((x - means) / scales, -8.0, 8.0)
    logits = x @ np.asarray(model["weights"], dtype=float) + np.asarray(model["bias"], dtype=float)
    logits = np.clip(logits, -40.0, 40.0)
    logits -= logits.max(axis=1, keepdims=True)
    exp_logits = np.exp(logits)
    probs = exp_logits / exp_logits.sum(axis=1, keepdims=True)
    classes = np.asarray(model["classes"], dtype=str)
    return classes[np.argmax(probs, axis=1)], probs


def evaluate_predictions(actual: np.ndarray, predicted: np.ndarray, classes: list[str]) -> dict[str, Any]:
    """Produce accuracy, balanced accuracy, and per-class precision/recall/F1."""
    actual = np.asarray(actual, dtype=str)
    predicted = np.asarray(predicted, dtype=str)
    per_class = {}
    recalls = []
    for label in classes:
        tp = int(np.sum((actual == label) & (predicted == label)))
        fp = int(np.sum((actual != label) & (predicted == label)))
        fn = int(np.sum((actual == label) & (predicted != label)))
        support = int(np.sum(actual == label))
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        per_class[label] = {
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1": round(f1, 4),
            "support": support,
        }
        if support:
            recalls.append(recall)
    return {
        "accuracy": round(float(np.mean(actual == predicted)), 4),
        "balanced_accuracy": round(float(np.mean(recalls)) if recalls else 0.0, 4),
        "samples": int(len(actual)),
        "per_class": per_class,
    }
