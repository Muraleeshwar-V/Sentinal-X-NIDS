"""
Sentinel-X: Traffic Ingestion & Flow Processing Module
Processes network traffic from CSV files, PCAP files, and optional live sniffing.
Produces a unified cross-platform internal flow representation.
"""

import csv
import io
import logging
import math
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger("sentinel_x.traffic")

# Common column mapping aliases for network flow CSV datasets (normalized format)
COLUMN_ALIASES = {
    # Source IP
    "src_ip": ["src_ip", "source_ip", "srcip", "sourceip", "id_orig_h", "source_address", "ip_src", "source"],
    # Destination IP
    "dst_ip": ["dst_ip", "dest_ip", "destination_ip", "dstip", "destinationip", "id_resp_h", "dest_address", "ip_dst", "destination"],
    # Source Port
    "src_port": ["src_port", "source_port", "srcport", "sourceport", "id_orig_p", "sport", "s_port"],
    # Destination Port
    "dst_port": ["dst_port", "dest_port", "destination_port", "dstport", "destinationport", "id_resp_p", "dport", "d_port"],
    # Protocol
    "protocol": ["protocol", "proto", "proto_name", "transport_protocol"],
    # Packet Count
    "packet_count": ["packet_count", "tot_fwd_pkts", "total_fwd_packets", "total_packets", "packets", "pkt_count", "tot_pkts"],
    # Byte Count
    "byte_count": ["byte_count", "totlen_fwd_pkts", "total_length_of_fwd_packets", "total_bytes", "bytes", "tot_bytes", "flow_bytes"],
    # Flow Duration
    "flow_duration": ["flow_duration", "duration", "flow_duration_sec", "flow_dur"],
    # Packet Rate
    "packet_rate": ["packet_rate", "flow_pkts_s", "flow_packets_s", "flow_packets_per_sec", "packet_rate_s"],
    # Byte Rate
    "byte_rate": ["byte_rate", "flow_byts_s", "flow_bytes_s", "flow_bytes_per_sec", "byte_rate_s"],
    # TCP Flags
    "tcp_flags": ["tcp_flags", "flags", "flag", "tcp_flag"],
    # Average Packet Size
    "avg_packet_size": ["avg_packet_size", "average_packet_size", "pkt_size_avg", "mean_packet_size", "packet_length_mean", "fwd_packet_length_mean"],
    # Optional supervised-training label
    "label": ["label", "attack_type", "class", "target", "category"],
}


def normalize_column_name(col: str) -> str:
    """Normalize arbitrary header string for fuzzy matching."""
    return col.strip().lower().replace(" ", "_").replace(".", "_").replace("-", "_").replace("/", "_")


def _finite_float(value: Any, default: float = 0.0) -> float:
    """Convert CSV cells to finite numbers, treating blank/NaN/inf as missing."""
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (ValueError, TypeError):
        return default


def map_dataframe_columns(columns: list[str]) -> dict[str, str]:
    """Map external CSV headers to standard Sentinel-X field names."""
    normalized_cols = {col: normalize_column_name(col) for col in columns}
    rename_dict = {}
    used_standards = set()

    # Pass 1: Exact alias matches
    for original_col, norm in normalized_cols.items():
        for standard_name, aliases in COLUMN_ALIASES.items():
            if standard_name in used_standards:
                continue
            if norm in aliases:
                rename_dict[original_col] = standard_name
                used_standards.add(standard_name)
                break

    # Pass 2: Substring matches for remaining unmapped columns
    for original_col, norm in normalized_cols.items():
        if original_col in rename_dict:
            continue
        for standard_name, aliases in COLUMN_ALIASES.items():
            if standard_name in used_standards:
                continue
            # TCP flag counters are separate features, not a serialized flag
            # mask; derive their combined value later in the CSV row parser.
            if standard_name == "tcp_flags":
                continue
            if any(alias in norm for alias in aliases):
                rename_dict[original_col] = standard_name
                used_standards.add(standard_name)
                break

    return rename_dict


def parse_csv_data(filepath_or_buffer: str | Path | io.StringIO | bytes) -> list[dict]:
    """
    Parse CSV flow dataset from file path or in-memory buffer.
    Returns a list of standardized flow dictionaries.
    """
    if isinstance(filepath_or_buffer, bytes):
        csv_source = io.StringIO(filepath_or_buffer.decode("utf-8-sig"))
    elif isinstance(filepath_or_buffer, Path):
        csv_source = io.StringIO(filepath_or_buffer.read_text(encoding="utf-8-sig"))
    elif isinstance(filepath_or_buffer, str):
        csv_source = io.StringIO(Path(filepath_or_buffer).read_text(encoding="utf-8-sig"))
    else:
        csv_source = filepath_or_buffer

    reader = csv.DictReader(csv_source, skipinitialspace=True)
    if not reader.fieldnames:
        return []
    column_map = map_dataframe_columns(reader.fieldnames)
    normalized_headers = {normalize_column_name(name) for name in reader.fieldnames}
    # CIC-IDS datasets store Flow Duration in microseconds. Their flow-rate
    # fields identify the unit convention without guessing for generic CSVs.
    duration_is_microseconds = "flow_duration" in normalized_headers and bool(
        normalized_headers & {"flow_byts_s", "flow_pkts_s", "tot_fwd_pkts", "total_fwd_packets"}
    )
    records: list[dict] = []

    for raw_row in reader:
        row = {column_map.get(key, key): value for key, value in raw_row.items() if key is not None}
        src_ip = str(row.get("src_ip", "0.0.0.0") or "0.0.0.0").strip()
        dst_ip = str(row.get("dst_ip", "0.0.0.0") or "0.0.0.0").strip()

        src_port = int(_finite_float(row.get("src_port", 0)))
        dst_port = int(_finite_float(row.get("dst_port", 0)))

        protocol = str(row.get("protocol", "TCP") or "TCP").strip().upper()

        packet_count = max(1, int(_finite_float(row.get("packet_count", 1), 1)))
        byte_count = max(0, int(_finite_float(row.get("byte_count", 0))))
        flow_duration = max(0.0, _finite_float(row.get("flow_duration", 0)))
        if duration_is_microseconds:
            flow_duration /= 1_000_000.0

        packet_rate = _finite_float(row.get("packet_rate", 0))
        if packet_rate <= 0.0:
            packet_rate = round(packet_count / max(flow_duration, 0.001), 2)

        byte_rate = _finite_float(row.get("byte_rate", 0))
        if byte_rate <= 0.0:
            byte_rate = round(byte_count / max(flow_duration, 0.001), 2)

        avg_packet_size = _finite_float(row.get("avg_packet_size", 0))
        if avg_packet_size <= 0.0:
            avg_packet_size = round(byte_count / max(packet_count, 1), 2)

        tcp_flags = str(row.get("tcp_flags", "") or "").strip()
        if not tcp_flags:
            raw_headers = {normalize_column_name(key): value for key, value in raw_row.items() if key is not None}
            flag_names = {
                "SYN": {"syn_flag_count", "syn_flag", "syn_count"},
                "ACK": {"ack_flag_count", "ack_flag", "ack_count"},
                "FIN": {"fin_flag_count", "fin_flag", "fin_count"},
                "RST": {"rst_flag_count", "rst_flag", "rst_count"},
            }
            tcp_flags = ",".join(
                flag for flag, names in flag_names.items()
                if any(_finite_float(raw_headers.get(name, 0)) > 0 for name in names)
            )

        rec = {
            "src_ip": src_ip,
            "dst_ip": dst_ip,
            "src_port": src_port,
            "dst_port": dst_port,
            "protocol": protocol,
            "packet_count": packet_count,
            "byte_count": byte_count,
            "flow_duration": flow_duration,
            "packet_rate": packet_rate,
            "byte_rate": byte_rate,
            "tcp_flags": tcp_flags,
            "avg_packet_size": avg_packet_size,
            "source_type": "CSV",
        }
        if row.get("label") not in (None, ""):
            rec["label"] = str(row["label"]).strip()
        records.append(rec)

    return records


# -----------------------------------------------------------------
# PCAP PROCESSING (SCAPY-BASED, PURE PYTHON, CROSS-PLATFORM)
# -----------------------------------------------------------------

def parse_pcap_data(filepath_or_bytes: str | Path | bytes | io.BytesIO) -> list[dict]:
    """
    Parse a PCAP or PCAPNG file and reconstruct network flows using 5-tuples.
    Uses Scapy directly without relying on tcpdump, tshark, or Wireshark.
    Works identically on Windows, Linux, and macOS.
    """
    from scapy.utils import rdpcap, PcapReader
    from scapy.layers.inet import IP, TCP, UDP, ICMP
    from scapy.layers.inet6 import IPv6

    if isinstance(filepath_or_bytes, bytes):
        pcap_source = io.BytesIO(filepath_or_bytes)
    elif isinstance(filepath_or_bytes, (str, Path)):
        pcap_source = str(filepath_or_bytes)
    else:
        pcap_source = filepath_or_bytes

    try:
        packets = rdpcap(pcap_source)
    except Exception as e:
        logger.error(f"Error reading PCAP file with Scapy: {e}")
        return []

    # Map flows by (src_ip, dst_ip, src_port, dst_port, protocol)
    flows: dict[tuple, dict] = {}

    for pkt in packets:
        if not pkt.haslayer(IP) and not pkt.haslayer(IPv6):
            continue

        ip_layer = pkt.getlayer(IP) if pkt.haslayer(IP) else pkt.getlayer(IPv6)
        src_ip = str(ip_layer.src)
        dst_ip = str(ip_layer.dst)

        protocol = "OTHER"
        src_port = 0
        dst_port = 0
        tcp_flags = []

        if pkt.haslayer(TCP):
            protocol = "TCP"
            tcp = pkt.getlayer(TCP)
            src_port = int(tcp.sport)
            dst_port = int(tcp.dport)
            flags_str = str(tcp.flags)
            if "S" in flags_str:
                tcp_flags.append("SYN")
            if "A" in flags_str:
                tcp_flags.append("ACK")
            if "F" in flags_str:
                tcp_flags.append("FIN")
            if "R" in flags_str:
                tcp_flags.append("RST")
        elif pkt.haslayer(UDP):
            protocol = "UDP"
            udp = pkt.getlayer(UDP)
            src_port = int(udp.sport)
            dst_port = int(udp.dport)
        elif pkt.haslayer(ICMP):
            protocol = "ICMP"

        pkt_len = len(pkt)
        pkt_time = float(pkt.time) if hasattr(pkt, "time") else 0.0

        flow_key = (src_ip, dst_ip, src_port, dst_port, protocol)

        if flow_key not in flows:
            flows[flow_key] = {
                "src_ip": src_ip,
                "dst_ip": dst_ip,
                "src_port": src_port,
                "dst_port": dst_port,
                "protocol": protocol,
                "packet_count": 1,
                "byte_count": pkt_len,
                "first_time": pkt_time,
                "last_time": pkt_time,
                "tcp_flags": set(tcp_flags),
            }
        else:
            fl = flows[flow_key]
            fl["packet_count"] += 1
            fl["byte_count"] += pkt_len
            fl["first_time"] = min(fl["first_time"], pkt_time)
            fl["last_time"] = max(fl["last_time"], pkt_time)
            fl["tcp_flags"].update(tcp_flags)

    # Standardize records
    records = []
    for flow in flows.values():
        duration = max(0.0, flow["last_time"] - flow["first_time"])
        pkt_cnt = flow["packet_count"]
        byte_cnt = flow["byte_count"]
        pkt_rate = round(pkt_cnt / max(duration, 0.001), 2)
        byte_rate = round(byte_cnt / max(duration, 0.001), 2)
        avg_size = round(byte_cnt / max(pkt_cnt, 1), 2)
        flags_formatted = ",".join(sorted(flow["tcp_flags"]))

        records.append({
            "src_ip": flow["src_ip"],
            "dst_ip": flow["dst_ip"],
            "src_port": flow["src_port"],
            "dst_port": flow["dst_port"],
            "protocol": flow["protocol"],
            "packet_count": pkt_cnt,
            "byte_count": byte_cnt,
            "flow_duration": round(duration, 4),
            "packet_rate": pkt_rate,
            "byte_rate": byte_rate,
            "tcp_flags": flags_formatted,
            "avg_packet_size": avg_size,
            "source_type": "PCAP",
        })

    return records


# -----------------------------------------------------------------
# OPTIONAL LIVE CAPTURE MANAGER
# -----------------------------------------------------------------

import threading
class LiveCaptureManager:
    """
    Manages optional background network packet sniffing.
    Designed with graceful degradation: if elevated privileges are missing,
    the application marks capability as UNAVAILABLE and does not crash.
    """

    def __init__(self):
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self.packets_captured = 0
        self.is_capturing = False
        self.provider: str | None = None
        self._capture_callback = None
        self._pktmon_etl: Path | None = None
        self._pktmon_pcapng: Path | None = None

    def is_available(self) -> tuple[bool, str]:
        """Check live packet capture availability."""
        try:
            from setup import detect_environment
        except ImportError:
            import detect_environment
        cap = detect_environment.detect_network_capture_capability()
        self._capability = cap
        return cap["available"], cap["reason"]

    def start_capture(self, iface: str | None = None, callback=None) -> dict:
        """Start live packet capture in a non-blocking background thread."""
        available, reason = self.is_available()
        if not available:
            return {
                "success": False,
                "status": "UNAVAILABLE",
                "message": f"Live packet capture is not permitted in this environment: {reason}"
            }

        if self.is_capturing:
            return {"success": True, "status": "ALREADY_RUNNING", "message": "Capture is already active."}

        cap = getattr(self, "_capability", {})
        provider = cap.get("provider")
        if provider == "pktmon":
            return self._start_pktmon_capture(callback)

        self._stop_event.clear()
        self.packets_captured = 0
        self.is_capturing = True
        self.provider = "npcap" if provider == "npcap" else provider
        self._capture_callback = callback

        def capture_loop():
            try:
                from scapy.all import sniff

                def process_packet(pkt):
                    if self._stop_event.is_set():
                        return True
                    self.packets_captured += 1
                    if callback:
                        try:
                            callback(pkt)
                        except Exception as callback_error:
                            logger.error("Live capture callback failed: %s", callback_error)

                while not self._stop_event.is_set():
                    sniff(iface=iface, prn=process_packet, timeout=1, store=False)
            except Exception as e:
                logger.error(f"Live capture error: {e}")
            finally:
                self.is_capturing = False
                self.provider = None

        self._thread = threading.Thread(target=capture_loop, daemon=True)
        self._thread.start()
        return {"success": True, "status": "STARTED", "message": "Live capture started successfully."}

    def _start_pktmon_capture(self, callback=None) -> dict:
        """Start Windows' in-box PktMon capture; packets are analyzed on stop."""
        from app.config import CAPTURES_DIR

        pktmon = shutil.which("pktmon.exe") or shutil.which("pktmon")
        if not pktmon:
            return {"success": False, "status": "UNAVAILABLE", "message": "PktMon was not found."}
        stamp = time.strftime("%Y%m%d_%H%M%S")
        self._pktmon_etl = CAPTURES_DIR / f"sentinel_x_{stamp}.etl"
        self._pktmon_pcapng = CAPTURES_DIR / f"sentinel_x_{stamp}.pcapng"
        command = [
            pktmon, "start", "--capture", "--comp", "nics", "--pkt-size", "0",
            "--file-size", "64", "--log-mode", "circular", "--file-name", str(self._pktmon_etl),
        ]
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=15)
        except Exception as exc:
            self._pktmon_etl = None
            self._pktmon_pcapng = None
            return {"success": False, "status": "UNAVAILABLE", "message": f"Could not start PktMon: {exc}"}
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "PktMon returned an error.").strip()
            self._pktmon_etl = None
            self._pktmon_pcapng = None
            return {"success": False, "status": "UNAVAILABLE", "message": detail}

        self._stop_event.clear()
        self.packets_captured = 0
        self.provider = "pktmon"
        self._capture_callback = callback
        self.is_capturing = True
        return {
            "success": True,
            "status": "STARTED",
            "provider": "pktmon",
            "message": "Windows Packet Monitor capture started. Captured packets are analyzed when you stop the session.",
        }

    def stop_capture(self) -> dict:
        """Stop background live packet capture."""
        if not self.is_capturing:
            return {"success": True, "message": "Capture is not currently active."}
        self._stop_event.set()
        if self.provider == "pktmon":
            return self._stop_pktmon_capture()
        thread = self._thread
        if thread and thread.is_alive():
            thread.join(timeout=2)
        self.is_capturing = False
        count = self.packets_captured
        self.provider = None
        self._capture_callback = None
        return {"success": True, "packets_captured": count, "message": f"Capture stopped. Total packets: {count}"}

    def _stop_pktmon_capture(self) -> dict:
        pktmon = shutil.which("pktmon.exe") or shutil.which("pktmon")
        self.is_capturing = False
        try:
            if not pktmon:
                return {"success": False, "message": "PktMon is no longer available on PATH.", "packets_captured": 0}
            if not self._pktmon_etl or not self._pktmon_pcapng:
                return {"success": False, "message": "PktMon capture file paths are missing.", "packets_captured": 0}
            stopped = subprocess.run([pktmon, "stop"], capture_output=True, text=True, timeout=20)
            if stopped.returncode != 0:
                detail = (stopped.stderr or stopped.stdout or "PktMon stop failed.").strip()
                return {"success": False, "message": detail, "packets_captured": 0}
            converted = subprocess.run(
                [pktmon, "etl2pcap", str(self._pktmon_etl), "--out", str(self._pktmon_pcapng)],
                capture_output=True, text=True, timeout=30,
            )
            if converted.returncode != 0 or not self._pktmon_pcapng.exists():
                detail = (converted.stderr or converted.stdout or "Could not convert PktMon capture to PCAPNG.").strip()
                return {"success": False, "message": detail, "packets_captured": 0, "capture_file": str(self._pktmon_etl)}

            from scapy.utils import PcapReader
            with PcapReader(str(self._pktmon_pcapng)) as reader:
                for packet in reader:
                    self.packets_captured += 1
                    if self._capture_callback:
                        self._capture_callback(packet)
            return {
                "success": True,
                "provider": "pktmon",
                "packets_captured": self.packets_captured,
                "capture_file": str(self._pktmon_pcapng),
                "message": f"PktMon capture analyzed. Packets processed: {self.packets_captured}",
            }
        except Exception as exc:
            logger.exception("Could not finalize PktMon capture")
            return {"success": False, "message": f"Could not finalize PktMon capture: {exc}", "packets_captured": self.packets_captured}
        finally:
            self.provider = None
            self._capture_callback = None
            self._pktmon_etl = None
            self._pktmon_pcapng = None


# Global singleton instance
live_capture_manager = LiveCaptureManager()

