"""
Sentinel-X: False-Positive Reduction Filter
============================================
A three-layer defence that sits between the raw RF/IF predictions and alert
creation, reducing false-positive alerts without silencing genuine threats.

Layer 1 — Confidence Gate
    Attack classifications below a per-class minimum confidence must also
    pass an anomaly corroboration threshold to be treated as confirmed.

Layer 2 — Feature Plausibility Check
    Validates that the raw flow features are actually consistent with the
    claimed attack class.  A "DDoS" prediction on a flow with large
    avg_packet_size or long flow_duration is implausible.

Layer 3 — GBM Meta-Learner
    An optional Gradient Boosted classifier trained on the combined
    meta-feature vector:
        [ RF class probabilities (5)
        | calibrated IF anomaly score (1)
        | raw flow features (12)
        | plausibility_score (1) ]
    Predicts: "confirmed_threat" | "likely_benign"

The final verdict is:
    - CONFIRMED_THREAT   → alert fires as normal
    - LIKELY_BENIGN      → alert is downgraded (threat_score dampened,
                           severity capped at MEDIUM, is_alert = False
                           unless the raw score was HIGH/CRITICAL)
    - SUPPRESSED         → alert is completely suppressed (score < 30 after
                           dampening AND verdict is likely_benign)

Usage
-----
    from app.fp_filter import fp_filter
    verdict, fp_score, details = fp_filter.evaluate(
        attack_type, confidence, anomaly_score, rf_probas, feature_row, flow_record
    )
"""

from __future__ import annotations

import logging
from typing import Any

import numpy as np

from app.preprocessing import FEATURE_COLUMNS
from app.model_manager import model_manager

logger = logging.getLogger("sentinel_x.fp_filter")

# Path to the serialised GBM model (resolved via config)
from app.config import MODEL_DIR as _MODEL_DIR
FP_FILTER_MODEL_PATH = _MODEL_DIR / "fp_filter_gbm.joblib"

# ---------------------------------------------------------------------------
# Per-class confidence gates (minimum confidence before an alert fires
# without anomaly corroboration).
# ---------------------------------------------------------------------------
CONFIDENCE_GATES: dict[str, float] = {
    "DDoS":       0.65,
    "PortScan":   0.60,
    "BruteForce": 0.70,   # highest — strongest Normal overlap (SSH port 22)
    "Malware/C2": 0.60,
}

# Minimum anomaly score required to corroborate a low-confidence attack call.
ANOMALY_CORROBORATION_THRESHOLD: float = 0.55

# ---------------------------------------------------------------------------
# Feature plausibility rules per attack class.
# Each entry is (feature_index, operator, threshold, weight).
# Operator: ">" means the feature SHOULD be above threshold for this class
#           "<" means the feature SHOULD be below threshold
# weight: how much this failed rule penalises the plausibility score (0–1).
# ---------------------------------------------------------------------------
_FEAT = {name: idx for idx, name in enumerate(FEATURE_COLUMNS)}

PLAUSIBILITY_RULES: dict[str, list[tuple[str, str, float, float]]] = {
    "DDoS": [
        # DDoS: very high packet_rate, small packets, short duration
        ("packet_rate",      ">",   200.0,  0.30),
        ("avg_packet_size",  "<",   400.0,  0.25),
        ("flow_duration",    "<",   5.0,    0.20),
        ("packet_count",     ">",   100.0,  0.25),
    ],
    "PortScan": [
        # PortScan: very few packets, tiny bytes, very short duration
        ("packet_count",     "<",   10.0,   0.35),
        ("avg_packet_size",  "<",   100.0,  0.30),
        ("flow_duration",    "<",   0.5,    0.20),
        ("flag_ack",         "<",   0.5,    0.15),   # no ACK in SYN-only scan
    ],
    "BruteForce": [
        # BruteForce: medium packets, multi-second flows, auth ports
        ("flow_duration",    ">",   0.5,    0.20),
        ("packet_count",     ">",   10.0,   0.25),
        ("flag_syn",         ">",   0.5,    0.15),
        ("flag_ack",         ">",   0.5,    0.25),   # full handshake
        ("avg_packet_size",  ">",   60.0,   0.15),
    ],
    "Malware/C2": [
        # C2: long-duration low-rate beacon
        ("flow_duration",    ">",   10.0,   0.35),
        ("packet_rate",      "<",   5.0,    0.30),
        ("flag_fin",         "<",   0.5,    0.20),   # C2 rarely FINs
        ("flag_rst",         "<",   0.5,    0.15),
    ],
}


def _compute_plausibility(attack_type: str, feature_row: np.ndarray) -> float:
    """
    Return a plausibility score in [0.0, 1.0].
    1.0 = all rules pass (flow looks like this attack class).
    0.0 = all rules fail (flow does NOT look like this attack class).
    """
    rules = PLAUSIBILITY_RULES.get(attack_type)
    if not rules:
        return 1.0   # no rules for "Normal" — always plausible

    total_weight = sum(w for _, _, _, w in rules)
    passed_weight = 0.0

    for feat_name, op, threshold, weight in rules:
        idx = _FEAT.get(feat_name)
        if idx is None:
            continue
        val = float(feature_row[idx])
        if op == ">" and val > threshold:
            passed_weight += weight
        elif op == "<" and val < threshold:
            passed_weight += weight

    return passed_weight / total_weight if total_weight > 0 else 1.0


def _build_meta_features(
    rf_probas: np.ndarray,
    anomaly_score: float,
    feature_row: np.ndarray,
    plausibility: float,
) -> np.ndarray:
    """
    Assemble the meta-feature vector fed to the GBM:
    [ rf_proba_BruteForce, rf_proba_DDoS, rf_proba_Malware/C2,
      rf_proba_Normal, rf_proba_PortScan,   (5 — alphabetical order)
      anomaly_score,                         (1)
      ...12 raw features...,                 (12)
      plausibility_score ]                   (1)
    Total: 19 features.
    """
    # rf_probas may have variable length; pad/truncate to exactly 5 values
    proba_vec = np.zeros(5, dtype=np.float32)
    n = min(len(rf_probas), 5)
    proba_vec[:n] = rf_probas[:n]

    meta = np.concatenate([
        proba_vec,
        np.array([anomaly_score], dtype=np.float32),
        feature_row.astype(np.float32),
        np.array([plausibility], dtype=np.float32),
    ])
    return meta


# Number of features in the meta-vector (must match _build_meta_features)
META_FEATURE_COUNT = 5 + 1 + len(FEATURE_COLUMNS) + 1   # = 19


class FalsePositiveFilter:
    """
    Three-layer false-positive reduction engine.
    Operates as a stateless evaluator — no mutable state between calls.
    """

    def __init__(self) -> None:
        self._gbm = None          # loaded on first use via model_manager
        self._classes: list[str] = ["confirmed_threat", "likely_benign"]

    def _load_gbm(self) -> bool:
        """Lazy-load the GBM meta-learner from model_manager."""
        if self._gbm is not None:
            return True
        gbm = getattr(model_manager, "fp_filter_model", None)
        if gbm is not None:
            self._gbm = gbm
            if hasattr(gbm, "classes_"):
                self._classes = list(gbm.classes_)
            return True
        return False

    # ------------------------------------------------------------------
    def evaluate(
        self,
        attack_type: str,
        confidence: float,
        anomaly_score: float,
        rf_probas: np.ndarray,
        feature_row: np.ndarray,
        flow_record: dict,
    ) -> tuple[str, float, dict[str, Any]]:
        """
        Run all three filter layers and return a final verdict.

        Returns
        -------
        verdict : "CONFIRMED_THREAT" | "LIKELY_BENIGN" | "SUPPRESSED"
        fp_score : float [0.0, 1.0]
            Probability that this alert is a false positive.
            0.0 = definitely real threat, 1.0 = definitely false positive.
        details : dict
            Breakdown of each layer's decision for logging/display.
        """
        if attack_type == "Normal":
            # Normal-classified traffic never reaches this filter via
            # the attack path — pass through transparently.
            return "CONFIRMED_THREAT", 0.0, {"layer": "passthrough"}

        details: dict[str, Any] = {
            "attack_type":  attack_type,
            "confidence":   round(confidence, 4),
            "anomaly_score": round(anomaly_score, 4),
        }

        # ── Layer 1: Confidence Gate ─────────────────────────────────
        min_conf = CONFIDENCE_GATES.get(attack_type, 0.60)
        gate_passed = confidence >= min_conf
        corroborated = anomaly_score >= ANOMALY_CORROBORATION_THRESHOLD

        if not gate_passed and not corroborated:
            details["layer1"] = (
                f"FAILED — confidence {confidence:.2f} < gate {min_conf:.2f} "
                f"and anomaly {anomaly_score:.2f} < corroboration threshold "
                f"{ANOMALY_CORROBORATION_THRESHOLD:.2f}"
            )
            return "LIKELY_BENIGN", 0.80, details

        details["layer1"] = (
            f"passed — conf={confidence:.2f} gate={min_conf:.2f} "
            f"corroborated={corroborated}"
        )

        # ── Layer 2: Feature Plausibility ────────────────────────────
        plausibility = _compute_plausibility(attack_type, feature_row)
        details["layer2"] = {
            "plausibility_score": round(plausibility, 3),
        }

        if plausibility < 0.30:
            # Flow features strongly contradict the predicted attack class
            details["layer2"]["result"] = (
                f"FAILED — plausibility {plausibility:.2f} < 0.30"
            )
            return "LIKELY_BENIGN", 0.75, details

        details["layer2"]["result"] = f"passed — plausibility {plausibility:.2f}"

        # ── Layer 3: GBM Meta-Learner ────────────────────────────────
        gbm_loaded = self._load_gbm()

        if gbm_loaded and self._gbm is not None:
            try:
                meta = _build_meta_features(
                    rf_probas, anomaly_score, feature_row, plausibility
                )
                meta_row = np.asarray(meta, dtype=np.float32).reshape(1, -1)
                gbm_pred = self._gbm.predict(meta_row)[0]
                gbm_proba = self._gbm.predict_proba(meta_row)[0]

                # fp_score = P(likely_benign)
                if "likely_benign" in self._classes:
                    lb_idx = self._classes.index("likely_benign")
                    fp_score = float(gbm_proba[lb_idx])
                else:
                    fp_score = 0.0

                details["layer3"] = {
                    "gbm_verdict":   gbm_pred,
                    "fp_score":      round(fp_score, 4),
                    "gbm_probas":    {
                        c: round(float(p), 4)
                        for c, p in zip(self._classes, gbm_proba)
                    },
                }

                if gbm_pred == "likely_benign":
                    if fp_score > 0.85:
                        verdict = "SUPPRESSED"
                    else:
                        verdict = "LIKELY_BENIGN"
                    return verdict, fp_score, details

                # GBM says confirmed_threat — trust it
                return "CONFIRMED_THREAT", fp_score, details

            except Exception as exc:
                logger.warning("GBM meta-learner evaluation failed: %s", exc)
                details["layer3"] = {"error": str(exc)}
                # Fall through to heuristic verdict
        else:
            details["layer3"] = {"status": "GBM model not loaded — using heuristics only"}

        # ── Heuristic fallback (no GBM) ──────────────────────────────
        # Combine gate result and plausibility into a simple fp_score
        fp_score = (1.0 - confidence) * 0.5 + (1.0 - plausibility) * 0.5
        verdict = "LIKELY_BENIGN" if fp_score > 0.45 else "CONFIRMED_THREAT"
        details["fallback"] = {"fp_score": round(fp_score, 4), "verdict": verdict}
        return verdict, fp_score, details


# ---------------------------------------------------------------------------
# Module-level helpers used by the training pipeline to generate meta-labels
# and meta-features without importing the full filter object.
# ---------------------------------------------------------------------------

def generate_meta_features_batch(
    rf_probas_matrix: np.ndarray,    # shape (N, 5)
    anomaly_scores: np.ndarray,      # shape (N,)
    feature_matrix: np.ndarray,      # shape (N, 12)
    attack_types: list[str],
) -> np.ndarray:
    """
    Vectorised meta-feature generation for training the GBM.
    Returns array of shape (N, META_FEATURE_COUNT).
    """
    rows = []
    for i in range(len(attack_types)):
        plausibility = _compute_plausibility(attack_types[i], feature_matrix[i])
        row = _build_meta_features(
            rf_probas_matrix[i],
            float(anomaly_scores[i]),
            feature_matrix[i],
            plausibility,
        )
        rows.append(row)
    return np.array(rows, dtype=np.float32)


def apply_verdict_to_score(
    verdict: str,
    threat_score: int,
    severity: str,
) -> tuple[int, str, bool]:
    """
    Adjust threat_score and severity based on the FP filter verdict.

    Returns
    -------
    adjusted_score : int
    adjusted_severity : str
    is_alert : bool
    """
    if verdict == "CONFIRMED_THREAT":
        return threat_score, severity, True

    if verdict == "SUPPRESSED":
        return max(0, threat_score // 3), "LOW", False

    # LIKELY_BENIGN — dampen but do not fully suppress if genuinely high score
    dampened = int(threat_score * 0.55)

    # Recompute severity from dampened score
    from app.scoring import determine_severity
    adj_severity = determine_severity(dampened)

    # Only keep as alert if dampened score is still >= 60 (HIGH threshold)
    is_alert = dampened >= 60

    return dampened, adj_severity, is_alert


# Global singleton
fp_filter = FalsePositiveFilter()
