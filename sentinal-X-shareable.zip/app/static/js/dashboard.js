// Sentinel-X Dashboard Logic
let trafficChart, threatsChart, attackChart, severityChart;

document.addEventListener("DOMContentLoaded", () => {
  initCharts();
  loadDashboardData();
  // Poll every 5 seconds
  setInterval(loadDashboardData, 5000);
});

function initCharts() {
  const commonOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { labels: { color: "#9ca3af", font: { family: "sans-serif" } } }
    },
    scales: {
      x: { grid: { color: "#1f2937" }, ticks: { color: "#9ca3af" } },
      y: { grid: { color: "#1f2937" }, ticks: { color: "#9ca3af" } }
    }
  };

  // 1. Traffic Volume Timeline
  const ctxTraffic = document.getElementById("trafficTimelineChart").getContext("2d");
  trafficChart = new Chart(ctxTraffic, {
    type: "line",
    data: {
      labels: [],
      datasets: [{
        label: "Packets",
        data: [],
        borderColor: "#3b82f6",
        backgroundColor: "rgba(59, 130, 246, 0.15)",
        fill: true,
        tension: 0.3
      }]
    },
    options: commonOptions
  });

  // 2. Threats Timeline
  const ctxThreats = document.getElementById("threatsTimelineChart").getContext("2d");
  threatsChart = new Chart(ctxThreats, {
    type: "line",
    data: {
      labels: [],
      datasets: [{
        label: "Threat Risk Score",
        data: [],
        borderColor: "#ef4444",
        backgroundColor: "rgba(239, 68, 68, 0.15)",
        fill: true,
        tension: 0.2
      }]
    },
    options: {
      ...commonOptions,
      scales: {
        ...commonOptions.scales,
        y: { ...commonOptions.scales.y, min: 0, max: 100 }
      }
    }
  });

  // 3. Attack Distribution
  const ctxAttack = document.getElementById("attackDistChart").getContext("2d");
  attackChart = new Chart(ctxAttack, {
    type: "doughnut",
    data: {
      labels: ["DDoS", "PortScan", "BruteForce", "Malware/C2", "Normal"],
      datasets: [{
        data: [0, 0, 0, 0, 0],
        backgroundColor: ["#ef4444", "#f97316", "#eab308", "#a855f7", "#10b981"]
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { labels: { color: "#9ca3af" } } }
    }
  });

  // 4. Severity Breakdown
  const ctxSeverity = document.getElementById("severityDistChart").getContext("2d");
  severityChart = new Chart(ctxSeverity, {
    type: "bar",
    data: {
      labels: ["CRITICAL", "HIGH", "MEDIUM", "LOW"],
      datasets: [{
        label: "Alert Count",
        data: [0, 0, 0, 0],
        backgroundColor: ["#ef4444", "#f97316", "#eab308", "#38bdf8"]
      }]
    },
    options: {
      ...commonOptions,
      plugins: { legend: { display: false } }
    }
  });
}

async function loadDashboardData() {
  try {
    const res = await fetch("/api/dashboard");
    if (!res.ok) return;
    const data = await res.json();

    // Update Counters
    document.getElementById("metricTotalTraffic").textContent = data.total_traffic || 0;
    document.getElementById("metricCritical").textContent = data.critical_count || 0;
    document.getElementById("metricHigh").textContent = data.high_count || 0;
    document.getElementById("metricMedium").textContent = data.medium_count || 0;
    document.getElementById("metricLow").textContent = data.low_count || 0;
    document.getElementById("metricNormal").textContent = data.normal_traffic || 0;

    // Update Live Capture Badge
    const liveCap = data.live_capture || {};
    const badge = document.getElementById("liveCaptureBadge");
    const badgeText = document.getElementById("liveCaptureText");
    if (liveCap.available) {
      badge.className = "status-badge available";
      badgeText.textContent = "Live Capture: AVAILABLE";
    } else {
      badge.className = "status-badge unavailable";
      badgeText.textContent = "Live Capture: UNAVAILABLE";
    }

    // Update Charts
    if (data.traffic_timeline && data.traffic_timeline.length > 0) {
      trafficChart.data.labels = data.traffic_timeline.map(t => t.time);
      trafficChart.data.datasets[0].data = data.traffic_timeline.map(t => t.packets);
      trafficChart.update();
    }

    if (data.threats_timeline && data.threats_timeline.length > 0) {
      threatsChart.data.labels = data.threats_timeline.map(t => t.time);
      threatsChart.data.datasets[0].data = data.threats_timeline.map(t => t.score);
      threatsChart.update();
    }

    if (data.attack_distribution) {
      const labels = Object.keys(data.attack_distribution);
      const vals = Object.values(data.attack_distribution);
      if (labels.length > 0) {
        attackChart.data.labels = labels;
        attackChart.data.datasets[0].data = vals;
        attackChart.update();
      }
    }

    if (data.severity_distribution) {
      const sev = data.severity_distribution;
      severityChart.data.datasets[0].data = [
        sev.CRITICAL || 0,
        sev.HIGH || 0,
        sev.MEDIUM || 0,
        sev.LOW || 0
      ];
      severityChart.update();
    }

    // Fetch and display recent alerts
    loadRecentAlerts();

  } catch (err) {
    console.error("Dashboard update error:", err);
  }
}

async function loadRecentAlerts() {
  try {
    const res = await fetch("/api/alerts?limit=5");
    if (!res.ok) return;
    const data = await res.json();
    const tbody = document.getElementById("recentAlertsBody");

    if (!data.alerts || data.alerts.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: var(--text-muted);">No active security alerts recorded yet.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.alerts.map(a => {
      const sevClass = (a.severity || "LOW").toLowerCase();
      const statusClass = a.status === "RESOLVED" ? "badge-resolved" : "badge-new";
      return `
        <tr>
          <td class="font-mono">#${a.id}</td>
          <td><strong>${a.attack_type}</strong></td>
          <td><span class="badge badge-${sevClass}">${a.severity}</span></td>
          <td class="font-mono">${a.threat_score}</td>
          <td class="font-mono">${a.src_ip} -> ${a.dst_ip}:${a.dst_port}</td>
          <td>${a.protocol}</td>
          <td class="font-mono" style="font-size: 0.75rem;">${a.created_at || ""}</td>
          <td>
            <a href="/alerts/${a.id}" class="btn btn-outline btn-sm">Inspect</a>
          </td>
        </tr>
      `;
    }).join("");

  } catch (err) {
    console.error("Failed to load recent alerts:", err);
  }
}
