// Sentinel-X Alerts Management Logic
document.addEventListener("DOMContentLoaded", () => {
  loadAlerts();
});

async function loadAlerts() {
  const sev = document.getElementById("filterSeverity").value;
  const status = document.getElementById("filterStatus").value;

  let url = `/api/alerts?limit=100`;
  if (sev) url += `&severity=${encodeURIComponent(sev)}`;
  if (status) url += `&status=${encodeURIComponent(status)}`;

  try {
    const res = await fetch(url);
    if (!res.ok) return;
    const data = await res.json();
    const tbody = document.getElementById("alertsTableBody");

    document.getElementById("alertsCount").textContent = `${data.count} alerts matching filters`;

    if (!data.alerts || data.alerts.length === 0) {
      tbody.innerHTML = `<tr><td colspan="10" style="text-align: center; color: var(--text-muted); padding: 2rem;">No alerts found matching filter criteria.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.alerts.map(a => {
      const sevClass = (a.severity || "LOW").toLowerCase();
      const statusClass = a.status === "RESOLVED" ? "badge-resolved" : "badge-new";
      const resolveBtn = a.status !== "RESOLVED" 
        ? `<button class="btn btn-outline btn-sm" onclick="resolveAlert(${a.id})">Resolve</button>`
        : `<span style="color: var(--color-normal); font-size: 0.8rem;">Resolved</span>`;

      return `
        <tr>
          <td class="font-mono">#${a.id}</td>
          <td><strong>${a.attack_type}</strong></td>
          <td><span class="badge badge-${sevClass}">${a.severity}</span></td>
          <td class="font-mono"><strong>${a.threat_score}</strong>/100</td>
          <td class="font-mono">${(a.confidence * 100).toFixed(1)}%</td>
          <td class="font-mono">${(a.anomaly_score * 100).toFixed(1)}%</td>
          <td class="font-mono">${a.src_ip} -> ${a.dst_ip}:${a.dst_port}</td>
          <td><span class="badge ${statusClass}">${a.status}</span></td>
          <td class="font-mono" style="font-size: 0.75rem;">${a.created_at || ""}</td>
          <td style="display: flex; gap: 0.5rem;">
            <a href="/alerts/${a.id}" class="btn btn-primary btn-sm">Details</a>
            ${resolveBtn}
          </td>
        </tr>
      `;
    }).join("");

  } catch (err) {
    console.error("Failed to load alerts:", err);
  }
}

async function resolveAlert(alertId) {
  try {
    const res = await fetch(`/api/alerts/${alertId}/resolve`, { method: "POST" });
    if (res.ok) {
      loadAlerts();
    } else {
      const footer = document.getElementById("alertsFooter");
      if (footer) footer.textContent = `Error: Could not resolve alert #${alertId}.`;
      console.error("Failed to resolve alert:", alertId);
    }
  } catch (err) {
    console.error("Resolve error:", err);
  }
}
