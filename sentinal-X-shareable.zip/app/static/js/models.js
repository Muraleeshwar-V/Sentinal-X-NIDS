// Sentinel-X Models Management Logic
let fiChart;

document.addEventListener("DOMContentLoaded", () => {
  initFIChart();
  loadModelsData();
});

function initFIChart() {
  const ctx = document.getElementById("featureImportanceChart").getContext("2d");
  fiChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: [],
      datasets: [{
        label: "Feature Importance",
        data: [],
        backgroundColor: "#06b6d4"
      }]
    },
    options: {
      indexAxis: "y",
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      },
      scales: {
        x: {
          grid: { color: "#1f2937" },
          ticks: { color: "#9ca3af" }
        },
        y: {
          grid: { color: "#1f2937" },
          ticks: { color: "#9ca3af", font: { family: "monospace" } }
        }
      }
    }
  });
}

async function loadModelsData() {
  try {
    // 1. Load active models info
    const resActive = await fetch("/api/models/active");
    if (resActive.ok) {
      const activeData = await resActive.json();
      const importances = activeData.feature_importances || {};
      const sortedKeys = Object.keys(importances).sort((a, b) => importances[b] - importances[a]);

      const report = activeData.training_report || {};
      const metrics = report.held_out_metrics;
      const architecture = report.selected_model === "trained"
        ? "NumPy softmax classifier"
        : "Calibrated multi-signal flow rules";
      document.getElementById("classifierArchitecture").textContent = architecture;
      if (metrics) {
        document.getElementById("rfAccuracy").textContent = `${(metrics.accuracy * 100).toFixed(1)}%`;
        const classes = Object.values(metrics.per_class || {});
        const macroF1 = classes.length ? classes.reduce((sum, item) => sum + item.f1, 0) / classes.length : 0;
        document.getElementById("rfF1").textContent = `${(macroF1 * 100).toFixed(1)}%`;
        const candidateAcc = report.trained_candidate_metrics?.accuracy;
        const rulesAcc = report.rules_baseline_metrics?.accuracy;
        const comparison = candidateAcc !== undefined && rulesAcc !== undefined
          ? ` · softmax ${ (candidateAcc * 100).toFixed(1) }% vs rules ${ (rulesAcc * 100).toFixed(1) }%`
          : "";
        document.getElementById("trainingSummary").textContent =
          `Selected ${report.selected_model || "rules"} · ${metrics.samples} held-out flows · ` +
          `${(metrics.balanced_accuracy * 100).toFixed(1)}% balanced accuracy · source: ${report.source || "unknown"}${comparison}`;
        const rows = Object.entries(metrics.per_class || {});
        document.getElementById("trainingMetricsBody").innerHTML = rows.map(([label, item]) => `
          <tr><td>${label}</td><td>${(item.precision * 100).toFixed(1)}%</td>
          <td>${(item.recall * 100).toFixed(1)}%</td><td>${(item.f1 * 100).toFixed(1)}%</td>
          <td>${item.support}</td></tr>`).join("");
      }

      fiChart.data.labels = sortedKeys;
      fiChart.data.datasets[0].data = sortedKeys.map(k => importances[k]);
      fiChart.update();
    }

    // 2. Load model history from DB
    const resList = await fetch("/api/models");
    if (resList.ok) {
      const listData = await resList.json();
      const tbody = document.getElementById("modelsTableBody");

      if (!listData.models || listData.models.length === 0) {
        tbody.innerHTML = `<tr><td colspan="9" style="text-align: center; color: var(--text-muted); padding: 2rem;">No registered models found in database.</td></tr>`;
        return;
      }

      tbody.innerHTML = listData.models.map(m => `
        <tr>
          <td class="font-mono">#${m.id}</td>
          <td><strong>${m.name}</strong></td>
          <td class="font-mono">${m.version}</td>
          <td>${m.model_type}</td>
          <td class="font-mono">${m.accuracy !== null ? (m.accuracy * 100).toFixed(1) + '%' : 'N/A'}</td>
          <td class="font-mono">${m.f1_score !== null ? (m.f1_score * 100).toFixed(1) + '%' : 'N/A'}</td>
          <td class="font-mono">${m.file_path}</td>
          <td><span class="badge ${m.is_active ? 'badge-resolved' : 'badge-low'}">${m.is_active ? 'Active' : 'Inactive'}</span></td>
          <td class="font-mono" style="font-size: 0.75rem;">${m.created_at || ""}</td>
        </tr>
      `).join("");
    }
  } catch (err) {
    console.error("Failed to load models data:", err);
  }
}

async function triggerRetraining() {
  const btn = document.getElementById("trainBtn");
  const statusEl = document.getElementById("trainStatus");
  btn.disabled = true;
  btn.textContent = "Initiating Training...";
  if (statusEl) statusEl.textContent = "";

  try {
    const res = await fetch("/api/models/train", { method: "POST" });
    const data = await res.json();
    const msg = data.message || "Training task started in background.";
    if (statusEl) {
      statusEl.style.color = "var(--color-normal)";
      statusEl.textContent = "✓ " + msg;
    } else {
      console.info("Retraining:", msg);
    }
    setTimeout(() => {
      loadModelsData();
      btn.disabled = false;
      btn.textContent = "Train / Update Models";
      if (statusEl) statusEl.textContent = "";
    }, 4000);
  } catch (err) {
    const errMsg = "Error initiating training: " + err;
    if (statusEl) {
      statusEl.style.color = "var(--color-critical)";
      statusEl.textContent = "✗ " + errMsg;
    } else {
      console.error(errMsg);
    }
    btn.disabled = false;
    btn.textContent = "Train / Update Models";
  }
}

async function triggerLabeledTraining() {
  const input = document.getElementById("trainingCsv");
  const btn = document.getElementById("trainCsvBtn");
  const statusEl = document.getElementById("trainStatus");
  const file = input.files && input.files[0];
  if (!file) {
    statusEl.style.color = "var(--color-high)";
    statusEl.textContent = "Choose a labeled CSV first.";
    return;
  }

  const form = new FormData();
  form.append("file", file);
  btn.disabled = true;
  statusEl.style.color = "var(--text-muted)";
  statusEl.textContent = "Checking labels and starting held-out training…";
  try {
    const res = await fetch("/api/models/train/labeled", { method: "POST", body: form });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Training request failed.");
    statusEl.style.color = "var(--color-normal)";
    statusEl.textContent = `Training ${data.samples} flows across ${data.classes.length} classes…`;
    for (let attempt = 0; attempt < 120; attempt++) {
      await new Promise(resolve => setTimeout(resolve, 2000));
      const activeResponse = await fetch("/api/models/active");
      if (!activeResponse.ok) continue;
      const active = await activeResponse.json();
      if ((active.training_report?.source || "").endsWith(data.training_id)) {
        await loadModelsData();
        statusEl.textContent = "Training finished; held-out metrics are updated.";
        btn.disabled = false;
        setTimeout(() => { statusEl.textContent = ""; }, 5000);
        return;
      }
    }
    statusEl.style.color = "var(--color-high)";
    statusEl.textContent = "Training is taking longer than expected. Check the system log for status.";
    btn.disabled = false;
  } catch (err) {
    statusEl.style.color = "var(--color-critical)";
    statusEl.textContent = err.message;
    btn.disabled = false;
  }
}
