// Sentinel-X Traffic Management & Upload Logic
document.addEventListener("DOMContentLoaded", () => {
  setupDropzone();
  checkLiveCaptureStatus();
  loadRecentTraffic();
});

function setupDropzone() {
  const dropzone = document.getElementById("dropzone");

  ["dragenter", "dragover"].forEach(eventName => {
    dropzone.addEventListener(eventName, e => {
      e.preventDefault();
      dropzone.classList.add("dragover");
    });
  });

  ["dragleave", "drop"].forEach(eventName => {
    dropzone.addEventListener(eventName, e => {
      e.preventDefault();
      dropzone.classList.remove("dragover");
    });
  });

  dropzone.addEventListener("drop", e => {
    const dt = e.dataTransfer;
    const files = dt.files;
    if (files.length > 0) {
      uploadFile(files[0]);
    }
  });
}

function handleFileSelect(event) {
  const file = event.target.files[0];
  if (file) {
    uploadFile(file);
  }
}

async function uploadFile(file) {
  const progress = document.getElementById("uploadProgress");
  const summary = document.getElementById("uploadSummary");
  progress.style.display = "block";
  summary.innerHTML = "";

  const formData = new FormData();
  formData.append("file", file);

  try {
    const res = await fetch("/api/traffic/upload", {
      method: "POST",
      body: formData
    });
    const data = await res.json();
    progress.style.display = "none";

    if (data.success) {
      summary.innerHTML = `
        <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); padding: 1rem; border-radius: 6px; color: var(--color-normal);">
          <strong>Successfully processed ${data.filename}:</strong>
          <ul style="margin-top: 0.5rem; margin-left: 1.5rem; color: #fff;">
            <li>Total Flows Extracted: <strong>${data.total_flows}</strong></li>
            <li>Security Alerts Triggered: <strong>${data.alerts_generated}</strong></li>
            <li>Data Drift Assessment: <strong>${data.drift_status || 'STABLE'}</strong></li>
          </ul>
        </div>
      `;
      loadRecentTraffic();
    } else {
      summary.innerHTML = `<div style="color: var(--color-critical);">Upload failed: ${data.message}</div>`;
    }
  } catch (err) {
    progress.style.display = "none";
    summary.innerHTML = `<div style="color: var(--color-critical);">Network error uploading file: ${err}</div>`;
  }
}

async function checkLiveCaptureStatus() {
  try {
    const res = await fetch("/api/system/status");
    if (!res.ok) return;
    const data = await res.json();

    const liveCap  = data.live_capture || {};
    const pill     = document.getElementById("liveStatusPill");
    const text     = document.getElementById("liveStatusText");
    const info     = document.getElementById("liveCaptureInfo");
    const startBtn = document.getElementById("startCaptureBtn");
    const stopBtn  = document.getElementById("stopCaptureBtn");

    if (liveCap.available) {
      pill.className   = "status-badge available";
      text.textContent = "Live Capture: AVAILABLE";
      info.innerHTML   = `<span style="color: var(--color-normal);">Capture driver and permissions verified. Ready to capture on default interface.</span>`;
      startBtn.disabled = false;
      stopBtn.disabled  = true;
    } else {
      pill.className   = "status-badge unavailable";
      text.textContent = "Live Capture: UNAVAILABLE";
      info.innerHTML   = `
        <span style="color: var(--color-high);">Live sniffing unavailable in current environment:</span><br>
        <em>${liveCap.reason || "Elevated privileges required."}</em><br>
        <small style="color: var(--text-muted); display: block; margin-top: 0.5rem;">
          CSV and PCAP processing remain fully operational without live capture.
        </small>
      `;
      startBtn.disabled = true;
      stopBtn.disabled  = true;
    }
  } catch (err) {
    console.error("Live capture check failed:", err);
  }
}

async function startCapture() {
  const startBtn = document.getElementById("startCaptureBtn");
  const stopBtn  = document.getElementById("stopCaptureBtn");
  const info     = document.getElementById("liveCaptureInfo");

  startBtn.disabled = true;
  info.innerHTML = `<span style="color: var(--accent-cyan);">Starting capture session...</span>`;

  try {
    const res  = await fetch("/api/traffic/capture/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({})
    });
    const data = await res.json();

    if (res.ok && data.success !== false) {
      stopBtn.disabled = false;
      info.innerHTML = `
        <span style="color: var(--color-normal);">&#9679; Live capture active.</span><br>
        <small style="color: var(--text-muted);">${data.message || "Capturing packets on default interface."}</small>
      `;
      _pollCaptureStats();
    } else {
      startBtn.disabled = false;
      const reason = data.detail || data.message || "Unknown error.";
      info.innerHTML = `<span style="color: var(--color-high);">Capture failed: ${reason}</span>`;
    }
  } catch (err) {
    startBtn.disabled = false;
    info.innerHTML = `<span style="color: var(--color-critical);">Network error: ${err}</span>`;
  }
}

async function stopCapture() {
  const startBtn = document.getElementById("startCaptureBtn");
  const stopBtn  = document.getElementById("stopCaptureBtn");
  const info     = document.getElementById("liveCaptureInfo");

  stopBtn.disabled = true;

  try {
    const res  = await fetch("/api/traffic/capture/stop", { method: "POST" });
    const data = await res.json();
    startBtn.disabled = false;
    info.innerHTML = `
      <span style="color: var(--text-muted);">Capture stopped.</span><br>
      <small style="color: var(--text-muted);">${data.message || ""}</small>
    `;
    document.getElementById("capturedCount").textContent = "0";
    loadRecentTraffic();
  } catch (err) {
    stopBtn.disabled = false;
    info.innerHTML = `<span style="color: var(--color-critical);">Stop error: ${err}</span>`;
  }
}

let _capturePoller = null;

function _pollCaptureStats() {
  if (_capturePoller) return;   // already polling
  _capturePoller = setInterval(async () => {
    try {
      const res  = await fetch("/api/traffic/capture/status");
      const data = await res.json();
      document.getElementById("capturedCount").textContent = data.packets_captured || 0;

      if (!data.is_capturing) {
        clearInterval(_capturePoller);
        _capturePoller = null;
        loadRecentTraffic();
      }
    } catch (_) {
      clearInterval(_capturePoller);
      _capturePoller = null;
    }
  }, 2000);
}

async function loadRecentTraffic() {
  try {
    const res = await fetch("/api/traffic/recent?limit=50");
    if (!res.ok) return;
    const data = await res.json();
    const tbody = document.getElementById("trafficTableBody");

    if (!data.records || data.records.length === 0) {
      tbody.innerHTML = `<tr><td colspan="11" style="text-align: center; color: var(--text-muted); padding: 2rem;">No traffic flows recorded yet. Upload a CSV or PCAP file above.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.records.map(r => `
      <tr>
        <td class="font-mono">#${r.id}</td>
        <td class="font-mono">${r.src_ip}</td>
        <td class="font-mono">${r.dst_ip}</td>
        <td class="font-mono">${r.dst_port}</td>
        <td>${r.protocol}</td>
        <td class="font-mono">${r.packet_count}</td>
        <td class="font-mono">${r.byte_count}</td>
        <td class="font-mono">${r.flow_duration}s</td>
        <td class="font-mono">${r.packet_rate}/s</td>
        <td><span class="badge badge-low">${r.source_type}</span></td>
        <td class="font-mono" style="font-size: 0.75rem;">${r.timestamp || ""}</td>
      </tr>
    `).join("");

  } catch (err) {
    console.error("Failed to load traffic records:", err);
  }
}
