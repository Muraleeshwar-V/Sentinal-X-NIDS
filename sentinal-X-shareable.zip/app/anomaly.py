"""
Sentinel-X anomaly scoring based on distance from the normal-flow baseline.
"""

import numpy as np
from typing import Any
from app.model_manager import model_manager
from app.preprocessing import FEATURE_COLUMNS


def calculate_anomaly_score(feature_df: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """
    Compute raw decision function and normalized anomaly probabilities [0.0, 1.0].
    
    Baseline decision function:
    - Positive values: close to the normal training baseline.
    - Negative values: increasingly distant from the normal baseline.
    
    Normalization:
    Uses a logistic sigmoid mapping calibrated such that:
    - Extreme outliers (decision < -0.2) map to ~0.9 - 1.0
    - Baseline normal (decision > +0.1) map to ~0.0 - 0.2
    """
    if not model_manager.anomaly_detector:
        model_manager.load_models()

    if not model_manager.anomaly_detector:
        # Fallback if model not loaded
        n = len(feature_df)
        return np.zeros(n), np.zeros(n)

    # Scikit-learn isolation forest decision function
    raw_decisions = model_manager.anomaly_detector.decision_function(feature_df)

    # IsolationForest decision_function is positive for inliers and negative
    # for outliers. Invert that direction so increasingly negative values
    # produce increasingly high anomaly scores.
    logits = np.clip(15.0 * raw_decisions, -60.0, 60.0)
    anomaly_scores = 1.0 / (1.0 + np.exp(logits))
    anomaly_scores = np.clip(anomaly_scores, 0.0, 1.0)

    return raw_decisions, anomaly_scores
