"""
Sentinel-X: Database Abstraction & Resilience Layer
Supports MySQL 8+ via mysql-connector-python with resilient fallback.
Guarantees uninterrupted application execution and testability across all platforms.
"""

import json
import logging
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# Configure logger
logger = logging.getLogger("sentinel_x.database")


class DatabaseManager:
    """Manages database connectivity, schema creation, queries, and fallback storage."""

    def __init__(self, host: str | None = None, port: int | None = None,
                 user: str | None = None, password: str | None = None,
                 database: str | None = None, fallback_path: Path | None = None):
        # Read defaults from config so .env is always respected
        from app.config import (
            DATABASE_HOST, DATABASE_PORT, DATABASE_NAME,
            DATABASE_USER, DATABASE_PASSWORD,
        )
        if host is None:
            host = DATABASE_HOST
        if port is None:
            port = DATABASE_PORT
        if user is None:
            user = DATABASE_USER
        if password is None:
            password = DATABASE_PASSWORD
        if database is None:
            database = DATABASE_NAME
        self.host = host
        self.port = int(port)
        self.user = user
        self.password = password
        self.database = database
        self.is_mysql_active = False
        self.last_error = ""

        # High-fidelity fallback storage
        self._fallback_traffic: list[dict] = []
        self._fallback_alerts: list[dict] = []
        self._fallback_models: list[dict] = []
        self._fallback_drift: list[dict] = []
        self._fallback_logs: list[dict] = []
        self._id_counters = {
            "traffic": 1,
            "alerts": 1,
            "models": 1,
            "drift": 1,
            "logs": 1,
        }
        if fallback_path is None:
            from app.config import DATABASE_SQLITE_PATH
            fallback_path = DATABASE_SQLITE_PATH
        self.fallback_path = Path(fallback_path)
        self._sqlite_lock = threading.RLock()
        self._sqlite_ready = False

        # Attempt initial connection
        self.connect()

    def _activate_sqlite_fallback(self) -> bool:
        """Load/create durable local storage used when MySQL is unavailable."""
        try:
            self.fallback_path.parent.mkdir(parents=True, exist_ok=True)
            with self._sqlite_lock:
                conn = sqlite3.connect(self.fallback_path, timeout=10)
                try:
                    conn.execute("PRAGMA journal_mode=WAL")
                    conn.execute("PRAGMA synchronous=NORMAL")
                    conn.execute(
                        "CREATE TABLE IF NOT EXISTS fallback_records ("
                        "collection TEXT NOT NULL, id INTEGER NOT NULL, payload TEXT NOT NULL, "
                        "PRIMARY KEY (collection, id))"
                    )
                    conn.execute(
                        "CREATE INDEX IF NOT EXISTS idx_fallback_records_collection_id "
                        "ON fallback_records(collection, id DESC)"
                    )
                    conn.commit()
                    collections = {
                        "traffic": "_fallback_traffic",
                        "alerts": "_fallback_alerts",
                        "models": "_fallback_models",
                        "drift": "_fallback_drift",
                        "logs": "_fallback_logs",
                    }
                    for name, attribute in collections.items():
                        rows = conn.execute(
                            "SELECT id, payload FROM fallback_records WHERE collection=? ORDER BY id",
                            (name,),
                        ).fetchall()
                        setattr(self, attribute, [json.loads(payload) for _, payload in rows])
                        counter = {"traffic": "traffic", "alerts": "alerts", "models": "models", "drift": "drift", "logs": "logs"}[name]
                        self._id_counters[counter] = max((int(row_id) for row_id, _ in rows), default=0) + 1
                finally:
                    conn.close()
            self._sqlite_ready = True
            logger.info("Persistent SQLite fallback active at %s", self.fallback_path)
            return True
        except Exception as exc:
            self._sqlite_ready = False
            logger.error("Could not initialize SQLite fallback at %s: %s", self.fallback_path, exc)
            return False

    def _persist_fallback(self, collection: str, record: dict) -> None:
        """Persist one fallback row without blocking the in-memory fallback."""
        if not self._sqlite_ready:
            return
        try:
            payload = json.dumps(record, default=str, ensure_ascii=False)
            with self._sqlite_lock:
                conn = sqlite3.connect(self.fallback_path, timeout=10)
                try:
                    conn.execute(
                        "INSERT OR REPLACE INTO fallback_records(collection, id, payload) VALUES (?, ?, ?)",
                        (collection, int(record["id"]), payload),
                    )
                    conn.commit()
                finally:
                    conn.close()
        except Exception as exc:
            logger.error("Failed to persist %s record %s to SQLite fallback: %s", collection, record.get("id"), exc)

    def get_connection(self):
        """Establish and return a new MySQL connection if available."""
        if not self.is_mysql_active:
            return None
        try:
            import mysql.connector
            conn = mysql.connector.connect(
                host=self.host,
                port=self.port,
                user=self.user,
                password=self.password,
                database=self.database,
                connect_timeout=3
            )
            return conn
        except Exception as e:
            self.last_error = str(e)
            self.is_mysql_active = False
            self._activate_sqlite_fallback()
            logger.warning(f"MySQL connection lost: {e}. Switching to resilient fallback mode.")
            return None

    def connect(self) -> bool:
        """Attempt connection to MySQL server and verify database."""
        try:
            import mysql.connector
            conn = mysql.connector.connect(
                host=self.host,
                port=self.port,
                user=self.user,
                password=self.password,
                connect_timeout=2
            )
            cursor = conn.cursor()
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{self.database}` DEFAULT CHARACTER SET utf8mb4")
            conn.database = self.database
            self.is_mysql_active = True
            self.last_error = ""
            cursor.close()
            conn.close()
            logger.info(f"Connected to MySQL database '{self.database}' at {self.host}:{self.port}")
            self.init_schema()
            return True
        except Exception as e:
            self.is_mysql_active = False
            self.last_error = str(e)
            self._activate_sqlite_fallback()
            logger.info(f"MySQL not reachable ({e}). Persistent fallback activated.")
            self.insert_system_log(
                "WARNING", "Database",
                f"MySQL offline ({e}). Operating in resilient fallback mode."
            )
            return False

    def init_schema(self, schema_file: Path | None = None) -> bool:
        """Execute database/schema.sql on MySQL."""
        if not self.is_mysql_active:
            return False

        if schema_file is None:
            # Resolve relative to project root
            schema_file = Path(__file__).resolve().parent.parent / "database" / "schema.sql"

        if not schema_file.exists():
            logger.error(f"Schema file not found at: {schema_file}")
            return False

        try:
            conn = self.get_connection()
            if not conn:
                return False
            cursor = conn.cursor()

            with open(schema_file, "r", encoding="utf-8") as f:
                sql_content = f.read()

            # Split on semicolons, skip server-management and empty statements
            skip_prefixes = ("create database", "use ", "--", "/*")
            statements = sql_content.split(";")
            executed = 0
            for stmt in statements:
                cleaned = stmt.strip()
                if not cleaned:
                    continue
                lower = cleaned.lower()
                if any(lower.startswith(p) for p in skip_prefixes):
                    continue
                try:
                    cursor.execute(cleaned)
                    executed += 1
                except Exception as stmt_err:
                    # Log but continue — duplicate table errors are fine
                    logger.debug(f"Schema statement skipped: {stmt_err}")

            conn.commit()
            cursor.close()
            conn.close()
            logger.info(f"Database schema initialized successfully ({executed} statements executed).")
            return True
        except Exception as e:
            logger.error(f"Failed to execute schema SQL: {e}")
            self.last_error = str(e)
            return False

    def get_status(self) -> dict:
        """Get database health and mode status."""
        return {
            "connected": self.is_mysql_active,
            "mysql_connected": self.is_mysql_active,
            "storage_available": self.is_mysql_active or self._sqlite_ready,
            "persistent": self.is_mysql_active or self._sqlite_ready,
            "mode": "MySQL 8+" if self.is_mysql_active else ("SQLite Persistent Fallback" if self._sqlite_ready else "In-memory Fallback"),
            "host": self.host,
            "port": self.port,
            "database": self.database,
            "user": self.user,
            "last_error": self.last_error if not self.is_mysql_active else None,
            "fallback_path": str(self.fallback_path) if self._sqlite_ready else None,
            "records_stored": {
                "traffic": len(self._fallback_traffic),
                "alerts": len(self._fallback_alerts),
                "drift_events": len(self._fallback_drift),
                "models": len(self._fallback_models),
                "system_logs": len(self._fallback_logs),
            }
        }

    # -------------------------------------------------------------
    # TRAFFIC RECORDS
    # -------------------------------------------------------------
    def insert_traffic_record(self, data: dict) -> int:
        """Insert a single traffic record."""
        ts = data.get("timestamp") or datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        if self.is_mysql_active:
            conn = self.get_connection()
            if conn:
                try:
                    cursor = conn.cursor()
                    query = """
                        INSERT INTO traffic_records
                        (src_ip, dst_ip, src_port, dst_port, protocol, packet_count, byte_count,
                         flow_duration, packet_rate, byte_rate, tcp_flags, avg_packet_size, source_type, timestamp)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """
                    params = (
                        str(data.get("src_ip", "0.0.0.0")),
                        str(data.get("dst_ip", "0.0.0.0")),
                        int(data.get("src_port", 0)),
                        int(data.get("dst_port", 0)),
                        str(data.get("protocol", "TCP")),
                        int(data.get("packet_count", 0)),
                        int(data.get("byte_count", 0)),
                        float(data.get("flow_duration", 0.0)),
                        float(data.get("packet_rate", 0.0)),
                        float(data.get("byte_rate", 0.0)),
                        str(data.get("tcp_flags", "")),
                        float(data.get("avg_packet_size", 0.0)),
                        str(data.get("source_type", "CSV")),
                        ts
                    )
                    cursor.execute(query, params)
                    conn.commit()
                    rec_id = cursor.lastrowid
                    cursor.close()
                    conn.close()
                    return rec_id
                except Exception as e:
                    logger.error(f"MySQL insert_traffic_record failed: {e}")
                    self.last_error = str(e)
                    self.is_mysql_active = False
                    self._activate_sqlite_fallback()

        # Fallback
        rec_id = self._id_counters["traffic"]
        self._id_counters["traffic"] += 1
        record = dict(data)
        record["id"] = rec_id
        record["timestamp"] = ts
        self._fallback_traffic.append(record)
        self._persist_fallback("traffic", record)
        return rec_id

    def insert_traffic_records_batch(self, records: list[dict]) -> list[int]:
        """Insert a batch of traffic records."""
        ids = []
        for r in records:
            ids.append(self.insert_traffic_record(r))
        return ids

    def get_recent_traffic(self, limit: int = 50) -> list[dict]:
        """Retrieve most recent traffic records."""
        if self.is_mysql_active:
            conn = self.get_connection()
            if conn:
                try:
                    cursor = conn.cursor(dictionary=True)
                    cursor.execute(
                        "SELECT * FROM traffic_records ORDER BY timestamp DESC, id DESC LIMIT %s",
                        (limit,)
                    )
                    rows = cursor.fetchall()
                    cursor.close()
                    conn.close()
                    return rows
                except Exception as e:
                    logger.error(f"MySQL get_recent_traffic failed: {e}")

        # Fallback
        sorted_records = sorted(
            self._fallback_traffic,
            key=lambda x: str(x.get("timestamp", "")),
            reverse=True
        )
        return sorted_records[:limit]

    # -------------------------------------------------------------
    # ALERTS
    # -------------------------------------------------------------
    def insert_alert(self, alert: dict) -> int:
        """Insert a security alert."""
        ts = alert.get("created_at") or datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        top_features = alert.get("top_features_json")
        if isinstance(top_features, (dict, list)):
            top_features = json.dumps(top_features)
        elif not top_features:
            top_features = "[]"

        if self.is_mysql_active:
            conn = self.get_connection()
            if conn:
                try:
                    cursor = conn.cursor()
                    query = """
                        INSERT INTO alerts
                        (traffic_id, attack_type, threat_score, severity, confidence, anomaly_score,
                         status, explanation, top_features_json, src_ip, dst_ip, dst_port, protocol,
                         fp_verdict, fp_score, created_at)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """
                    params = (
                        alert.get("traffic_id"),
                        str(alert.get("attack_type", "Unknown")),
                        int(alert.get("threat_score", 0)),
                        str(alert.get("severity", "LOW")),
                        float(alert.get("confidence", 0.0)),
                        float(alert.get("anomaly_score", 0.0)),
                        str(alert.get("status", "NEW")),
                        str(alert.get("explanation", "")),
                        top_features,
                        str(alert.get("src_ip", "0.0.0.0")),
                        str(alert.get("dst_ip", "0.0.0.0")),
                        int(alert.get("dst_port", 0)),
                        str(alert.get("protocol", "TCP")),
                        str(alert.get("fp_verdict", "CONFIRMED_THREAT")),
                        float(alert.get("fp_score", 0.0)),
                        ts
                    )
                    cursor.execute(query, params)
                    conn.commit()
                    alert_id = cursor.lastrowid
                    cursor.close()
                    conn.close()
                    return alert_id
                except Exception as e:
                    logger.error(f"MySQL insert_alert failed: {e}")
                    self.last_error = str(e)
                    self.is_mysql_active = False
                    self._activate_sqlite_fallback()

        # Fallback
        alert_id = self._id_counters["alerts"]
        self._id_counters["alerts"] += 1
        record = dict(alert)
        record["id"] = alert_id
        record["created_at"] = ts
        record["top_features_json"] = top_features
        record.setdefault("status", "NEW")
        record.setdefault("fp_verdict", "CONFIRMED_THREAT")
        record.setdefault("fp_score", 0.0)
        self._fallback_alerts.append(record)
        self._persist_fallback("alerts", record)
        return alert_id

    def get_alerts(self, limit: int = 50, severity: str | None = None, status: str | None = None) -> list[dict]:
        """Retrieve alerts with optional filtering."""
        if self.is_mysql_active:
            conn = self.get_connection()
            if conn:
                try:
                    cursor = conn.cursor(dictionary=True)
                    query = "SELECT * FROM alerts WHERE 1=1"
                    params = []
                    if severity:
                        query += " AND severity = %s"
                        params.append(severity.upper())
                    if status:
                        query += " AND status = %s"
                        params.append(status.upper())
                    query += " ORDER BY created_at DESC, id DESC LIMIT %s"
                    params.append(limit)

                    cursor.execute(query, tuple(params))
                    rows = cursor.fetchall()
                    cursor.close()
                    conn.close()
                    return rows
                except Exception as e:
                    logger.error(f"MySQL get_alerts failed: {e}")

        # Fallback
        filtered = self._fallback_alerts
        if severity:
            filtered = [a for a in filtered if a.get("severity", "").upper() == severity.upper()]
        if status:
            filtered = [a for a in filtered if a.get("status", "").upper() == status.upper()]

        sorted_alerts = sorted(
            filtered,
            key=lambda x: str(x.get("created_at", "")),
            reverse=True
        )
        return sorted_alerts[:limit]

    def get_alert_by_id(self, alert_id: int) -> dict | None:
        """Retrieve single alert details by ID."""
        if self.is_mysql_active:
            conn = self.get_connection()
            if conn:
                try:
                    cursor = conn.cursor(dictionary=True)
                    cursor.execute("SELECT * FROM alerts WHERE id = %s", (alert_id,))
                    row = cursor.fetchone()
                    cursor.close()
                    conn.close()
                    return row
                except Exception as e:
                    logger.error(f"MySQL get_alert_by_id failed: {e}")

        # Fallback
        for a in self._fallback_alerts:
            if a.get("id") == alert_id:
                return dict(a)
        return None

    def resolve_alert(self, alert_id: int) -> bool:
        """Mark an alert as RESOLVED."""
        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        if self.is_mysql_active:
            conn = self.get_connection()
            if conn:
                try:
                    cursor = conn.cursor()
                    cursor.execute(
                        "UPDATE alerts SET status = 'RESOLVED', resolved_at = %s WHERE id = %s",
                        (now, alert_id)
                    )
                    conn.commit()
                    updated = cursor.rowcount > 0
                    cursor.close()
                    conn.close()
                    return updated
                except Exception as e:
                    logger.error(f"MySQL resolve_alert failed: {e}")

        # Fallback
        for a in self._fallback_alerts:
            if a.get("id") == alert_id:
                a["status"] = "RESOLVED"
                a["resolved_at"] = now
                self._persist_fallback("alerts", a)
                return True
        return False

    # -------------------------------------------------------------
    # DASHBOARD AGGREGATES
    # -------------------------------------------------------------
    def get_dashboard_stats(self) -> dict:
        """Get aggregate metrics for the dashboard."""
        alerts = self.get_alerts(limit=5000)
        recent_traffic = self.get_recent_traffic(limit=5000)

        total_traffic = len(recent_traffic)
        total_alerts = len(alerts)

        severity_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        attack_counts: dict[str, int] = {}

        for a in alerts:
            sev = a.get("severity", "LOW").upper()
            if sev in severity_counts:
                severity_counts[sev] += 1
            att = a.get("attack_type", "Unknown")
            attack_counts[att] = attack_counts.get(att, 0) + 1

        normal_traffic = max(0, total_traffic - total_alerts)

        # Timeline aggregates (grouped by hour or chronological)
        traffic_timeline: list[dict] = []
        threats_timeline: list[dict] = []

        # Chronological samples
        for t in reversed(recent_traffic[:20]):
            traffic_timeline.append({
                "time": str(t.get("timestamp", ""))[-8:],
                "packets": t.get("packet_count", 1)
            })

        for a in reversed(alerts[:20]):
            threats_timeline.append({
                "time": str(a.get("created_at", ""))[-8:],
                "score": a.get("threat_score", 0)
            })

        return {
            "total_traffic": total_traffic,
            "total_alerts": total_alerts,
            "critical_count": severity_counts["CRITICAL"],
            "high_count": severity_counts["HIGH"],
            "medium_count": severity_counts["MEDIUM"],
            "low_count": severity_counts["LOW"],
            "normal_traffic": normal_traffic,
            "severity_distribution": severity_counts,
            "attack_distribution": attack_counts,
            "traffic_timeline": traffic_timeline,
            "threats_timeline": threats_timeline,
        }

    # -------------------------------------------------------------
    # MODELS
    # -------------------------------------------------------------
    def insert_model_record(self, model_info: dict) -> int:
        """Insert model registration record."""
        ts = model_info.get("created_at") or datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        metrics = model_info.get("metrics_json")
        if isinstance(metrics, (dict, list)):
            metrics = json.dumps(metrics)

        if self.is_mysql_active:
            conn = self.get_connection()
            if conn:
                try:
                    cursor = conn.cursor()
                    query = """
                        INSERT INTO models
                        (name, version, model_type, file_path, accuracy, f1_score, metrics_json, is_active, created_at)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """
                    params = (
                        str(model_info.get("name")),
                        str(model_info.get("version")),
                        str(model_info.get("model_type")),
                        str(model_info.get("file_path")),
                        model_info.get("accuracy"),
                        model_info.get("f1_score"),
                        metrics,
                        bool(model_info.get("is_active", True)),
                        ts
                    )
                    cursor.execute(query, params)
                    conn.commit()
                    m_id = cursor.lastrowid
                    cursor.close()
                    conn.close()
                    return m_id
                except Exception as e:
                    logger.error(f"MySQL insert_model_record failed: {e}")
                    self.last_error = str(e)
                    self.is_mysql_active = False
                    self._activate_sqlite_fallback()

        # Fallback
        m_id = self._id_counters["models"]
        self._id_counters["models"] += 1
        rec = dict(model_info)
        rec["id"] = m_id
        rec["created_at"] = ts
        rec["metrics_json"] = metrics
        self._fallback_models.append(rec)
        self._persist_fallback("models", rec)
        return m_id

    def get_models(self) -> list[dict]:
        """Retrieve all registered models."""
        if self.is_mysql_active:
            conn = self.get_connection()
            if conn:
                try:
                    cursor = conn.cursor(dictionary=True)
                    cursor.execute("SELECT * FROM models ORDER BY id DESC")
                    rows = cursor.fetchall()
                    cursor.close()
                    conn.close()
                    return rows
                except Exception as e:
                    logger.error(f"MySQL get_models failed: {e}")

        return list(reversed(self._fallback_models))

    def get_active_models(self) -> list[dict]:
        """Retrieve active models."""
        if self.is_mysql_active:
            conn = self.get_connection()
            if conn:
                try:
                    cursor = conn.cursor(dictionary=True)
                    cursor.execute("SELECT * FROM models WHERE is_active = TRUE ORDER BY id DESC")
                    rows = cursor.fetchall()
                    cursor.close()
                    conn.close()
                    return rows
                except Exception as e:
                    logger.error(f"MySQL get_active_models failed: {e}")

        return [m for m in reversed(self._fallback_models) if m.get("is_active", True)]

    # -------------------------------------------------------------
    # DRIFT EVENTS
    # -------------------------------------------------------------
    def insert_drift_event(self, drift_data: dict) -> int:
        """Insert a drift calculation event."""
        ts = drift_data.get("created_at") or datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        if self.is_mysql_active:
            conn = self.get_connection()
            if conn:
                try:
                    cursor = conn.cursor()
                    query = """
                        INSERT INTO drift_events
                        (feature_name, baseline_value, current_value, drift_score, status, created_at)
                        VALUES (%s, %s, %s, %s, %s, %s)
                    """
                    params = (
                        str(drift_data.get("feature_name")),
                        float(drift_data.get("baseline_value", 0.0)),
                        float(drift_data.get("current_value", 0.0)),
                        float(drift_data.get("drift_score", 0.0)),
                        str(drift_data.get("status", "NO_DRIFT")),
                        ts
                    )
                    cursor.execute(query, params)
                    conn.commit()
                    d_id = cursor.lastrowid
                    cursor.close()
                    conn.close()
                    return d_id
                except Exception as e:
                    logger.error(f"MySQL insert_drift_event failed: {e}")
                    self.last_error = str(e)
                    self.is_mysql_active = False
                    self._activate_sqlite_fallback()

        # Fallback
        d_id = self._id_counters["drift"]
        self._id_counters["drift"] += 1
        rec = dict(drift_data)
        rec["id"] = d_id
        rec["created_at"] = ts
        self._fallback_drift.append(rec)
        self._persist_fallback("drift", rec)
        return d_id

    def get_drift_events(self, limit: int = 50) -> list[dict]:
        """Retrieve recent drift events."""
        if self.is_mysql_active:
            conn = self.get_connection()
            if conn:
                try:
                    cursor = conn.cursor(dictionary=True)
                    cursor.execute("SELECT * FROM drift_events ORDER BY id DESC LIMIT %s", (limit,))
                    rows = cursor.fetchall()
                    cursor.close()
                    conn.close()
                    return rows
                except Exception as e:
                    logger.error(f"MySQL get_drift_events failed: {e}")

        return list(reversed(self._fallback_drift))[:limit]

    # -------------------------------------------------------------
    # SYSTEM LOGS
    # -------------------------------------------------------------
    def insert_system_log(self, level: str, component: str, message: str) -> int:
        """Insert a system log record."""
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        if self.is_mysql_active:
            conn = self.get_connection()
            if conn:
                try:
                    cursor = conn.cursor()
                    query = """
                        INSERT INTO system_logs (level, component, message, created_at)
                        VALUES (%s, %s, %s, %s)
                    """
                    cursor.execute(query, (level, component, message, ts))
                    conn.commit()
                    log_id = cursor.lastrowid
                    cursor.close()
                    conn.close()
                    return log_id
                except Exception as e:
                    logger.error(f"MySQL insert_system_log failed: {e}")
                    self.last_error = str(e)
                    self.is_mysql_active = False
                    self._activate_sqlite_fallback()

        # Fallback
        log_id = self._id_counters["logs"]
        self._id_counters["logs"] += 1
        record = {
            "id": log_id,
            "level": level,
            "component": component,
            "message": message,
            "created_at": ts,
        }
        self._fallback_logs.append(record)
        self._persist_fallback("logs", record)
        return log_id

    def get_system_logs(self, limit: int = 50) -> list[dict]:
        """Retrieve recent system logs."""
        if self.is_mysql_active:
            conn = self.get_connection()
            if conn:
                try:
                    cursor = conn.cursor(dictionary=True)
                    cursor.execute("SELECT * FROM system_logs ORDER BY id DESC LIMIT %s", (limit,))
                    rows = cursor.fetchall()
                    cursor.close()
                    conn.close()
                    return rows
                except Exception as e:
                    logger.error(f"MySQL get_system_logs failed: {e}")

        return list(reversed(self._fallback_logs))[:limit]


# Global singleton instance
db_manager = DatabaseManager()
