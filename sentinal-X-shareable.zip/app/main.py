"""
Sentinel-X: FastAPI Application & API Foundation
Serves both backend REST APIs and the Vanilla JS / Jinja2 frontend operations dashboard.
Fully cross-platform, with graceful fallback and no OS-specific assumptions.
"""

import sys
import json
import io
import logging
import shutil
from datetime import datetime, timezone
from pathlib import Path
from contextlib import asynccontextmanager

logger = logging.getLogger("sentinel_x.main")

from fastapi import FastAPI, Request, HTTPException, UploadFile, File, Form, BackgroundTasks
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware

# Ensure app and project modules can be imported
APP_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = APP_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(PROJECT_ROOT / "setup") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "setup"))

try:
    from setup import detect_environment
except ImportError:
    import detect_environment

from app.config import (
    STATIC_DIR, TEMPLATES_DIR, UPLOADS_DIR
)
from app.database import db_manager
from app.traffic import parse_csv_data, parse_pcap_data, live_capture_manager
from app.model_manager import model_manager
from app.detection import detection_engine
from app.drift import calculate_feature_drift


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup and shutdown lifecycle management."""
    # Startup
    db_manager.insert_system_log(
        "INFO", "System", "Sentinel-X server initialized."
    )
    # Check if models are loaded
    if not model_manager.are_models_loaded():
        model_manager.load_models()

    yield
    # Shutdown
    live_capture_manager.stop_capture()
    db_manager.insert_system_log(
        "INFO", "System", "Sentinel-X server shutting down."
    )


app = FastAPI(
    title="Sentinel-X Intrusion Detection System",
    description="Cross-platform Autonomous Network Intrusion Detection System",
    version="1.0.0",
    lifespan=lifespan
)

# Enable CORS for local API access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files and HTML templates
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


# -----------------------------------------------------------------
# CORE HEALTH & SYSTEM STATUS ENDPOINTS
# -----------------------------------------------------------------

@app.get("/api/health")
async def health_check():
    """Health check endpoint confirming API availability."""
    return {
        "status": "ok",
        "service": "Sentinel-X",
        "timestamp": datetime.now(timezone.utc).isoformat()
    }


@app.get("/api/system/status")
async def system_status():
    """Detailed telemetry on host environment, hardware resources, MySQL, and models."""
    env = detect_environment.detect_all()
    db_status = db_manager.get_status()
    models_ready = model_manager.are_models_loaded()

    return {
        "status": "operational",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "operating_system": env["os"],
        "cpu": env["cpu"],
        "python": env["python"],
        "resources": env["resources"],
        "database": db_status,
        "models": {
            "ready": models_ready,
            "classifier_exists": model_manager.classifier is not None,
            "anomaly_detector_exists": model_manager.anomaly_detector is not None,
            "runtime_model": model_manager.metadata.get("runtime_model", "unknown"),
        },
        "live_capture": env["network_capture"],
        "logs": db_manager.get_system_logs(limit=25),
    }


# -----------------------------------------------------------------
# DASHBOARD API
# -----------------------------------------------------------------

@app.get("/api/dashboard")
async def get_dashboard_data():
    """Return complete telemetry, metrics, and chart series for the dashboard."""
    stats = db_manager.get_dashboard_stats()
    live_cap = detect_environment.detect_network_capture_capability()
    stats["live_capture"] = live_cap
    return stats


# -----------------------------------------------------------------
# ALERTS API
# -----------------------------------------------------------------

@app.get("/api/alerts")
async def list_alerts(limit: int = 50, severity: str | None = None, status: str | None = None):
    """List security alerts with optional severity and status filters."""
    alerts = db_manager.get_alerts(limit=limit, severity=severity, status=status)
    return {"count": len(alerts), "alerts": alerts}


@app.get("/api/alerts/{alert_id}")
async def get_alert(alert_id: int):
    """Retrieve full details, telemetry, and explanation for an alert."""
    alert = db_manager.get_alert_by_id(alert_id)
    if not alert:
        raise HTTPException(status_code=404, detail=f"Alert #{alert_id} not found")
    
    # Parse top features if string
    if isinstance(alert.get("top_features_json"), str):
        try:
            alert["top_features"] = json.loads(alert["top_features_json"])
        except Exception:
            alert["top_features"] = []
    else:
        alert["top_features"] = alert.get("top_features_json", [])

    return alert


@app.post("/api/alerts/{alert_id}/resolve")
async def resolve_alert_endpoint(alert_id: int):
    """Mark an alert as resolved."""
    success = db_manager.resolve_alert(alert_id)
    if not success:
        raise HTTPException(status_code=404, detail=f"Alert #{alert_id} could not be resolved or not found")
    db_manager.insert_system_log("INFO", "Alerts", f"Alert #{alert_id} resolved by analyst.")
    return {"success": True, "alert_id": alert_id, "status": "RESOLVED"}


# -----------------------------------------------------------------
# TRAFFIC & INGESTION API
# -----------------------------------------------------------------

@app.post("/api/traffic/upload")
async def upload_traffic_file(file: UploadFile = File(...)):
    """
    Upload and process a network traffic file (CSV or PCAP/PCAPNG).
    Executes detection pipeline and persists alerts and traffic records.
    """
    filename = file.filename or "upload"
    content = await file.read()

    # Save to data/uploads
    dest_path = UPLOADS_DIR / f"{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}_{filename}"
    with open(dest_path, "wb") as f:
        f.write(content)

    lower_name = filename.lower()
    if lower_name.endswith(".csv"):
        flows = parse_csv_data(content)
    elif lower_name.endswith((".pcap", ".pcapng", ".cap")):
        flows = parse_pcap_data(content)
    else:
        # Try CSV as default fallback
        try:
            flows = parse_csv_data(content)
        except Exception:
            flows = parse_pcap_data(content)

    if not flows:
        return {
            "success": False,
            "filename": filename,
            "message": "No valid network flow records could be extracted from file."
        }

    # Run detection pipeline
    results = detection_engine.analyze_flows(flows, persist=True)
    alerts_created = sum(1 for r in results if r["is_alert"])

    # Calculate drift if flow batch has sufficient samples
    drift_report = calculate_feature_drift(flows, persist=True)

    db_manager.insert_system_log(
        "INFO", "Traffic",
        f"Uploaded {filename}: processed {len(flows)} flows, generated {alerts_created} alerts."
    )

    return {
        "success": True,
        "filename": filename,
        "total_flows": len(flows),
        "alerts_generated": alerts_created,
        "drift_status": drift_report.get("overall_status"),
        "results_sample": results[:10],
    }


@app.post("/api/traffic/analyze")
async def analyze_traffic_payload(payload: dict):
    """Analyze a batch of raw flow records passed as JSON."""
    flows = payload.get("flows", [])
    if not flows and "flow" in payload:
        flows = [payload["flow"]]

    if not flows:
        raise HTTPException(status_code=400, detail="Missing 'flows' or 'flow' in request body")

    persist = bool(payload.get("persist", True))
    results = detection_engine.analyze_flows(flows, persist=persist)
    return {"total": len(results), "results": results}


@app.get("/api/traffic/recent")
async def get_recent_traffic_endpoint(limit: int = 50):
    """Retrieve recently logged traffic flow records."""
    records = db_manager.get_recent_traffic(limit=limit)
    return {"count": len(records), "records": records}


# -----------------------------------------------------------------
# DETECTION API
# -----------------------------------------------------------------

@app.post("/api/detection/predict")
async def predict_single_flow(flow: dict):
    """Direct inference endpoint for a single flow dictionary."""
    result = detection_engine.analyze_flow(flow, persist=False)
    return result


# -----------------------------------------------------------------
# MODELS API
# -----------------------------------------------------------------

@app.get("/api/models")
async def get_models_list():
    """List all registered models from database."""
    models = db_manager.get_models()
    return {"count": len(models), "models": models}


@app.get("/api/models/active")
async def get_active_models_info():
    """Get active model parameters, accuracy, and memory status."""
    status = model_manager.get_status()
    importances = model_manager.get_feature_importances()
    baseline = model_manager.get_baseline_stats()
    return {
        "model_status": status,
        "feature_importances": importances,
        "baseline_summary": {k: v.get("median") for k, v in baseline.items()},
        "training_report": model_manager.metadata.get("training", {}),
    }


@app.post("/api/models/train")
async def trigger_model_training(background_tasks: BackgroundTasks):
    """Trigger background model retraining pipeline."""
    from scripts.train_models import train_and_save_models

    def train_task():
        try:
            train_and_save_models()
            model_manager.load_models()
        except Exception as e:
            db_manager.insert_system_log("ERROR", "ModelManager", f"Retraining failed: {e}")

    background_tasks.add_task(train_task)
    return {"success": True, "message": "Model retraining task initiated."}


@app.post("/api/models/train/labeled")
async def train_labeled_model(background_tasks: BackgroundTasks, file: UploadFile = File(...)):
    """Train from a labeled flow CSV while retaining a held-out evaluation set."""
    from app.traffic import parse_csv_data
    from scripts.train_models import canonicalize_label

    filename = Path(file.filename or "training.csv").name
    if not filename.lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="Training data must be a CSV file")
    content = await file.read()
    try:
        records = parse_csv_data(content)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not read training CSV: {exc}") from exc
    label_counts: dict[str, int] = {}
    for record in records:
        label = canonicalize_label(record.get("label", ""))
        if label:
            label_counts[label] = label_counts.get(label, 0) + 1
    labels = set(label_counts)
    if len(records) < 20 or len(labels) < 2:
        raise HTTPException(
            status_code=400,
            detail="CSV needs at least 20 flows and labels from at least two supported classes",
        )
    if "Normal" not in labels:
        raise HTTPException(
            status_code=400,
            detail="Labeled training CSV must include Normal or Benign flows for anomaly calibration",
        )
    underrepresented = [label for label, count in label_counts.items() if count < 5]
    if underrepresented:
        raise HTTPException(
            status_code=400,
            detail=f"At least five labeled flows are required per class; too few for: {underrepresented}",
        )

    training_path = UPLOADS_DIR / f"{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}_training_{filename}"
    training_path.write_bytes(content)

    def train_task():
        try:
            from scripts.train_models import train_and_save_models
            train_and_save_models(training_path)
            model_manager.load_models()
        except Exception as exc:
            db_manager.insert_system_log("ERROR", "ModelManager", f"Labeled retraining failed: {exc}")

    background_tasks.add_task(train_task)
    return {
        "success": True,
        "message": "Labeled training started with a stratified held-out evaluation split.",
        "samples": len(records),
        "classes": sorted(labels),
        "filename": filename,
        "training_id": training_path.name,
    }


# -----------------------------------------------------------------
# LIVE CAPTURE API
# -----------------------------------------------------------------

@app.post("/api/traffic/capture/start")
async def start_live_capture(payload: dict | None = None):
    """
    Start live packet capture on an optional network interface.
    Requires elevated privileges (CAP_NET_RAW on Linux, Npcap on Windows).
    Returns 403 if permissions are insufficient.
    """
    iface: str | None = None
    if payload:
        iface = payload.get("interface") or None

    available, reason = live_capture_manager.is_available()
    if not available:
        raise HTTPException(
            status_code=403,
            detail=f"Live packet capture unavailable: {reason}"
        )

    def flow_callback(pkt):
        """Process captured packets through the detection pipeline."""
        from scapy.layers.inet import IP, TCP, UDP, ICMP
        from scapy.layers.inet6 import IPv6

        if not (pkt.haslayer(IP) or pkt.haslayer(IPv6)):
            return
        ip_layer = pkt.getlayer(IP) if pkt.haslayer(IP) else pkt.getlayer(IPv6)
        src_ip = str(ip_layer.src)
        dst_ip = str(ip_layer.dst)

        proto = "OTHER"
        src_port = 0
        dst_port = 0
        if pkt.haslayer(TCP):
            proto = "TCP"
            src_port = int(pkt[TCP].sport)
            dst_port = int(pkt[TCP].dport)
        elif pkt.haslayer(UDP):
            proto = "UDP"
            src_port = int(pkt[UDP].sport)
            dst_port = int(pkt[UDP].dport)
        elif pkt.haslayer(ICMP):
            proto = "ICMP"

        pkt_len = len(pkt)
        flow = {
            "src_ip": src_ip,
            "dst_ip": dst_ip,
            "src_port": src_port,
            "dst_port": dst_port,
            "protocol": proto,
            "packet_count": 1,
            "byte_count": pkt_len,
            "flow_duration": 0.0,
            "packet_rate": 0.0,
            "byte_rate": 0.0,
            "tcp_flags": "",
            "avg_packet_size": float(pkt_len),
            "source_type": "LIVE",
        }
        try:
            detection_engine.analyze_flow(flow, persist=True)
        except Exception as exc:
            logger.error("Live capture detection error: %s", exc)

    result = live_capture_manager.start_capture(iface=iface, callback=flow_callback)
    if not result.get("success"):
        raise HTTPException(status_code=403, detail=result.get("message", "Live capture could not be started."))
    db_manager.insert_system_log(
        "INFO", "LiveCapture",
        f"Live capture started with {result.get('provider', 'Npcap')} on interface: {iface or 'default'}."
    )
    return result


@app.post("/api/traffic/capture/stop")
async def stop_live_capture():
    """Stop the running live packet capture session."""
    result = live_capture_manager.stop_capture()
    db_manager.insert_system_log(
        "INFO", "LiveCapture",
        f"Live capture stopped. Packets captured: {live_capture_manager.packets_captured}."
    )
    return result


@app.get("/api/traffic/capture/status")
async def get_capture_status():
    """Return the current live capture session state."""
    available, reason = live_capture_manager.is_available()
    return {
        "is_capturing": live_capture_manager.is_capturing,
        "packets_captured": live_capture_manager.packets_captured,
        "available": available,
        "reason": reason,
        "provider": live_capture_manager.provider,
    }


# -----------------------------------------------------------------
# DRIFT API
# -----------------------------------------------------------------

@app.get("/api/drift")
async def get_drift_report():
    """Retrieve recent drift events and evaluate current traffic drift."""
    recent_events = db_manager.get_drift_events(limit=50)
    recent_flows = db_manager.get_recent_traffic(limit=100)

    drift_eval = calculate_feature_drift(recent_flows, persist=False)
    return {
        "current_evaluation": drift_eval,
        "historical_events": recent_events,
    }


# -----------------------------------------------------------------
# FRONTEND TEMPLATE ROUTES
# -----------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
async def page_dashboard(request: Request):
    """Main Cyber Defense Operations Dashboard."""
    return templates.TemplateResponse(request, "index.html")


@app.get("/alerts", response_class=HTMLResponse)
async def page_alerts(request: Request):
    """Alerts monitoring and triage view."""
    return templates.TemplateResponse(request, "alerts.html")


@app.get("/alerts/{alert_id}", response_class=HTMLResponse)
async def page_alert_details(request: Request, alert_id: int):
    """Detailed alert explanation and flow breakdown view."""
    alert = db_manager.get_alert_by_id(alert_id)
    if not alert:
        return RedirectResponse(url="/alerts")
    return templates.TemplateResponse(request, "alert_details.html", {"alert": alert})


@app.get("/traffic", response_class=HTMLResponse)
async def page_traffic(request: Request):
    """Traffic ingestion and flow inspector."""
    return templates.TemplateResponse(request, "traffic.html")


@app.get("/models", response_class=HTMLResponse)
async def page_models(request: Request):
    """Model management and retraining view."""
    return templates.TemplateResponse(request, "models.html")


@app.get("/system", response_class=HTMLResponse)
async def page_system(request: Request):
    """System diagnostics, health, and logs."""
    return templates.TemplateResponse(request, "system.html")
