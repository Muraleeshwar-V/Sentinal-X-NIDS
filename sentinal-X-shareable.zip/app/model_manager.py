"""
Sentinel-X: Model Manager Module
Loads the NumPy-only classifier and anomaly scorer and manages their lifecycle.
"""

import logging
from pathlib import Path
from typing import Any
import joblib
import numpy as np

from app.config import (
    MODEL_DIR, CLASSIFIER_MODEL_PATH, ANOMALY_MODEL_PATH,
    PREPROCESSOR_METADATA_PATH
)
from app.preprocessing import FEATURE_COLUMNS
from app.lightweight_models import LightweightAnomalyDetector, LightweightClassifier
from app.database import db_manager

logger = logging.getLogger("sentinel_x.models")


class ModelManager:
    """Coordinates ML model loading, inference status, and lifecycle."""

    def __init__(self):
        self.classifier = None
        self.anomaly_detector = None
        self.fp_filter_model = None        # GBM false-positive meta-learner
        self.metadata = {}
        self.load_models()

    def are_models_loaded(self) -> bool:
        """Check if both classifier and anomaly detector are active in memory."""
        return self.classifier is not None and self.anomaly_detector is not None

    def load_models(self) -> bool:
        """Load serialized models from disk into memory."""
        try:
            if PREPROCESSOR_METADATA_PATH.exists():
                # The metadata artifact is plain Python data. Avoid importing
                # serialized sklearn estimators, which require blocked native
                # extensions on some managed Windows systems.
                self.metadata = joblib.load(PREPROCESSOR_METADATA_PATH)
                self.classifier = LightweightClassifier(self.metadata.get("classifier_model"))
                self.anomaly_detector = LightweightAnomalyDetector(
                    self.metadata.get("baseline_stats", {})
                )
                self.fp_filter_model = None
                logger.info("NumPy-only flow classifier and anomaly scorer loaded.")

                # Ensure DB has model registrations
                if len(db_manager.get_models()) == 0:
                    training_metrics = self.metadata.get("training", {}).get("held_out_metrics", {})
                    class_metrics = training_metrics.get("per_class", {}).values()
                    macro_f1 = (
                        sum(float(item.get("f1", 0.0)) for item in class_metrics) / len(class_metrics)
                        if class_metrics else None
                    )
                    db_manager.insert_model_record({
                        "name": "NumPy Flow Classifier",
                        "version": "2.0.0",
                        "model_type": "LightweightClassifier",
                        "file_path": "built-in",
                        "accuracy": training_metrics.get("accuracy"),
                        "f1_score": macro_f1,
                        "metrics_json": training_metrics or {"runtime": "NumPy-only"},
                        "is_active": True,
                    })
                    db_manager.insert_model_record({
                        "name": "Baseline Anomaly Scorer",
                        "version": "2.0.0",
                        "model_type": "LightweightAnomalyDetector",
                        "file_path": "built-in",
                        "accuracy": None,
                        "f1_score": None,
                        "metrics_json": {"contamination": 0.05},
                        "is_active": True,
                    })

                logger.info("Machine learning models and preprocessor metadata loaded successfully.")
                return True
            else:
                logger.warning("Model files not found on disk. Training required.")
                return False
        except Exception as e:
            logger.error(f"Failed to load machine learning models: {e}")
            return False

    def get_feature_importances(self) -> dict[str, float]:
        """Return feature weights for the currently active classifier."""
        if self.metadata and "feature_importances" in self.metadata:
            return self.metadata["feature_importances"]
        if self.classifier is not None and hasattr(self.classifier, "feature_importances_"):
            return dict(zip(FEATURE_COLUMNS, [float(v) for v in self.classifier.feature_importances_]))
        return {col: 1.0 / len(FEATURE_COLUMNS) for col in FEATURE_COLUMNS}

    def get_baseline_stats(self) -> dict[str, dict]:
        """Return normal traffic baseline statistics."""
        return self.metadata.get("baseline_stats", {})

    def get_classes(self) -> list[str]:
        """Return classification target categories."""
        if self.classifier is not None and hasattr(self.classifier, "classes_"):
            return list(self.classifier.classes_)
        return ["Normal", "DDoS", "PortScan", "BruteForce", "Malware/C2"]

    def get_status(self) -> dict:
        """Return status information for all models."""
        active_db_models = db_manager.get_active_models()
        return {
            "loaded": self.are_models_loaded(),
            "classifier_ready": self.classifier is not None,
            "anomaly_detector_ready": self.anomaly_detector is not None,
            "fp_filter_ready": self.fp_filter_model is not None,
            "classes": self.get_classes(),
            "feature_columns": FEATURE_COLUMNS,
            "database_records": active_db_models,
        }


# Global singleton instance
model_manager = ModelManager()
