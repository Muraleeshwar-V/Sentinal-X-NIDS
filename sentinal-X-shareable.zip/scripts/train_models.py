"""
Sentinel-X: Machine Learning Model Training Script
Builds a normal-traffic baseline for the NumPy-only classifier and anomaly scorer.
Serializes baseline statistics and feature weights using joblib.
"""

import sys
import logging
import argparse
from pathlib import Path
import numpy as np
import joblib

# Resolve project paths
SCRIPTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPTS_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from app.config import (
    MODEL_DIR, PREPROCESSOR_METADATA_PATH
)
from app.preprocessing import FEATURE_COLUMNS
from app.database import db_manager
from app.lightweight_models import LightweightClassifier
from app.training import evaluate_predictions, predict_softmax, train_softmax_classifier
from app.traffic import parse_csv_data

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("sentinel_x.training")


def generate_synthetic_dataset(num_samples: int = 5000, random_state: int = 42) -> tuple[np.ndarray, np.ndarray]:
    """
    Generate mathematically consistent network flow telemetry across 5 classes:
    - Normal (60%)
    - DDoS (15%)
    - PortScan (10%)
    - BruteForce (10%)
    - Malware/C2 (5%)
    """
    np.random.seed(random_state)
    records = []
    labels = []

    classes_distribution = [
        ("Normal", int(num_samples * 0.60)),
        ("DDoS", int(num_samples * 0.15)),
        ("PortScan", int(num_samples * 0.10)),
        ("BruteForce", int(num_samples * 0.10)),
        ("Malware/C2", int(num_samples * 0.05)),
    ]

    for label, count in classes_distribution:
        for _ in range(count):
            if label == "Normal":
                dst_port = np.random.choice([80, 443, 53, 8080, 22, 123, 8443], p=[0.3, 0.4, 0.15, 0.05, 0.04, 0.03, 0.03])
                proto_num = 17 if dst_port == 53 else 6
                packet_count = int(np.random.exponential(scale=25) + 5)
                byte_count = packet_count * int(np.random.normal(loc=650, scale=200))
                byte_count = max(byte_count, packet_count * 64)
                flow_duration = float(np.random.exponential(scale=2.5) + 0.1)
                packet_rate = packet_count / flow_duration
                byte_rate = byte_count / flow_duration
                avg_packet_size = byte_count / packet_count
                flag_syn = 1.0 if proto_num == 6 else 0.0
                flag_ack = 1.0 if proto_num == 6 and packet_count > 3 else 0.0
                flag_fin = 1.0 if proto_num == 6 and np.random.rand() > 0.4 else 0.0
                flag_rst = 1.0 if np.random.rand() < 0.02 else 0.0

            elif label == "DDoS":
                dst_port = np.random.choice([80, 443, 53, 8080])
                proto_num = np.random.choice([6, 17], p=[0.7, 0.3])
                packet_count = int(np.random.normal(loc=1500, scale=400))
                packet_count = max(packet_count, 300)
                byte_count = packet_count * int(np.random.normal(loc=120, scale=30))
                flow_duration = float(np.random.uniform(0.05, 1.2))
                packet_rate = packet_count / flow_duration
                byte_rate = byte_count / flow_duration
                avg_packet_size = byte_count / packet_count
                flag_syn = 1.0
                flag_ack = 0.0 if np.random.rand() > 0.3 else 1.0  # SYN flood pattern
                flag_fin = 0.0
                flag_rst = 1.0 if np.random.rand() > 0.6 else 0.0

            elif label == "PortScan":
                dst_port = int(np.random.randint(1, 65535))
                proto_num = 6
                packet_count = int(np.random.randint(1, 4))
                byte_count = packet_count * int(np.random.randint(40, 64))
                flow_duration = float(np.random.uniform(0.001, 0.05))
                packet_rate = packet_count / flow_duration
                byte_rate = byte_count / flow_duration
                avg_packet_size = byte_count / packet_count
                flag_syn = 1.0
                flag_ack = 0.0
                flag_fin = 0.0
                flag_rst = 1.0 if np.random.rand() > 0.4 else 0.0

            elif label == "BruteForce":
                dst_port = np.random.choice([22, 21, 3389, 445])
                proto_num = 6
                packet_count = int(np.random.normal(loc=45, scale=10))
                packet_count = max(packet_count, 15)
                byte_count = packet_count * int(np.random.normal(loc=180, scale=40))
                flow_duration = float(np.random.uniform(1.0, 4.0))
                packet_rate = packet_count / flow_duration
                byte_rate = byte_count / flow_duration
                avg_packet_size = byte_count / packet_count
                flag_syn = 1.0
                flag_ack = 1.0
                flag_fin = 1.0 if np.random.rand() > 0.5 else 0.0
                flag_rst = 1.0 if np.random.rand() > 0.5 else 0.0

            else:  # Malware/C2
                dst_port = np.random.choice([4444, 8888, 9001, 1337, 50050])
                proto_num = 6
                packet_count = int(np.random.randint(8, 25))
                byte_count = packet_count * int(np.random.randint(50, 150))
                flow_duration = float(np.random.uniform(15.0, 120.0))  # Long duration beacon
                packet_rate = packet_count / flow_duration
                byte_rate = byte_count / flow_duration
                avg_packet_size = byte_count / packet_count
                flag_syn = 1.0
                flag_ack = 1.0
                flag_fin = 0.0
                flag_rst = 0.0

            records.append([
                float(dst_port),
                float(proto_num),
                float(packet_count),
                float(byte_count),
                float(flow_duration),
                float(packet_rate),
                float(byte_rate),
                float(avg_packet_size),
                float(flag_syn),
                float(flag_ack),
                float(flag_fin),
                float(flag_rst),
            ])
            labels.append(label)

    X = np.asarray(records, dtype=np.float32)
    y = np.asarray(labels)

    # ----------------------------------------------------------------
    # Include boundary cases so the classifier is evaluated on normal flows
    # that partially overlap with attack patterns.
    # ----------------------------------------------------------------
    np.random.seed(random_state + 57)
    boundary_records = []
    boundary_labels  = []
    n_boundary = int(num_samples * 0.12)

    for _ in range(n_boundary // 4):
        # Busy-server Normal: high packet_rate like DDoS but large avg_packet_size
        pc   = int(np.random.normal(loc=400, scale=100)); pc = max(pc, 10)
        dur  = float(np.random.uniform(0.5, 3.0))
        bc   = pc * int(np.random.normal(loc=600, scale=150)); bc = max(bc, pc * 64)
        boundary_records.append([443.0, 6.0, float(pc), float(bc), dur,
                                  pc/dur, bc/dur, bc/pc, 1.0, 1.0, 1.0, 0.0])
        boundary_labels.append("Normal")

    for _ in range(n_boundary // 4):
        # SSH session: same port/packet range as BruteForce but has FIN and no RST
        pc   = int(np.random.normal(loc=40, scale=8)); pc = max(pc, 10)
        dur  = float(np.random.uniform(1.5, 4.0))
        bc   = pc * int(np.random.normal(loc=200, scale=50)); bc = max(bc, pc * 64)
        boundary_records.append([22.0, 6.0, float(pc), float(bc), dur,
                                  pc/dur, bc/dur, bc/pc, 1.0, 1.0, 1.0, 0.0])
        boundary_labels.append("Normal")

    for _ in range(n_boundary // 4):
        # Long-duration low-rate HTTPS: overlaps Malware/C2 on duration/rate
        pc   = int(np.random.randint(10, 30))
        dur  = float(np.random.uniform(12.0, 90.0))
        bc   = pc * int(np.random.normal(loc=650, scale=200)); bc = max(bc, pc * 64)
        boundary_records.append([443.0, 6.0, float(pc), float(bc), dur,
                                  pc/dur, bc/dur, bc/pc, 1.0, 1.0, 0.0, 0.0])
        boundary_labels.append("Normal")

    for _ in range(n_boundary // 4):
        # Single-packet probe to ephemeral port: overlaps PortScan on packet_count/duration
        pc   = int(np.random.randint(1, 4))
        dur  = float(np.random.uniform(0.01, 0.08))
        port = int(np.random.randint(1024, 65535))
        bc   = pc * int(np.random.randint(60, 120))
        boundary_records.append([float(port), 6.0, float(pc), float(bc), dur,
                                  pc/dur, bc/dur, bc/pc, 1.0, 0.0, 0.0, 0.0])
        boundary_labels.append("Normal")

    X_boundary = np.asarray(boundary_records, dtype=np.float32)
    y_boundary = np.asarray(boundary_labels)
    X = np.concatenate([X, X_boundary], axis=0)
    y = np.concatenate([y, y_boundary], axis=0)

    return X, y


def canonicalize_label(value: str) -> str | None:
    """Map common IDS label spellings to Sentinel-X's five traffic classes."""
    key = "".join(char for char in str(value).strip().lower() if char.isalnum())
    if key in {"normal", "benign", "benigntraffic", "background"}:
        return "Normal"
    if key.startswith(("ddos", "dos")) or key == "denialofservice":
        return "DDoS"
    if "scan" in key or key == "nmap":
        return "PortScan"
    if "brute" in key or "patator" in key or key == "passwordattack":
        return "BruteForce"
    if any(token in key for token in ("malware", "bot", "infiltration", "commandandcontrol")) or key == "c2":
        return "Malware/C2"
    return None


def load_labeled_csv(path: Path) -> tuple[np.ndarray, np.ndarray]:
    records = parse_csv_data(path)
    usable = [(record, canonicalize_label(record.get("label", ""))) for record in records]
    usable = [(record, label) for record, label in usable if label]
    if len(usable) < 20 or len({label for _, label in usable}) < 2:
        raise ValueError("Labeled CSV needs at least 20 usable flows from at least two supported classes")
    from app.preprocessing import record_to_feature_vector
    X = np.stack([record_to_feature_vector(record) for record, _ in usable])
    y = np.asarray([label for _, label in usable])
    return X, y


def stratified_split(X: np.ndarray, y: np.ndarray, test_fraction: float = 0.2, seed: int = 42):
    rng = np.random.default_rng(seed)
    train_idx, test_idx = [], []
    for label in np.unique(y):
        indices = np.flatnonzero(y == label)
        rng.shuffle(indices)
        test_count = max(1, int(round(len(indices) * test_fraction))) if len(indices) > 1 else 0
        test_idx.extend(indices[:test_count])
        train_idx.extend(indices[test_count:])
    return np.asarray(train_idx), np.asarray(test_idx)


def train_and_save_models(labeled_csv: str | Path | None = None):
    """Train and evaluate a portable NumPy classifier and normal baseline."""
    if labeled_csv:
        logger.info("Loading labeled flows from %s", labeled_csv)
        X, y = load_labeled_csv(Path(labeled_csv))
        dataset_source = str(Path(labeled_csv).resolve())
    else:
        logger.info("Generating synthetic network flow training data...")
        X, y = generate_synthetic_dataset(num_samples=6000)
        dataset_source = "synthetic"

    if "Normal" not in y:
        raise ValueError("Labeled training data must include Normal/Benign flows for anomaly calibration")

    train_idx, test_idx = stratified_split(X, y)
    class_counts = {label: int(np.sum(y == label)) for label in np.unique(y)}
    rare_classes = [label for label, count in class_counts.items() if count < 5]
    if rare_classes:
        raise ValueError(f"At least five labeled flows are required for each class; too few for: {rare_classes}")
    if len(test_idx) == 0 or len(np.unique(y[train_idx])) < 2:
        raise ValueError("Training data needs at least two classes with multiple samples each")
    candidate = train_softmax_classifier(X[train_idx], y[train_idx])
    trained_pred, _ = predict_softmax(candidate, X[test_idx])
    trained_metrics = evaluate_predictions(y[test_idx], trained_pred, candidate["classes"])

    baseline_classifier = LightweightClassifier()
    baseline_pred = baseline_classifier.predict(X[test_idx])
    baseline_metrics = evaluate_predictions(y[test_idx], baseline_pred, list(baseline_classifier.classes_))

    # Balance overall correctness and class coverage. A learned model that
    # raises minority recall by causing many benign false positives should
    # not replace a better calibrated rule model.
    trained_quality = 0.65 * trained_metrics["accuracy"] + 0.35 * trained_metrics["balanced_accuracy"]
    rules_quality = 0.65 * baseline_metrics["accuracy"] + 0.35 * baseline_metrics["balanced_accuracy"]
    use_trained = trained_quality > rules_quality
    selected_metrics = trained_metrics if use_trained else baseline_metrics
    selected_model = train_softmax_classifier(X, y) if use_trained else None
    logger.info(
        "Held-out accuracy: %.2f%%, balanced accuracy: %.2f%% (selected=%s)",
        selected_metrics["accuracy"] * 100,
        selected_metrics["balanced_accuracy"] * 100,
        "trained" if use_trained else "rules",
    )

    train_normal = X[train_idx][y[train_idx] == "Normal"]
    if not len(train_normal):
        train_normal = X[train_idx]
    stats = {}
    for index, name in enumerate(FEATURE_COLUMNS):
        values = train_normal[:, index].astype(float)
        std = float(np.std(values, ddof=1)) if values.size > 1 else 1.0
        stats[name] = {
            "median": float(np.median(values)),
            "mean": float(np.mean(values)),
            "std": std if std > 0 else 1.0,
            "q25": float(np.quantile(values, 0.25)),
            "q75": float(np.quantile(values, 0.75)),
        }

    weights = np.array([0.08, 0.05, 0.10, 0.10, 0.08, 0.16, 0.12, 0.10, 0.06, 0.05, 0.04, 0.06])
    weights /= weights.sum()
    if selected_model:
        learned_importance = np.sum(np.abs(np.asarray(selected_model["weights"])), axis=1)
        if learned_importance.sum() > 0:
            weights = learned_importance / learned_importance.sum()
    metadata = {
        "feature_columns": FEATURE_COLUMNS,
        "classes": selected_model["classes"] if selected_model else ["BruteForce", "DDoS", "Malware/C2", "Normal", "PortScan"],
        "feature_importances": dict(zip(FEATURE_COLUMNS, weights.tolist())),
        "baseline_stats": stats,
        "classifier_model": selected_model,
        "runtime_model": "numpy_softmax_v1" if selected_model else "numpy_rules_v1",
        "training": {
            "source": dataset_source,
            "selected_model": "trained" if use_trained else "rules",
            "held_out_metrics": selected_metrics,
            "trained_candidate_metrics": trained_metrics,
            "rules_baseline_metrics": baseline_metrics,
        },
    }
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(metadata, PREPROCESSOR_METADATA_PATH)
    db_manager.insert_model_record({
        "name": "NumPy Flow Classifier",
        "version": "2.0.0",
        "model_type": metadata["runtime_model"],
        "file_path": str(PREPROCESSOR_METADATA_PATH.name),
        "accuracy": selected_metrics["accuracy"],
        "f1_score": float(np.mean([row["f1"] for row in selected_metrics["per_class"].values()])),
        "metrics_json": selected_metrics,
        "is_active": True,
    })
    db_manager.insert_system_log("INFO", "ModelManager", "Trained portable flow classifier and refreshed baseline.")
    logger.info("Baseline metadata saved to %s", PREPROCESSOR_METADATA_PATH)
    return {
        "runtime_model": metadata["runtime_model"],
        "baseline_features": len(stats),
        "selected_model": "trained" if use_trained else "rules",
        "held_out_metrics": selected_metrics,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train Sentinel-X from synthetic or labeled flow data")
    parser.add_argument("--data", type=Path, help="Labeled flow CSV (requires a label/attack_type column)")
    args = parser.parse_args()
    train_and_save_models(args.data)
