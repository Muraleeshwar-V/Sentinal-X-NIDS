# Sentinel-X: setup on another Windows laptop

This guide sets up Sentinel-X as a normal user. MySQL and live packet capture are optional. If MySQL is not available, the app stores data in `data/sentinel_x.sqlite3`. PCAP/PCAPNG file analysis does not require live capture permissions.

## 1. Copy the project

Copy and extract the shared `sentinal-X-shareable.zip` to a folder you can write to, such as:

```text
C:\Users\<your-name>\Projects\sentinal-X-shareable
```

Avoid `Program Files` and other protected folders because the app needs to write its local database, uploaded files, and logs.

## 2. Install Python

Install Python 3.11 or newer for Windows from [python.org](https://www.python.org/downloads/windows/). During installation, enable **Add python.exe to PATH**. Open a new PowerShell window and check:

```powershell
py --version
```

If `py` is not recognized, close and reopen PowerShell after installing Python, or use the `python` command in the remaining steps.

## 3. Install project dependencies

In PowerShell, change to the extracted project directory. Run the provided setup program:

```powershell
cd "$HOME\Projects\sentinal-X-shareable"
py setup\setup.py
```

The setup program creates `.venv`, installs the packages from `requirements.txt` into that local environment, verifies imports, and creates `.env` from `.env.example` if needed. It does not require MySQL. Package downloads require an internet connection.

If setup reports a package installation error, use the explicit commands below to see the pip error directly:

```powershell
py -m venv .venv
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

You do not need to activate the virtual environment or change PowerShell execution policy; the commands call its Python executable directly. If your organization blocks package downloads, use its approved Python package mirror or ask its IT administrator for the approved installation method. Do not disable Windows security controls.

## 4. Configure storage (optional)

The app runs without MySQL and persists data locally in `data\sentinel_x.sqlite3`. No database server installation is needed for a single laptop.

To use an existing MySQL server instead, edit `.env` and set `DATABASE_HOST`, `DATABASE_PORT`, `DATABASE_NAME`, `DATABASE_USER`, and `DATABASE_PASSWORD` to credentials supplied by your database administrator. Keep `.env` private; do not share it.

## 5. Start the application

Start Sentinel-X from the project folder:

```powershell
.venv\Scripts\python.exe run.py
```

Wait for the startup message, then open [http://127.0.0.1:8000](http://127.0.0.1:8000). API health is available at [http://127.0.0.1:8000/api/health](http://127.0.0.1:8000/api/health). Keep the PowerShell window open while using the app. Press **Ctrl+C** there to stop it.

If port 8000 is already in use, start on another port:

```powershell
.venv\Scripts\python.exe run.py --port 8080
```

Then open `http://127.0.0.1:8080`.

## 6. Analyze sample or real traffic

Use the Traffic page to upload one of the files in `samples\`, or upload your own `.pcap`, `.pcapng`, or supported traffic `.csv` file. The app extracts flows, runs the configured detector, and stores results in SQLite/MySQL.

The sample captures are for checking that parsing and alert output work. They are not ground-truth datasets for measuring real-world detection accuracy. For meaningful accuracy measurements, train and evaluate with representative labeled traffic from the target network.

## 7. Retrain models (optional)

The shared copy includes the model metadata needed to start. To regenerate the built-in models from the project's synthetic training data:

```powershell
.venv\Scripts\python.exe scripts\train_models.py
```

To train/evaluate with a labeled CSV:

```powershell
.venv\Scripts\python.exe scripts\train_models.py --data path\to\labeled_flows.csv
```

Use labeled examples that represent the traffic you expect to analyze. Synthetic-data scores are not a substitute for evaluation on real, representative data.

## 8. Optional Windows live capture

Live capture is separate from uploaded PCAP analysis. On Windows it needs a packet-capture provider and the necessary operating-system permissions. This build can use Windows Packet Monitor (PktMon) when the app is run with capture rights; Npcap is another supported provider. Installing drivers or granting capture rights may require an administrator. If you do not have those rights, leave live capture off and analyze uploaded PCAP/PCAPNG files instead.

## Troubleshooting

- **`py` is not recognized:** reinstall Python with PATH enabled, then reopen PowerShell.
- **Package installation fails:** check internet/proxy access and use the organization's approved package mirror if one is required.
- **Port is in use:** select another port with `--port 8080`.
- **MySQL is unavailable:** confirm the app reports `SQLite Persistent Fallback`; this is a supported mode.
- **Live capture is unavailable:** check the status message for the missing provider or permission. PCAP uploads remain available.
- **The app cannot create its database or logs:** move the project to a folder your Windows account can write to.
