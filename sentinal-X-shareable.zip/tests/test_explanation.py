"""
Unit tests for Explanation and Feature Attribution Engine
"""

from app.explanation import explain_detection, get_top_contributing_features, generate_explanation_text


def test_top_contributing_features():
    sample_flow = {
        "dst_port": 80,
        "protocol": "TCP",
        "packet_count": 5000,
        "byte_count": 250000,
        "flow_duration": 0.5,
        "packet_rate": 10000.0,
        "byte_rate": 500000.0,
        "avg_packet_size": 50.0,
        "flag_syn": 1.0,
        "flag_ack": 0.0,
        "flag_fin": 0.0,
        "flag_rst": 0.0,
    }

    top_feats = get_top_contributing_features(sample_flow, "DDoS", top_k=5)
    assert len(top_feats) == 5
    # Should include high deviation features like packet_rate or byte_rate
    feature_names = [f["feature"] for f in top_feats]
    assert any("rate" in name or "packet" in name for name in feature_names)

    # Every item has required metadata
    for f in top_feats:
        assert "feature" in f
        assert "impact_score" in f
        assert "current_value" in f
        assert "baseline_median" in f


def test_explanation_text_generation():
    explanation, top_feats = explain_detection(
        flow_record={
            "src_ip": "10.0.0.99",
            "dst_ip": "192.168.1.1",
            "dst_port": 80,
            "protocol": "TCP",
            "packet_rate": 8000.0,
        },
        attack_type="DDoS",
        threat_score=92,
        severity="CRITICAL"
    )

    assert "10.0.0.99" in explanation
    assert "192.168.1.1:80" in explanation
    assert "92/100" in explanation
    assert "CRITICAL" in explanation
    assert len(top_feats) == 5
