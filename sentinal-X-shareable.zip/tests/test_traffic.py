"""
Tests for CSV parsing and traffic flow processing
"""

import io
from app.traffic import parse_csv_data, map_dataframe_columns


def test_standard_csv_parsing():
    csv_data = '''src_ip,dst_ip,src_port,dst_port,protocol,packet_count,byte_count,flow_duration,tcp_flags
192.168.1.10,10.0.0.1,50123,80,TCP,100,15000,2.5,"SYN,ACK"
192.168.1.20,10.0.0.2,50124,443,TCP,50,45000,1.2,ACK
192.168.1.30,10.0.0.3,50125,53,UDP,2,120,0.05,
'''
    records = parse_csv_data(csv_data.encode("utf-8"))
    assert len(records) == 3

    r1 = records[0]
    assert r1["src_ip"] == "192.168.1.10"
    assert r1["dst_port"] == 80
    assert r1["protocol"] == "TCP"
    assert r1["packet_count"] == 100
    assert r1["byte_count"] == 15000
    assert r1["flow_duration"] == 2.5
    assert r1["packet_rate"] > 0
    assert r1["avg_packet_size"] == 150.0


def test_aliased_and_missing_columns():
    # Test with Zeek / CIC-IDS style headers
    csv_data = """id.orig_h,id.resp_h,id.resp_p,proto,tot_pkts,tot_bytes,duration
172.16.0.4,192.168.10.50,22,tcp,85,6200,4.0
"""
    records = parse_csv_data(io.StringIO(csv_data))
    assert len(records) == 1

    r = records[0]
    assert r["src_ip"] == "172.16.0.4"
    assert r["dst_ip"] == "192.168.10.50"
    assert r["dst_port"] == 22
    assert r["protocol"] == "TCP"
    assert r["packet_count"] == 85
    assert r["byte_count"] == 6200
    assert r["flow_duration"] == 4.0
    assert r["packet_rate"] == round(85 / 4.0, 2)
    assert r["avg_packet_size"] == round(6200 / 85, 2)
