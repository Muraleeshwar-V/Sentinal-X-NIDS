import numpy as np
import pytest
from app.model_manager import ModelManager
from app.preprocessing import record_to_feature_vector, FEATURE_COLUMNS


@pytest.fixture
def mm():
    mgr = ModelManager()
    mgr.load_models()
    return mgr


def test_models_loaded(mm):
    assert mm.are_models_loaded() is True
    assert mm.classifier is not None
    assert mm.anomaly_detector is not None
    classes = mm.get_classes()
    assert "Normal" in classes
    assert "DDoS" in classes
    assert "PortScan" in classes


def test_random_forest_prediction(mm):
    # Construct normal HTTP flow
    normal_flow = {
        "dst_port": 80, "protocol": "TCP", "packet_count": 25,
        "byte_count": 16000, "flow_duration": 2.0, "packet_rate": 12.5,
        "byte_rate": 8000.0, "avg_packet_size": 640.0,
        "tcp_flags": "SYN,ACK"
    }
    vec = record_to_feature_vector(normal_flow).reshape(1, -1)
    pred = mm.classifier.predict(vec)[0]
    probs = mm.classifier.predict_proba(vec)[0]

    assert pred in mm.get_classes()
    assert len(probs) == len(mm.get_classes())
    assert 0.0 <= max(probs) <= 1.0


def test_isolation_forest_anomaly(mm):
    # Construct normal flow vs extreme outlier flow
    normal_flow = {
        "dst_port": 443, "protocol": "TCP", "packet_count": 20,
        "byte_count": 12000, "flow_duration": 1.5, "tcp_flags": "ACK"
    }
    extreme_flow = {
        "dst_port": 64221, "protocol": "TCP", "packet_count": 50000,
        "byte_count": 50000000, "flow_duration": 0.001, "packet_rate": 50000000.0,
        "byte_rate": 50000000000.0, "tcp_flags": "SYN"
    }

    v_norm = record_to_feature_vector(normal_flow).reshape(1, -1)
    v_extreme = record_to_feature_vector(extreme_flow).reshape(1, -1)

    # Decision function returns negative for anomalies, positive for inliers
    norm_score = mm.anomaly_detector.decision_function(v_norm)[0]
    extreme_score = mm.anomaly_detector.decision_function(v_extreme)[0]

    # Extreme outlier should have lower decision_function than normal
    assert extreme_score < norm_score


def test_feature_importances(mm):
    importances = mm.get_feature_importances()
    assert len(importances) == 12
    assert "packet_rate" in importances
    assert "dst_port" in importances
    assert sum(importances.values()) > 0.99
