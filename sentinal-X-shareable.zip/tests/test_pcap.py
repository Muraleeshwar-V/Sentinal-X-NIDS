"""
Tests for Scapy-based PCAP parsing and optional LiveCaptureManager
"""

from scapy.layers.inet import IP, TCP, UDP
from scapy.utils import wrpcap
from app.traffic import parse_pcap_data, live_capture_manager


def test_pcap_parsing(tmp_path):
    # Construct in-memory Scapy packets
    pkts = [
        IP(src="192.168.1.10", dst="10.0.0.1") / TCP(sport=54321, dport=80, flags="S"),
        IP(src="192.168.1.10", dst="10.0.0.1") / TCP(sport=54321, dport=80, flags="A"),
        IP(src="192.168.1.10", dst="10.0.0.1") / TCP(sport=54321, dport=80, flags="PA") / b"GET / HTTP/1.1\r\n",
        IP(src="192.168.1.20", dst="8.8.8.8") / UDP(sport=53000, dport=53) / b"dnsquery",
    ]

    pcap_file = tmp_path / "test_capture.pcap"
    wrpcap(str(pcap_file), pkts)

    # Test reading from Path
    flows = parse_pcap_data(pcap_file)
    assert len(flows) == 2

    tcp_flow = next(f for f in flows if f["protocol"] == "TCP")
    assert tcp_flow["src_ip"] == "192.168.1.10"
    assert tcp_flow["dst_ip"] == "10.0.0.1"
    assert tcp_flow["dst_port"] == 80
    assert tcp_flow["packet_count"] == 3
    assert tcp_flow["source_type"] == "PCAP"
    assert "SYN" in tcp_flow["tcp_flags"]
    assert "ACK" in tcp_flow["tcp_flags"]

    udp_flow = next(f for f in flows if f["protocol"] == "UDP")
    assert udp_flow["src_ip"] == "192.168.1.20"
    assert udp_flow["dst_ip"] == "8.8.8.8"
    assert udp_flow["dst_port"] == 53
    assert udp_flow["packet_count"] == 1

    # Test reading from raw bytes
    raw_bytes = pcap_file.read_bytes()
    flows_from_bytes = parse_pcap_data(raw_bytes)
    assert len(flows_from_bytes) == 2


def test_live_capture_manager_resilience():
    # Live capture should report status without crashing, even if unprivileged
    available, reason = live_capture_manager.is_available()
    assert isinstance(available, bool)
    assert isinstance(reason, str)

    # Calling start when unprivileged should return UNAVAILABLE status gracefully
    res = live_capture_manager.start_capture()
    assert "status" in res
    assert res["status"] in ("UNAVAILABLE", "STARTED", "ALREADY_RUNNING")

    # Stop should complete without error
    stop_res = live_capture_manager.stop_capture()
    assert stop_res["success"] is True
