"""
Tests for the False-Positive Reduction Filter (app/fp_filter.py).
Verifies all three layers: confidence gate, plausibility check, GBM meta-learner.
"""
import numpy as np
import pytest
from app.fp_filter import (
    fp_filter, apply_verdict_to_score,
    _compute_plausibility, CONFIDENCE_GATES,
    ANOMALY_CORROBORATION_THRESHOLD,
)
from app.preprocessing import record_to_feature_vector


def _make_feat(dst_port, packet_count, byte_count, flow_duration, tcp_flags="SYN,ACK"):
    return record_to_feature_vector({
        "dst_port": dst_port, "protocol": "TCP",
        "packet_count": packet_count, "byte_count": byte_count,
        "flow_duration": flow_duration, "tcp_flags": tcp_flags,
    })


# ── Layer 1: Confidence Gate ─────────────────────────────────────────────────

def test_confidence_gate_fails_low_conf_low_anom():
    """Low confidence + low anomaly score → LIKELY_BENIGN (no corroboration)."""
    feat = _make_feat(22, 35, 6300, 2.5)
    probas = np.zeros(5); probas[0] = 0.55
    verdict, fp_score, details = fp_filter.evaluate(
        "BruteForce", 0.55, 0.25, probas, feat, {}
    )
    assert verdict == "LIKELY_BENIGN"
    assert fp_score >= 0.70
    assert "layer1" in details
    assert "FAILED" in details["layer1"]


def test_confidence_gate_passes_with_anomaly_corroboration():
    """Low confidence but high anomaly score → gate corroborated, passes."""
    feat = _make_feat(22, 35, 6300, 2.5)
    probas = np.zeros(5); probas[0] = 0.55
    anom = ANOMALY_CORROBORATION_THRESHOLD + 0.10   # above threshold
    verdict, fp_score, details = fp_filter.evaluate(
        "BruteForce", 0.55, anom, probas, feat, {}
    )
    assert verdict in ("CONFIRMED_THREAT", "LIKELY_BENIGN")
    # corroborated means layer1 passed
    assert "FAILED" not in details["layer1"]


def test_confidence_gate_passes_high_confidence():
    """High confidence → passes gate regardless of anomaly."""
    feat = _make_feat(80, 1500, 180000, 0.3, "SYN")
    probas = np.zeros(5); probas[1] = 0.95
    verdict, fp_score, details = fp_filter.evaluate(
        "DDoS", 0.95, 0.10, probas, feat, {}
    )
    assert "FAILED" not in details["layer1"]


def test_normal_passthrough():
    """Normal-classified traffic always returns CONFIRMED_THREAT (not filtered)."""
    feat = _make_feat(443, 10, 6500, 1.0)
    probas = np.zeros(5); probas[3] = 0.99
    verdict, fp_score, details = fp_filter.evaluate(
        "Normal", 0.99, 0.05, probas, feat, {}
    )
    assert verdict == "CONFIRMED_THREAT"
    assert details.get("layer") == "passthrough"


# ── Layer 2: Plausibility ────────────────────────────────────────────────────

def test_ddos_plausibility_real_ddos():
    """Real DDoS-profile flow should have high plausibility."""
    feat = _make_feat(80, 1800, 216000, 0.4, "SYN")  # small avg_pkt_size, high rate
    p = _compute_plausibility("DDoS", feat)
    assert p >= 0.75, f"Expected high DDoS plausibility, got {p}"


def test_ddos_plausibility_large_packets():
    """Large avg_packet_size should reduce DDoS plausibility."""
    feat = _make_feat(443, 50, 325000, 2.0, "SYN,ACK,FIN")  # 6500B avg → not DDoS
    p = _compute_plausibility("DDoS", feat)
    assert p < 1.0, f"Expected reduced DDoS plausibility, got {p}"


def test_portscan_plausibility_real_scan():
    """Single-packet TCP SYN to random port → high PortScan plausibility."""
    feat = _make_feat(31337, 2, 120, 0.02, "SYN")
    p = _compute_plausibility("PortScan", feat)
    assert p >= 0.75


def test_portscan_plausibility_established_session():
    """Established session with many packets → low PortScan plausibility."""
    feat = _make_feat(80, 200, 130000, 5.0, "SYN,ACK,FIN")
    p = _compute_plausibility("PortScan", feat)
    assert p < 0.75


def test_c2_plausibility_real_beacon():
    """Long-duration low-rate flow → high Malware/C2 plausibility."""
    feat = _make_feat(4444, 15, 1500, 60.0, "SYN,ACK")
    p = _compute_plausibility("Malware/C2", feat)
    assert p >= 0.75


def test_c2_plausibility_short_flow():
    """Short-duration flow does not match C2 beacon pattern."""
    feat = _make_feat(4444, 15, 1500, 0.5, "SYN,ACK")
    p = _compute_plausibility("Malware/C2", feat)
    assert p < 1.0


# ── apply_verdict_to_score ────────────────────────────────────────────────────

def test_confirmed_threat_score_unchanged():
    """CONFIRMED_THREAT verdict leaves score/severity intact."""
    score, sev, is_alert = apply_verdict_to_score("CONFIRMED_THREAT", 75, "HIGH")
    assert score == 75
    assert sev == "HIGH"
    assert is_alert is True


def test_likely_benign_dampens_score():
    """LIKELY_BENIGN verdict reduces threat score by ~45%."""
    score, sev, is_alert = apply_verdict_to_score("LIKELY_BENIGN", 70, "HIGH")
    assert score < 70
    assert score == int(70 * 0.55)


def test_likely_benign_below_threshold_suppresses_alert():
    """LIKELY_BENIGN on a MEDIUM score should suppress the alert."""
    score, sev, is_alert = apply_verdict_to_score("LIKELY_BENIGN", 55, "MEDIUM")
    assert is_alert is False
    assert score < 55


def test_suppressed_verdict():
    """SUPPRESSED verdict reduces score to ~1/3 and clears alert."""
    score, sev, is_alert = apply_verdict_to_score("SUPPRESSED", 75, "HIGH")
    assert score == 25
    assert sev == "LOW"
    assert is_alert is False


def test_suppressed_low_score():
    """SUPPRESSED on a LOW score produces zero or near-zero score."""
    score, sev, is_alert = apply_verdict_to_score("SUPPRESSED", 20, "LOW")
    assert score <= 7
    assert is_alert is False


# ── Integration: full FP filter on detection output ─────────────────────────

def test_full_filter_high_confidence_ddos_fires():
    """Very high-confidence DDoS with matching features must remain an alert."""
    from app.detection import detection_engine
    flow = {
        "src_ip": "1.2.3.4", "dst_ip": "10.0.0.1",
        "dst_port": 80, "protocol": "TCP",
        "packet_count": 2000, "byte_count": 240000,
        "flow_duration": 0.3, "tcp_flags": "SYN",
    }
    result = detection_engine.analyze_flow(flow, persist=False)
    assert result["attack_type"] == "DDoS"
    assert result["is_alert"] is True
    assert result["fp_verdict"] == "CONFIRMED_THREAT"


def test_full_filter_low_confidence_brute_ssh_suppressed():
    """
    BruteForce-like SSH flow that the RF classifies with low confidence
    and no anomaly corroboration should be downgraded.
    We test directly via fp_filter rather than rely on RF's own classification.
    """
    ssh_feat = _make_feat(22, 35, 6300, 2.5, "SYN,ACK,FIN")
    probas = np.zeros(5); probas[0] = 0.54
    verdict, fp_score, _ = fp_filter.evaluate(
        "BruteForce", 0.54, 0.20, probas, ssh_feat, {}
    )
    assert verdict == "LIKELY_BENIGN"
    assert fp_score >= 0.70
    score, sev, is_alert = apply_verdict_to_score(verdict, 48, "MEDIUM")
    assert is_alert is False
