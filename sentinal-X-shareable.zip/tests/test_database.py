"""
Unit tests for Sentinel-X Database Manager
"""

import pytest
from app.database import DatabaseManager


@pytest.fixture
def db():
    return DatabaseManager()


def test_database_initialization(db):
    status = db.get_status()
    assert "connected" in status
    assert "mode" in status
    assert "database" in status
    assert status["database"] == "sentinel_x"


def test_insert_and_get_traffic(db):
    tid = db.insert_traffic_record({
        "src_ip": "10.0.0.5",
        "dst_ip": "10.0.0.1",
        "src_port": 12345,
        "dst_port": 443,
        "protocol": "TCP",
        "packet_count": 50,
        "byte_count": 5000,
        "flow_duration": 1.0,
        "packet_rate": 50.0,
        "byte_rate": 5000.0,
        "tcp_flags": "ACK",
        "avg_packet_size": 100.0,
        "source_type": "CSV"
    })
    assert tid > 0

    traffic = db.get_recent_traffic(limit=10)
    assert len(traffic) >= 1
    found = any(t.get("src_ip") == "10.0.0.5" for t in traffic)
    assert found


def test_insert_and_resolve_alert(db):
    aid = db.insert_alert({
        "attack_type": "DDoS",
        "threat_score": 90,
        "severity": "CRITICAL",
        "confidence": 0.98,
        "anomaly_score": 0.92,
        "explanation": "High packet volume flooding target",
        "top_features_json": [{"feature": "packet_rate", "importance": 0.5}],
        "src_ip": "192.168.1.50",
        "dst_ip": "192.168.1.1",
        "dst_port": 80,
        "protocol": "TCP"
    })
    assert aid > 0

    alert = db.get_alert_by_id(aid)
    assert alert is not None
    assert alert["attack_type"] == "DDoS"
    assert alert["severity"] == "CRITICAL"
    assert alert["status"] == "NEW"

    resolved = db.resolve_alert(aid)
    assert resolved is True

    alert_updated = db.get_alert_by_id(aid)
    assert alert_updated["status"] == "RESOLVED"
    assert alert_updated["resolved_at"] is not None


def test_drift_events_and_logs(db):
    did = db.insert_drift_event({
        "feature_name": "byte_rate",
        "baseline_value": 100.0,
        "current_value": 450.0,
        "drift_score": 0.35,
        "status": "MODERATE_DRIFT"
    })
    assert did > 0
    drift_list = db.get_drift_events(limit=5)
    assert len(drift_list) >= 1

    lid = db.insert_system_log("INFO", "Test", "Test log message")
    assert lid > 0
    logs = db.get_system_logs(limit=5)
    assert len(logs) >= 1
