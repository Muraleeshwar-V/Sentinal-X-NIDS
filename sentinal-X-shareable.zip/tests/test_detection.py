"""
Unit tests for End-to-End Detection Pipeline
"""

from app.detection import DetectionEngine
from app.database import db_manager


def test_analyze_normal_flow():
    engine = DetectionEngine()
    flow = {
        "src_ip": "192.168.1.15",
        "dst_ip": "142.250.190.46",
        "src_port": 52140,
        "dst_port": 443,
        "protocol": "TCP",
        "packet_count": 28,
        "byte_count": 18200,
        "flow_duration": 2.2,
        "packet_rate": 12.7,
        "byte_rate": 8272.0,
        "avg_packet_size": 650.0,
        "tcp_flags": "ACK"
    }

    result = engine.analyze_flow(flow, persist=False)
    assert "attack_type" in result
    assert "confidence" in result
    assert "anomaly_score" in result
    assert "threat_score" in result
    assert "severity" in result
    assert "explanation" in result
    assert "top_features" in result
    assert result["threat_score"] <= 59


def test_analyze_ddos_flow():
    engine = DetectionEngine()
    flood_flow = {
        "src_ip": "172.16.0.99",
        "dst_ip": "10.0.0.1",
        "src_port": 44321,
        "dst_port": 80,
        "protocol": "TCP",
        "packet_count": 2500,
        "byte_count": 250000,
        "flow_duration": 0.2,
        "packet_rate": 12500.0,
        "byte_rate": 1250000.0,
        "avg_packet_size": 100.0,
        "tcp_flags": "SYN"
    }

    result = engine.analyze_flow(flood_flow, persist=True)
    assert result["attack_type"] == "DDoS"
    assert result["severity"] in ("HIGH", "CRITICAL")
    assert result["threat_score"] >= 75
    assert result["is_alert"] is True
    assert result["traffic_id"] is not None
    assert result["alert_id"] is not None

    # Check alert was recorded in database
    alert = db_manager.get_alert_by_id(result["alert_id"])
    assert alert is not None
    assert alert["attack_type"] == "DDoS"
