"""
Tests for Data & Feature Drift Monitoring Engine
"""

import pytest
from app.drift import calculate_feature_drift, compute_population_stability_index
import numpy as np


def test_psi_calculation():
    # Identical distributions -> low PSI
    a = np.random.normal(50, 10, 1000)
    b = np.random.normal(50, 10, 1000)
    psi = compute_population_stability_index(a, b)
    assert psi < 0.25

    # Drastically shifted distributions -> high PSI
    c = np.random.normal(150, 10, 1000)
    psi_shifted = compute_population_stability_index(a, c)
    assert psi_shifted > psi


def test_feature_drift_evaluation():
    # Normal flows matching baseline
    normal_flows = [
        {
            "dst_port": 80, "protocol": "TCP", "packet_count": 25,
            "byte_count": 16000, "flow_duration": 2.0, "packet_rate": 12.5,
            "byte_rate": 8000.0, "avg_packet_size": 640.0, "tcp_flags": "ACK"
        }
        for _ in range(10)
    ]
    report = calculate_feature_drift(normal_flows, persist=False)
    assert "overall_status" in report
    assert "drift_events" in report
    assert len(report["drift_events"]) == 12

    # Heavily shifted flows (extreme flood)
    shifted_flows = [
        {
            "dst_port": 80, "protocol": "TCP", "packet_count": 50000,
            "byte_count": 50000000, "flow_duration": 0.05, "packet_rate": 1000000.0,
            "byte_rate": 1000000000.0, "avg_packet_size": 1000.0, "tcp_flags": "SYN"
        }
        for _ in range(10)
    ]
    report_shifted = calculate_feature_drift(shifted_flows, persist=True)
    assert report_shifted["overall_status"] in ("MODERATE_DRIFT", "SIGNIFICANT_DRIFT")
    assert report_shifted["max_drift_score"] > report["max_drift_score"]
