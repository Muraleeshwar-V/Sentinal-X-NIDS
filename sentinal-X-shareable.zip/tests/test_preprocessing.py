"""
Tests for preprocessing and feature engineering
"""

import numpy as np
from app.preprocessing import (
    FEATURE_COLUMNS,
    encode_protocol,
    parse_tcp_flags,
    record_to_feature_vector,
    records_to_feature_matrix
)


def test_protocol_and_flag_encoding():
    assert encode_protocol("TCP") == 6
    assert encode_protocol("UDP") == 17
    assert encode_protocol("ICMP") == 1
    assert encode_protocol("UNKNOWN") == 0

    syn, ack, fin, rst = parse_tcp_flags("SYN,ACK")
    assert syn == 1
    assert ack == 1
    assert fin == 0
    assert rst == 0

    syn, ack, fin, rst = parse_tcp_flags(0x12)  # SYN + ACK in TCP header mask
    assert syn == 1
    assert ack == 1


def test_record_to_feature_vector():
    record = {
        "src_ip": "10.0.0.1",
        "dst_ip": "10.0.0.2",
        "src_port": 1234,
        "dst_port": 80,
        "protocol": "TCP",
        "packet_count": 20,
        "byte_count": 2000,
        "flow_duration": 1.0,
        "packet_rate": 20.0,
        "byte_rate": 2000.0,
        "avg_packet_size": 100.0,
        "tcp_flags": "SYN"
    }
    vec = record_to_feature_vector(record)
    assert isinstance(vec, np.ndarray)
    assert len(vec) == len(FEATURE_COLUMNS)
    assert vec[0] == 80.0  # dst_port
    assert vec[1] == 6.0   # protocol_num
    assert vec[8] == 1.0   # flag_syn


def test_records_to_feature_matrix():
    records = [
        {"dst_port": 80, "protocol": "TCP", "packet_count": 10, "byte_count": 1000},
        {"dst_port": 443, "protocol": "TCP", "packet_count": 50, "byte_count": 50000},
    ]
    df = records_to_feature_matrix(records)
    assert len(df) == 2
    assert df.shape == (2, len(FEATURE_COLUMNS))
