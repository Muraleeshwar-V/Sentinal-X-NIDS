"""
Sentinel-X: Cross-Platform Verification Test Suite
Inspects the codebase for prohibited OS-specific assumptions, hardcoded paths,
Linux-specific service calls, and verifies pure cross-platform compliance.
"""

from pathlib import Path
import re
import pytest

# Project root
PROJECT_ROOT = Path(__file__).resolve().parent.parent
APP_DIR = PROJECT_ROOT / "app"


def test_no_hardcoded_paths_in_app():
    """Verify application code contains no hardcoded absolute paths."""
    forbidden_patterns = [
        re.compile(r"""['"]/home/"""),
        re.compile(r"""['"]/opt/"""),
        re.compile(r"""['"]/usr/"""),
        re.compile(r"""['"]/etc/"""),
        re.compile(r"""['"]/var/"""),
        re.compile(r"""['"][A-Za-z]:\\\\"""),
    ]

    py_files = list(APP_DIR.glob("**/*.py"))
    assert len(py_files) > 0, "No python files found in app/"

    for py_file in py_files:
        content = py_file.read_text(encoding="utf-8")
        for pattern in forbidden_patterns:
            matches = pattern.findall(content)
            assert not matches, f"Forbidden hardcoded path found in {py_file.name}: {matches}"


def test_no_os_specific_commands_in_app():
    """Verify application code contains no OS-specific service or privilege commands."""
    forbidden_commands = [
        "systemctl",
        "apt-get",
        "apt install",
        "brew services",
        "winget",
        "net start",
    ]

    py_files = list(APP_DIR.glob("**/*.py"))
    for py_file in py_files:
        content = py_file.read_text(encoding="utf-8")
        for cmd in forbidden_commands:
            assert cmd not in content, f"Forbidden OS command '{cmd}' found in {py_file.name}"


def test_pure_pathlib_usage():
    """Verify that configuration uses pathlib.Path throughout."""
    from app.config import PROJECT_ROOT, MODEL_DIR, DATA_DIR, LOG_DIR, STATIC_DIR, TEMPLATES_DIR
    for p in (PROJECT_ROOT, MODEL_DIR, DATA_DIR, LOG_DIR, STATIC_DIR, TEMPLATES_DIR):
        assert isinstance(p, Path)
        assert p.is_absolute()
