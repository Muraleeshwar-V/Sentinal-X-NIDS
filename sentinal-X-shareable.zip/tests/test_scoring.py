"""
Unit tests for Threat Scoring & Severity Logic
"""

import pytest
from app.scoring import calculate_threat_score, determine_severity, evaluate_threat


def test_severity_thresholds():
    # 0–29 LOW
    assert determine_severity(0) == "LOW"
    assert determine_severity(29) == "LOW"

    # 30–59 MEDIUM
    assert determine_severity(30) == "MEDIUM"
    assert determine_severity(59) == "MEDIUM"

    # 60–79 HIGH
    assert determine_severity(60) == "HIGH"
    assert determine_severity(79) == "HIGH"

    # 80–100 CRITICAL
    assert determine_severity(80) == "CRITICAL"
    assert determine_severity(100) == "CRITICAL"


def test_threat_score_calculation():
    # Normal traffic with low anomaly should have low score
    score_normal = calculate_threat_score("Normal", confidence=0.99, anomaly_score=0.05)
    assert score_normal <= 29
    assert determine_severity(score_normal) == "LOW"

    # High-confidence DDoS attack should produce CRITICAL severity
    score_ddos, sev_ddos = evaluate_threat("DDoS", confidence=0.98, anomaly_score=0.90)
    assert score_ddos >= 80
    assert sev_ddos == "CRITICAL"

    # PortScan with moderate confidence
    score_scan, sev_scan = evaluate_threat("PortScan", confidence=0.75, anomaly_score=0.60)
    assert 60 <= score_scan <= 85
    assert sev_scan in ("HIGH", "CRITICAL")
