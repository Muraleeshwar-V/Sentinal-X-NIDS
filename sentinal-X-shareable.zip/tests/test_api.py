"""
Unit and integration tests for Sentinel-X FastAPI endpoints
"""

import asyncio
from app.main import (
    health_check, system_status, get_dashboard_data, list_alerts,
    get_alert, resolve_alert_endpoint, analyze_traffic_payload,
    get_recent_traffic_endpoint, predict_single_flow, get_models_list,
    get_active_models_info, get_drift_report
)
from app.database import db_manager


def test_health_check_endpoint():
    res = asyncio.run(health_check())
    assert res["status"] == "ok"
    assert res["service"] == "Sentinel-X"
    assert "timestamp" in res


def test_system_status_endpoint():
    res = asyncio.run(system_status())
    assert res["status"] == "operational"
    assert "operating_system" in res
    assert "cpu" in res
    assert "python" in res
    assert "database" in res
    assert "live_capture" in res
    assert "models" in res
    assert "logs" in res


def test_dashboard_endpoint():
    data = asyncio.run(get_dashboard_data())
    assert "total_traffic" in data
    assert "total_alerts" in data
    assert "critical_count" in data
    assert "severity_distribution" in data
    assert "traffic_timeline" in data
    assert "live_capture" in data


def test_detection_and_alerts_endpoints():
    # 1. Direct prediction
    flow = {
        "src_ip": "10.10.10.10",
        "dst_ip": "192.168.1.1",
        "dst_port": 80,
        "protocol": "TCP",
        "packet_count": 3000,
        "byte_count": 300000,
        "flow_duration": 0.2,
        "packet_rate": 15000.0,
        "byte_rate": 1500000.0,
        "tcp_flags": "SYN"
    }
    pred = asyncio.run(predict_single_flow(flow))
    assert pred["attack_type"] == "DDoS"
    assert pred["is_alert"] is True
    assert pred["threat_score"] >= 60
    assert pred["severity"] in ("HIGH", "CRITICAL")

    # 2. Analyze payload with persistence
    analyze_res = asyncio.run(analyze_traffic_payload({"flows": [flow], "persist": True}))
    assert analyze_res["total"] == 1
    analyzed_item = analyze_res["results"][0]
    alert_id = analyzed_item["alert_id"]
    assert alert_id is not None

    # 3. Retrieve alerts
    alerts_list = asyncio.run(list_alerts(limit=10))
    assert alerts_list["count"] >= 1

    # 4. Retrieve single alert
    alert_details = asyncio.run(get_alert(alert_id))
    assert alert_details["id"] == alert_id
    assert alert_details["attack_type"] == "DDoS"
    assert "top_features" in alert_details

    # 5. Resolve alert
    resolve_res = asyncio.run(resolve_alert_endpoint(alert_id))
    assert resolve_res["success"] is True
    assert resolve_res["status"] == "RESOLVED"


def test_traffic_recent_endpoint():
    recent = asyncio.run(get_recent_traffic_endpoint(limit=10))
    assert "count" in recent
    assert "records" in recent


def test_models_endpoints():
    models_list = asyncio.run(get_models_list())
    assert "models" in models_list
    assert len(models_list["models"]) >= 2

    active_info = asyncio.run(get_active_models_info())
    assert "model_status" in active_info
    assert active_info["model_status"]["loaded"] is True
    assert "feature_importances" in active_info


def test_drift_endpoint():
    drift_data = asyncio.run(get_drift_report())
    assert "current_evaluation" in drift_data
    assert "historical_events" in drift_data
