-- ============================================================
-- SENTINEL-X DATABASE SCHEMA
-- Target: MySQL 8+
-- Database: sentinel_x
-- Application user: sentinel_user
-- ============================================================

CREATE DATABASE IF NOT EXISTS `sentinel_x`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE `sentinel_x`;

-- 1. MODELS TABLE
CREATE TABLE IF NOT EXISTS `models` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `version` VARCHAR(50) NOT NULL,
    `model_type` VARCHAR(50) NOT NULL,
    `file_path` VARCHAR(255) NOT NULL,
    `accuracy` FLOAT NULL,
    `f1_score` FLOAT NULL,
    `metrics_json` TEXT NULL,
    `is_active` BOOLEAN NOT NULL DEFAULT TRUE,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_models_active` (`is_active`),
    INDEX `idx_models_name_version` (`name`, `version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. TRAFFIC RECORDS TABLE
CREATE TABLE IF NOT EXISTS `traffic_records` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `src_ip` VARCHAR(45) NOT NULL,
    `dst_ip` VARCHAR(45) NOT NULL,
    `src_port` INT NOT NULL,
    `dst_port` INT NOT NULL,
    `protocol` VARCHAR(20) NOT NULL,
    `packet_count` BIGINT NOT NULL DEFAULT 0,
    `byte_count` BIGINT NOT NULL DEFAULT 0,
    `flow_duration` FLOAT NOT NULL DEFAULT 0.0,
    `packet_rate` FLOAT NOT NULL DEFAULT 0.0,
    `byte_rate` FLOAT NOT NULL DEFAULT 0.0,
    `tcp_flags` VARCHAR(50) NOT NULL DEFAULT '',
    `avg_packet_size` FLOAT NOT NULL DEFAULT 0.0,
    `source_type` VARCHAR(20) NOT NULL DEFAULT 'CSV',
    `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_traffic_time` (`timestamp`),
    INDEX `idx_traffic_ips` (`src_ip`, `dst_ip`),
    INDEX `idx_traffic_dst_port` (`dst_port`),
    INDEX `idx_traffic_source` (`source_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. ALERTS TABLE
CREATE TABLE IF NOT EXISTS `alerts` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `traffic_id` BIGINT NULL,
    `attack_type` VARCHAR(50) NOT NULL,
    `threat_score` INT NOT NULL,
    `severity` ENUM('LOW', 'MEDIUM', 'HIGH', 'CRITICAL') NOT NULL,
    `confidence` FLOAT NOT NULL DEFAULT 0.0,
    `anomaly_score` FLOAT NOT NULL DEFAULT 0.0,
    `status` ENUM('NEW', 'INVESTIGATING', 'RESOLVED', 'FALSE_POSITIVE') NOT NULL DEFAULT 'NEW',
    `explanation` TEXT NOT NULL,
    `top_features_json` TEXT NOT NULL,
    `src_ip` VARCHAR(45) NOT NULL,
    `dst_ip` VARCHAR(45) NOT NULL,
    `dst_port` INT NOT NULL,
    `protocol` VARCHAR(20) NOT NULL,
    `fp_verdict` VARCHAR(30) NOT NULL DEFAULT 'CONFIRMED_THREAT',
    `fp_score` FLOAT NOT NULL DEFAULT 0.0,
    `resolved_at` TIMESTAMP NULL DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_alert_traffic` FOREIGN KEY (`traffic_id`)
        REFERENCES `traffic_records` (`id`) ON DELETE SET NULL,
    INDEX `idx_alerts_severity` (`severity`),
    INDEX `idx_alerts_status` (`status`),
    INDEX `idx_alerts_created` (`created_at`),
    INDEX `idx_alerts_score` (`threat_score`),
    INDEX `idx_alerts_fp_verdict` (`fp_verdict`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. DRIFT EVENTS TABLE
CREATE TABLE IF NOT EXISTS `drift_events` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `feature_name` VARCHAR(100) NOT NULL,
    `baseline_value` FLOAT NOT NULL,
    `current_value` FLOAT NOT NULL,
    `drift_score` FLOAT NOT NULL,
    `status` VARCHAR(50) NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_drift_feature` (`feature_name`),
    INDEX `idx_drift_status` (`status`),
    INDEX `idx_drift_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. SYSTEM LOGS TABLE
CREATE TABLE IF NOT EXISTS `system_logs` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `level` VARCHAR(20) NOT NULL,
    `component` VARCHAR(50) NOT NULL,
    `message` TEXT NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_syslog_level` (`level`),
    INDEX `idx_syslog_time` (`created_at`),
    INDEX `idx_syslog_component` (`component`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
