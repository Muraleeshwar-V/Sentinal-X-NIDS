"""
Sentinel-X: Environment Detection Module
Cross-platform detection of OS, architecture, Python, pip, MySQL, Git, hardware resources,
and optional network capture capabilities.
Works on Windows, Linux, and macOS.
"""

import os
import sys
import platform
import shutil
import socket
import ctypes
from pathlib import Path


def detect_operating_system() -> dict:
    """Detect OS name, release, version, and family."""
    system = platform.system()
    return {
        "system": system,  # "Windows", "Linux", "Darwin"
        "release": platform.release(),
        "version": platform.version(),
        "is_windows": system == "Windows",
        "is_linux": system == "Linux",
        "is_macos": system == "Darwin",
    }


def detect_cpu_architecture() -> dict:
    """Detect CPU architecture and processor."""
    return {
        "machine": platform.machine(),
        "processor": platform.processor() or platform.machine(),
        "architecture": platform.architecture()[0],
    }


def detect_python() -> dict:
    """Detect Python executable, version, and verify requirement (>= 3.11)."""
    major, minor, micro = sys.version_info[:3]
    version_str = f"{major}.{minor}.{micro}"
    compatible = (major == 3 and minor >= 11) or (major > 3)
    return {
        "executable": sys.executable,
        "version": version_str,
        "major": major,
        "minor": minor,
        "micro": micro,
        "compatible": compatible,
    }


def detect_pip() -> dict:
    """Detect pip binary or module availability."""
    pip_bin = shutil.which("pip") or shutil.which("pip3")
    pip_module = False
    try:
        import pip  # noqa: F401
        pip_module = True
    except ImportError:
        # Check through subprocess or ensurepip
        pass

    return {
        "binary": pip_bin,
        "module_available": pip_module,
        "available": bool(pip_bin or pip_module),
    }


def detect_mysql() -> dict:
    """Detect MySQL client binary and port 3306 connectivity."""
    mysql_client = shutil.which("mysql")
    mysqld_bin = shutil.which("mysqld") or shutil.which("mariadb")

    # Check port 3306 connectivity
    port_open = False
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1.0)
            res = s.connect_ex(("127.0.0.1", 3306))
            port_open = (res == 0)
    except Exception:
        port_open = False

    return {
        "client_binary": mysql_client,
        "server_binary": mysqld_bin,
        "port_3306_open": port_open,
        "available": bool(port_open or mysql_client),
    }


def detect_git() -> dict:
    """Detect git binary."""
    git_bin = shutil.which("git")
    return {
        "binary": git_bin,
        "available": bool(git_bin),
    }


def detect_resources(target_path: Path | None = None) -> dict:
    """Detect available disk space and system memory."""
    target = target_path or Path.cwd()

    # Disk usage using standard library shutil
    disk = shutil.disk_usage(str(target))
    disk_total_gb = round(disk.total / (1024**3), 2)
    disk_free_gb = round(disk.free / (1024**3), 2)
    disk_percent = round(((disk.total - disk.free) / disk.total) * 100, 1)

    # Memory usage
    mem_total_gb = None
    mem_available_gb = None
    try:
        import psutil
        vmem = psutil.virtual_memory()
        mem_total_gb = round(vmem.total / (1024**3), 2)
        mem_available_gb = round(vmem.available / (1024**3), 2)
    except ImportError:
        # Fallback reading /proc/meminfo on Linux without psutil
        if platform.system() == "Linux" and os.path.exists("/proc/meminfo"):
            try:
                with open("/proc/meminfo", "r") as f:
                    lines = f.readlines()
                info = {}
                for line in lines:
                    parts = line.split(":")
                    if len(parts) == 2:
                        info[parts[0].strip()] = parts[1].strip()
                if "MemTotal" in info:
                    kb = int(info["MemTotal"].split()[0])
                    mem_total_gb = round(kb / (1024**2), 2)
                if "MemAvailable" in info:
                    kb = int(info["MemAvailable"].split()[0])
                    mem_available_gb = round(kb / (1024**2), 2)
            except Exception:
                pass

    return {
        "disk_total_gb": disk_total_gb,
        "disk_free_gb": disk_free_gb,
        "disk_percent_used": disk_percent,
        "memory_total_gb": mem_total_gb,
        "memory_available_gb": mem_available_gb,
    }


def check_port_availability(port: int, host: str = "127.0.0.1") -> bool:
    """Check if a local port is available for binding."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        try:
            s.bind((host, port))
            return True
        except OSError:
            return False


def detect_network_capture_capability() -> dict:
    """
    Detect whether live packet capture is likely available.
    Live capture requires elevated privileges (Administrator/root)
    or appropriate pcap drivers (Npcap on Windows, libpcap on Linux/macOS).
    """
    system = platform.system()
    can_capture = False
    reason = ""

    if system == "Windows":
        system_root = Path(os.environ.get("SystemRoot", "C:\\Windows"))
        npcap_dir = system_root / "System32" / "Npcap"
        winpcap_files = (
            system_root / "System32" / "wpcap.dll",
            system_root / "SysWOW64" / "wpcap.dll",
        )
        if npcap_dir.exists() or any(path.exists() for path in winpcap_files):
            can_capture = True
            reason = "Npcap / WinPcap driver detected."
            provider = "npcap"
        else:
            pktmon = shutil.which("pktmon.exe") or shutil.which("pktmon")
            if pktmon:
                try:
                    is_admin = bool(ctypes.windll.shell32.IsUserAnAdmin())
                except Exception:
                    is_admin = False
                if is_admin:
                    can_capture = True
                    provider = "pktmon"
                    reason = "Windows Packet Monitor is available; captured traffic is analyzed when capture stops."
                else:
                    can_capture = False
                    provider = "pktmon"
                    reason = "Windows Packet Monitor is installed, but this app lacks administrator rights to capture. CSV/PCAP upload works without elevation."
            else:
                can_capture = False
                provider = None
                reason = "No Windows packet capture provider found. Npcap or Windows Packet Monitor is required; CSV/PCAP upload remains available."
    elif system in ("Linux", "Darwin"):
        provider = "raw_socket"
        # Check raw socket access
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_RAW):
                can_capture = True
                reason = "Raw socket capture privileges available."
        except PermissionError:
            can_capture = False
            reason = "Raw socket requires elevated privileges (CAP_NET_RAW / sudo)."
        except Exception as e:
            can_capture = False
            reason = f"Raw socket check failed: {e}"

    return {
        "available": can_capture,
        "reason": reason,
        "provider": provider if system in ("Windows", "Linux", "Darwin") else None,
        "status": "AVAILABLE" if can_capture else "UNAVAILABLE",
    }


def detect_all(target_path: Path | None = None) -> dict:
    """Collect full environment telemetry."""
    return {
        "os": detect_operating_system(),
        "cpu": detect_cpu_architecture(),
        "python": detect_python(),
        "pip": detect_pip(),
        "mysql": detect_mysql(),
        "git": detect_git(),
        "resources": detect_resources(target_path),
        "network_capture": detect_network_capture_capability(),
        "ports": {
            "web_8000_free": check_port_availability(8000),
            "mysql_3306_open": detect_mysql()["port_3306_open"],
        }
    }


def print_environment_summary():
    """Pretty print detected environment."""
    env = detect_all()
    os_info = env["os"]
    cpu_info = env["cpu"]
    py_info = env["python"]
    pip_info = env["pip"]
    db_info = env["mysql"]
    git_info = env["git"]
    res_info = env["resources"]
    net_info = env["network_capture"]
    port_info = env["ports"]

    print("=" * 60)
    print("SENTINEL-X: ENVIRONMENT DETECTION REPORT")
    print("=" * 60)
    print(f"Operating System : {os_info['system']} ({os_info['release']})")
    print(f"CPU Architecture : {cpu_info['machine']} ({cpu_info['architecture']})")
    print(f"Python Version   : {py_info['version']} ({'Compatible' if py_info['compatible'] else 'INCOMPATIBLE - Needs >= 3.11'})")
    print(f"Python Binary    : {py_info['executable']}")
    print(f"Pip Available    : {'Yes' if pip_info['available'] else 'No (needs bootstrap)'}")
    print(f"Git Available    : {'Yes (' + git_info['binary'] + ')' if git_info['available'] else 'No'}")
    print(f"MySQL Service    : {'Running on port 3306' if db_info['port_3306_open'] else 'Not detected on port 3306'}")
    print(f"MySQL Client     : {db_info['client_binary'] or 'Not found in PATH'}")
    print(f"Free Disk Space  : {res_info['disk_free_gb']} GB free of {res_info['disk_total_gb']} GB")
    if res_info['memory_total_gb']:
        print(f"System Memory    : {res_info['memory_available_gb']} GB available of {res_info['memory_total_gb']} GB total")
    print(f"Port 8000 (API)  : {'Available' if port_info['web_8000_free'] else 'In use / blocked'}")
    print(f"Live Packet Cap  : {net_info['status']} - {net_info['reason']}")
    print("=" * 60)


if __name__ == "__main__":
    print_environment_summary()
