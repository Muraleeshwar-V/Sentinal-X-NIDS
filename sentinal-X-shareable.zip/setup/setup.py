"""
Sentinel-X: Autonomous Cross-Platform Setup Program
Handles Python venv creation, dependency installation, verification,
directory scaffolding, environment configuration, and MySQL checks across
Windows, Linux, and macOS.
"""

import sys
import os
import platform
import subprocess
import shutil
import urllib.request
from pathlib import Path

# Add setup dir to sys.path so we can import detect_environment
SETUP_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SETUP_DIR.parent
if str(SETUP_DIR) not in sys.path:
    sys.path.insert(0, str(SETUP_DIR))

import detect_environment


def get_venv_paths(venv_dir: Path) -> tuple[Path, Path]:
    """Get cross-platform paths for python and pip inside a venv."""
    if platform.system() == "Windows":
        python_bin = venv_dir / "Scripts" / "python.exe"
        pip_bin = venv_dir / "Scripts" / "pip.exe"
    else:
        python_bin = venv_dir / "bin" / "python"
        pip_bin = venv_dir / "bin" / "pip"
    return python_bin, pip_bin


def create_virtual_environment(venv_dir: Path) -> tuple[Path, Path]:
    """Create a virtual environment with pip support, handling systems where ensurepip is missing."""
    python_bin, pip_bin = get_venv_paths(venv_dir)

    if python_bin.exists() and pip_bin.exists():
        print(f"[+] Existing virtual environment detected at: {venv_dir}")
        return python_bin, pip_bin

    print(f"[*] Creating virtual environment at: {venv_dir}")
    try:
        # First attempt standard venv creation
        res = subprocess.run([sys.executable, "-m", "venv", str(venv_dir)], capture_output=True, text=True)
        if res.returncode == 0 and pip_bin.exists():
            print("[+] Virtual environment created successfully with standard venv.")
            return python_bin, pip_bin
    except Exception as e:
        print(f"[!] Standard venv creation encountered an error: {e}")

    # Fallback: create --without-pip and bootstrap using get-pip.py
    print("[*] Bootstrapping pip via get-pip.py (cross-platform fallback)...")
    try:
        if venv_dir.exists():
            shutil.rmtree(venv_dir)
        subprocess.run([sys.executable, "-m", "venv", str(venv_dir), "--without-pip"], check=True)

        get_pip_script = venv_dir / "get-pip.py"
        urllib.request.urlretrieve("https://bootstrap.pypa.io/get-pip.py", str(get_pip_script))
        subprocess.run([str(python_bin), str(get_pip_script), "--no-warn-script-location"], check=True)
        if get_pip_script.exists():
            get_pip_script.unlink()

        if pip_bin.exists():
            print("[+] Virtual environment and pip bootstrapped successfully.")
            return python_bin, pip_bin
        else:
            raise RuntimeError(f"Pip binary not found at expected location: {pip_bin}")
    except Exception as e:
        print(f"[!] Critical error during virtual environment creation: {e}")
        raise


def install_dependencies(pip_bin: Path, requirements_file: Path) -> bool:
    """Install Python packages using the venv pip."""
    print(f"[*] Installing dependencies from {requirements_file.name}...")
    try:
        # Upgrade pip quietly
        subprocess.run([str(pip_bin), "install", "--upgrade", "pip", "-q"], check=False)
        cmd = [str(pip_bin), "install", "-r", str(requirements_file)]
        res = subprocess.run(cmd, check=True)
        print("[+] Dependencies installed successfully.")
        return True
    except subprocess.CalledProcessError as e:
        print(f"[!] Error installing dependencies: {e}")
        return False


def verify_packages(python_bin: Path) -> dict:
    """Verify all critical Sentinel-X modules in the virtual environment."""
    modules_to_test = [
        ("fastapi", "FastAPI"),
        ("uvicorn", "Uvicorn"),
        ("numpy", "NumPy"),
        ("scapy", "Scapy"),
        ("mysql.connector", "MySQL Connector"),
        ("dotenv", "Python Dotenv"),
        ("joblib", "Joblib"),
        ("jinja2", "Jinja2"),
        ("multipart", "Python Multipart"),
        ("psutil", "Psutil"),
        ("pytest", "Pytest"),
    ]

    results = {}
    print("\n[*] Verifying installed dependencies:")
    for mod, display_name in modules_to_test:
        verify_code = f"import {mod}; print('OK')"
        res = subprocess.run([str(python_bin), "-c", verify_code], capture_output=True, text=True)
        is_ok = (res.returncode == 0 and "OK" in res.stdout)
        results[display_name] = is_ok
        status_symbol = "[+]" if is_ok else "[-]"
        print(f"    {status_symbol} {display_name:<18}: {'VERIFIED' if is_ok else 'FAILED'}")
        if not is_ok and res.stderr.strip():
            detail = res.stderr.strip().splitlines()[-1]
            print(f"      Details: {detail}")

    return results


def scaffold_directories():
    """Create project directories relative to project root."""
    dirs = [
        PROJECT_ROOT / "app",
        PROJECT_ROOT / "app" / "templates",
        PROJECT_ROOT / "app" / "static",
        PROJECT_ROOT / "app" / "static" / "css",
        PROJECT_ROOT / "app" / "static" / "js",
        PROJECT_ROOT / "models",
        PROJECT_ROOT / "data",
        PROJECT_ROOT / "data" / "uploads",
        PROJECT_ROOT / "data" / "processed",
        PROJECT_ROOT / "data" / "captures",
        PROJECT_ROOT / "database",
        PROJECT_ROOT / "tests",
        PROJECT_ROOT / "logs",
        PROJECT_ROOT / "scripts",
        PROJECT_ROOT / "setup",
        PROJECT_ROOT / "docs",
    ]
    print("\n[*] Scaffolding project directories...")
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
    print("[+] All project directories confirmed.")


def configure_env_file():
    """Create .env file from .env.example if missing."""
    env_file = PROJECT_ROOT / ".env"
    env_example = PROJECT_ROOT / ".env.example"

    example_content = (
        "# SENTINEL-X Configuration\n"
        "# Cross-platform network intrusion detection system\n\n"
        "# Database (MySQL 8+)\n"
        "DATABASE_HOST=localhost\n"
        "DATABASE_PORT=3306\n"
        "DATABASE_NAME=sentinel_x\n"
        "DATABASE_USER=sentinel_user\n"
        "DATABASE_PASSWORD=sentinel_password\n\n"
        "# API Server\n"
        "API_HOST=127.0.0.1\n"
        "API_PORT=8000\n\n"
        "# Storage Paths (Relative to project root or absolute)\n"
        "# Empty values default to standard project directories\n"
        "MODEL_DIRECTORY=\n"
        "DATA_DIRECTORY=\n"
        "LOG_DIRECTORY=\n\n"
        "# Security & Sensitivity\n"
        "ANOMALY_CONTAMINATION=0.05\n"
        "THREAT_SCORE_THRESHOLD=60\n"
    )

    if not env_example.exists():
        with open(env_example, "w", encoding="utf-8") as f:
            f.write(example_content)
        print("[+] Created .env.example")

    if not env_file.exists():
        with open(env_file, "w", encoding="utf-8") as f:
            f.write(example_content)
        print("[+] Created .env from template.")
    else:
        print("[+] Existing .env configuration confirmed.")


def print_mysql_instructions():
    """Display platform-specific instructions for installing and starting MySQL."""
    system = platform.system()
    print("\n" + "=" * 60)
    print("MYSQL INSTALLATION & SETUP GUIDANCE")
    print("=" * 60)
    print("MySQL 8+ is recommended for production persistence.")
    print("Sentinel-X will operate in resilient fallback mode until MySQL is configured.\n")

    if system == "Windows":
        print("Windows Options:")
        print("1. Winget (Command Prompt/PowerShell as Admin):")
        print("   winget install Oracle.MySQL")
        print("2. Official MSI Installer:")
        print("   Download from: https://dev.mysql.com/downloads/installer/")
        print("3. Start service:")
        print("   net start MySQL80")
    elif system == "Darwin":
        print("macOS Options (Homebrew):")
        print("1. Install:")
        print("   brew install mysql")
        print("2. Start service:")
        print("   brew services start mysql")
    else:
        print("Linux Options:")
        print("1. Debian / Ubuntu / Mint:")
        print("   sudo apt update && sudo apt install -y mysql-server")
        print("   sudo systemctl start mysql")
        print("2. Fedora / RHEL / CentOS:")
        print("   sudo dnf install -y mysql-server")
        print("   sudo systemctl start mysqld")
        print("3. Arch Linux:")
        print("   sudo pacman -S mariadb")
        print("   sudo mariadb-install-db --user=mysql --basedir=/usr --datadir=/var/lib/mysql")
        print("   sudo systemctl start mariadb")

    print("\nOnce MySQL is running, create the user and database:")
    print("   CREATE DATABASE sentinel_x;")
    print("   CREATE USER 'sentinel_user'@'localhost' IDENTIFIED BY 'sentinel_password';")
    print("   GRANT ALL PRIVILEGES ON sentinel_x.* TO 'sentinel_user'@'localhost';")
    print("   FLUSH PRIVILEGES;")
    print("=" * 60 + "\n")


def run_setup():
    """Main setup routine."""
    print("=" * 60)
    print("SENTINEL-X: AUTOMATIC CROSS-PLATFORM SETUP")
    print("=" * 60)

    # 1. Detect environment
    detect_environment.print_environment_summary()
    env = detect_environment.detect_all()

    if not env["python"]["compatible"]:
        print("[!] Incompatible Python version. Python 3.11+ required.")
        sys.exit(1)

    # 2. Scaffold directories
    scaffold_directories()

    # 3. Configure .env
    configure_env_file()

    # 4. Create virtual environment
    venv_dir = PROJECT_ROOT / ".venv"
    python_bin, pip_bin = create_virtual_environment(venv_dir)

    # 5. Install dependencies
    req_file = PROJECT_ROOT / "requirements.txt"
    installed = install_dependencies(pip_bin, req_file)
    if not installed:
        print("[!] Dependency installation failed. Resolve the reported error and rerun setup.")
        sys.exit(1)

    # 6. Verify packages
    pkg_results = verify_packages(python_bin)
    all_ok = all(pkg_results.values())
    if not all_ok:
        failed_pkgs = [k for k, v in pkg_results.items() if not v]
        print(f"[!] Verification failed for: {', '.join(failed_pkgs)}")
        print("[!] Resolve the reported package errors and rerun setup.")
        sys.exit(1)

    # 7. Check MySQL status
    if not env["mysql"]["port_3306_open"]:
        print_mysql_instructions()
    else:
        print("[+] MySQL service detected on port 3306.")

    print("=" * 60)
    print("SENTINEL-X SETUP COMPLETE")
    print("=" * 60)
    print(f"Python Environment : {python_bin}")
    print(f"Web Dashboard URL  : http://127.0.0.1:8000")
    print("Next steps:")
    print(f"  To train initial models : {python_bin} scripts/train_models.py")
    print(f"  To start the application: {python_bin} run.py")
    print("=" * 60)


if __name__ == "__main__":
    run_setup()
