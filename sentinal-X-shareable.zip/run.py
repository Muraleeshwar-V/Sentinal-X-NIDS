"""
Sentinel-X: Cross-Platform Application Launcher
================================================
Performs pre-flight environment checks, verifies models, checks database
connectivity, then starts the FastAPI/Uvicorn server.

Usage:
    python run.py
    python run.py --host 0.0.0.0 --port 8080

Works identically on Windows, Linux, and macOS when executed with:
    python run.py                   (uses .env defaults)
    python run.py --host 0.0.0.0    (bind all interfaces)
"""

from __future__ import annotations

import argparse
import logging
import os
import platform
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Ensure project root is on sys.path so all app.* imports resolve correctly
# regardless of the working directory the user launches from.
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Configure a minimal console logger before any app imports fire
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("sentinel_x.launcher")

BANNER = r"""
  ███████╗███████╗███╗   ██╗████████╗██╗███╗   ██╗███████╗██╗      ██╗  ██╗
  ██╔════╝██╔════╝████╗  ██║╚══██╔══╝██║████╗  ██║██╔════╝██║      ╚██╗██╔╝
  ███████╗█████╗  ██╔██╗ ██║   ██║   ██║██╔██╗ ██║█████╗  ██║       ╚███╔╝ 
  ╚════██║██╔══╝  ██║╚██╗██║   ██║   ██║██║╚██╗██║██╔══╝  ██║       ██╔██╗ 
  ███████║███████╗██║ ╚████║   ██║   ██║██║ ╚████║███████╗███████╗ ██╔╝ ██╗
  ╚══════╝╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚═╝╚═╝  ╚═══╝╚══════╝╚══════╝╚═╝  ╚═╝
             Cross-Platform Autonomous Intrusion Detection System
"""


def _separator(char: str = "─", width: int = 72) -> str:
    return char * width


def check_python_version() -> bool:
    """Require Python 3.11 or newer."""
    major, minor = sys.version_info[:2]
    if (major, minor) < (3, 11):
        logger.error(
            f"Python {major}.{minor} detected. Sentinel-X requires Python 3.11+. "
            "Please upgrade Python and try again."
        )
        return False
    logger.info(f"Python {major}.{minor}.{sys.version_info[2]} — OK")
    return True


def check_dependencies() -> bool:
    """Verify all critical Python packages are importable."""
    required = {
        "fastapi": "fastapi",
        "uvicorn": "uvicorn",
        "numpy": "numpy",
        "scapy": "scapy",
        "joblib": "joblib",
        "dotenv": "python-dotenv",
        "jinja2": "jinja2",
        "psutil": "psutil",
    }
    failures: list[str] = []
    for module_name, package_name in required.items():
        try:
            __import__(module_name)
        except Exception as exc:
            failures.append(f"{package_name} ({module_name}): {exc}")

    if failures:
        logger.error("Required Python packages failed to load:\n  - %s", "\n  - ".join(failures))
        if platform.system() == "Windows" and any("application control" in item.lower() or "code integrity" in item.lower() for item in failures):
            logger.error(
                "Windows Code Integrity blocked a package extension. Ask your device administrator to approve the required Windows package binaries; see Microsoft-Windows-CodeIntegrity/Operational event 3077."
            )
        return False
    logger.info("All required Python packages installed — OK")
    return True


def check_models() -> bool:
    """Verify trained model files exist; attempt training if absent."""
    from app.config import PREPROCESSOR_METADATA_PATH

    models_present = PREPROCESSOR_METADATA_PATH.exists()

    if models_present:
        logger.info("Trained models found — OK")
        return True

    logger.warning(
        "One or more model files missing. Attempting automatic training..."
    )
    try:
        # Add scripts/ to path so the import resolves
        scripts_dir = PROJECT_ROOT / "scripts"
        if str(scripts_dir) not in sys.path:
            sys.path.insert(0, str(scripts_dir))
        from scripts.train_models import train_and_save_models  # type: ignore
        train_and_save_models()
        logger.info("Models trained and saved successfully — OK")
        return True
    except Exception as exc:
        logger.error(
            "Automatic model training failed: %s\n"
            "Run manually: python scripts/train_models.py",
            exc,
        )
        return False


def check_database() -> None:
    """
    Attempt MySQL connection. The application runs regardless of result
    (DatabaseManager has a built-in resilient fallback), so this is
    informational only.
    """
    try:
        from app.database import db_manager
        status = db_manager.get_status()
        if status["connected"]:
            logger.info(
                "MySQL connected — database '%s' at %s:%s — OK",
                status["database"],
                status["host"],
                status["port"],
            )
        else:
            if status.get("persistent"):
                logger.warning(
                    "MySQL unavailable (%s). Persistent local storage active at %s. "
                    "Set DATABASE_* variables in .env to enable MySQL.",
                    status.get("last_error", "connection refused"),
                    status.get("fallback_path", "SQLite fallback"),
                )
            else:
                logger.warning(
                    "MySQL unavailable (%s). In-memory fallback active; local persistence could not be initialized.",
                    status.get("last_error", "connection refused"),
                )
    except Exception as exc:
        logger.warning("Database check failed (%s). Fallback mode active.", exc)


def load_env_config() -> tuple[str, int]:
    """
    Load API host/port from .env (via app.config) or defaults.
    Returns (host, port) so the caller can pass them to uvicorn.
    """
    try:
        from app.config import API_HOST, API_PORT
        return API_HOST, API_PORT
    except Exception:
        return "127.0.0.1", 8000


def print_startup_info(host: str, port: int) -> None:
    """Print a formatted startup summary to the console."""
    os_name = platform.system()
    arch = platform.machine()

    print(_separator())
    print(f"  Operating System : {os_name} ({arch})")
    print(f"  Python           : {sys.version.split()[0]}")
    print(f"  Dashboard URL    : http://{host}:{port}")
    print(f"  API Docs         : http://{host}:{port}/docs")
    print(f"  Stop server      : Ctrl+C")
    print(_separator())


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Sentinel-X Intrusion Detection System Launcher",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument(
        "--host",
        default=None,
        help="Bind host override (default: from .env / 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=None,
        help="Bind port override (default: from .env / 8000)",
    )
    parser.add_argument(
        "--reload",
        action="store_true",
        help="Enable Uvicorn auto-reload (development only)",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="Number of Uvicorn worker processes (default: 1)",
    )
    return parser.parse_args()


def main() -> None:
    print(BANNER)
    print(_separator("═"))

    args = parse_args()

    # ── Pre-flight checks ──────────────────────────────────────────
    logger.info("Running pre-flight checks...")

    if not check_python_version():
        sys.exit(1)

    if not check_dependencies():
        sys.exit(1)

    if not check_models():
        # Training failure is fatal — predictions would be meaningless
        sys.exit(1)

    check_database()          # non-fatal; fallback handles missing MySQL

    # ── Resolve host / port ────────────────────────────────────────
    env_host, env_port = load_env_config()
    host = args.host if args.host is not None else env_host
    port = args.port if args.port is not None else env_port

    print_startup_info(host, port)

    # ── Launch Uvicorn ─────────────────────────────────────────────
    try:
        import uvicorn
        logger.info("Starting Sentinel-X on http://%s:%d ...", host, port)
        uvicorn.run(
            "app.main:app",
            host=host,
            port=port,
            reload=args.reload,
            workers=1 if args.reload else args.workers,
            log_level="info",
        )
    except KeyboardInterrupt:
        logger.info("Sentinel-X shut down by user (Ctrl+C).")
    except Exception as exc:
        logger.error("Failed to start Uvicorn: %s", exc)
        sys.exit(1)


if __name__ == "__main__":
    main()
