# Sentinel-X — Cross-Platform Intrusion Detection System

Sentinel-X is an autonomous, minimal-footprint Network Intrusion Detection System (NIDS) that
classifies network traffic, detects anomalies, calculates threat scores, generates plain-English
explanations, monitors feature drift, persists alerts to MySQL, and serves a live cyber-operations
dashboard — all from a single Python process with no Node.js, no Docker, and no OS-specific
assumptions.

```
INPUT (CSV / PCAP / Live)
  → Feature Extraction
    → Preprocessing
      → Flow Classifier (attack classification)
        → Baseline Deviation Scorer (anomaly detection)
          → Threat Scoring (0–100)
            → Explanation (feature importance)
              → MySQL / Fallback Storage
                → Web Dashboard
```

---

## Supported Operating Systems

| OS | Versions | Notes |
|---|---|---|
| **Linux** | Any modern distribution | Full support including optional live capture (requires `CAP_NET_RAW`) |
| **Windows** | 10, 11 | Full support; live capture requires Windows Packet Monitor or [Npcap](https://npcap.com), plus capture permissions |
| **macOS** | Monterey 12+ | Full support; live capture requires `sudo` or TCC permission |

---

## Requirements

| Dependency | Version | Purpose |
|---|---|---|
| Python | 3.11+ | Runtime |
| pip | any | Package installation |
| MySQL | 8.0+ | Persistent storage (optional — graceful fallback included) |
| Git | any | Source control |

Python packages are installed automatically by the setup script or `pip install -r requirements.txt`.
No Node.js, npm, React, or Docker is required.

---

## Automatic Setup

The setup script detects your OS, creates a virtual environment, installs all Python dependencies,
creates the database schema, and verifies the installation end-to-end.

```bash
python setup/setup.py
```

Once setup completes, train the ML models (only required once):

```bash
# Linux / macOS
.venv/bin/python scripts/train_models.py

# Windows
.venv\Scripts\python scripts\train_models.py
```

Then start the application:

```bash
# Linux / macOS
.venv/bin/python run.py

# Windows
.venv\Scripts\python run.py
```

Open the dashboard at **http://127.0.0.1:8000**

---

## Platform-Specific Setup

### Windows Setup

1. Install **Python 3.11+** from https://python.org — tick "Add Python to PATH".
2. Install **MySQL 8** from https://dev.mysql.com/downloads/installer/ and note the root password.
3. Live capture is optional. Windows Packet Monitor is built in on supported Windows versions; Npcap is also supported. Starting a capture may require administrator rights. PCAP uploads work without live capture permissions.
4. Open **Command Prompt** or **PowerShell** in the project folder and run:

```powershell
python setup\setup.py
.venv\Scripts\python scripts\train_models.py
.venv\Scripts\python run.py
```

### Linux Setup

1. Install Python 3.11+ via your distribution's package manager, e.g.:
   - Debian/Ubuntu: `sudo apt install python3 python3-pip python3-venv`
   - Fedora: `sudo dnf install python3 python3-pip`
   - Arch: `sudo pacman -S python python-pip`
2. Install MySQL 8: `sudo apt install mysql-server` (or equivalent).
3. Run setup:

```bash
python3 setup/setup.py
.venv/bin/python scripts/train_models.py
.venv/bin/python run.py
```

> **Live capture on Linux** requires either running as root or granting the `CAP_NET_RAW` capability:
> `sudo setcap cap_net_raw+eip .venv/bin/python`

### macOS Setup

1. Install Python 3.11+ via [Homebrew](https://brew.sh): `brew install python@3.12`
2. Install MySQL 8: `brew install mysql && brew services start mysql`
3. Run setup:

```bash
python3 setup/setup.py
.venv/bin/python scripts/train_models.py
.venv/bin/python run.py
```

> **Live capture on macOS** requires running with `sudo` or granting Full Disk Access to Terminal
> in System Settings → Privacy & Security.

---

## MySQL Setup

Sentinel-X uses a dedicated database user. Run these SQL commands as the MySQL root user
(replace `your_password` with a strong password):

```sql
CREATE DATABASE IF NOT EXISTS sentinel_x DEFAULT CHARACTER SET utf8mb4;
CREATE USER IF NOT EXISTS 'sentinel_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON sentinel_x.* TO 'sentinel_user'@'localhost';
FLUSH PRIVILEGES;
```

Then set the credentials in `.env`:

```
DATABASE_HOST=localhost
DATABASE_PORT=3306
DATABASE_NAME=sentinel_x
DATABASE_USER=sentinel_user
DATABASE_PASSWORD=your_password
```

> **Without MySQL:** Sentinel-X automatically stores alerts, traffic, models, drift events, and logs
> in a local SQLite database at `data/sentinel_x.sqlite3`. Data persists across restarts without a
> separate database installation. Set `DATABASE_SQLITE_PATH` to move this file.

---

## Application Startup

`run.py` performs a complete pre-flight sequence before handing off to Uvicorn:

1. Checks Python ≥ 3.11
2. Verifies all required packages are importable
3. Verifies trained model files exist (auto-trains if absent)
4. Checks MySQL connectivity (non-fatal — fallback activated if unavailable)
5. Starts Uvicorn on the configured host/port

```bash
# Default startup (127.0.0.1:8000)
python run.py

# Bind to all interfaces
python run.py --host 0.0.0.0

# Custom port
python run.py --port 9000

# Development auto-reload
python run.py --reload

# Help
python run.py --help
```

---

## Model Training

The trainer builds a NumPy-only supervised classifier and normal-traffic anomaly baseline. It
evaluates the learned classifier against the existing rules on a stratified held-out split and
keeps whichever scores better on a combined accuracy and balanced-accuracy measure:

| Model | Algorithm | Purpose |
|---|---|---|
| Built-in NumPy flow classifier | Trained softmax model or calibrated flow rules | Multi-class attack classification |
| Built-in NumPy deviation scorer | Normal-baseline distance | Anomaly scoring |
| `preprocessor_meta.joblib` | Classifier weights, held-out metrics, baseline | Inference, drift, and anomaly calibration |

Traffic classes: `Normal`, `DDoS`, `PortScan`, `BruteForce`, `Malware/C2`

```bash
# Train (or retrain) models
python scripts/train_models.py

# Train and evaluate from a labeled flow CSV
python scripts/train_models.py --data path/to/labeled_flows.csv

# Or trigger retraining via API
curl -X POST http://127.0.0.1:8000/api/models/train

# Upload a labeled CSV for supervised training and held-out evaluation
curl -X POST http://127.0.0.1:8000/api/models/train/labeled -F "file=@path/to/labeled_flows.csv"
```

Labeled CSV files need a `label`, `attack_type`, `class`, `target`, or `category` column. Include
Normal/Benign flows and at least five examples per class. Supported labels include common spellings
of Normal/Benign, DDoS/DoS, PortScan, BruteForce, and Malware/C2/Bot.
The Models page also accepts a labeled CSV and displays held-out accuracy, balanced accuracy, and
per-class precision/recall/F1. Synthetic-data metrics are useful for regression checks, but do not
replace evaluation on representative traffic from your network.

---

## CSV Usage

Upload any network flow CSV through the dashboard Traffic page or via the API.

Supported column naming conventions (auto-detected and mapped):

| Standard Field | Accepted Aliases |
|---|---|
| `src_ip` | `source_ip`, `srcip`, `id.orig_h`, `ip_src` |
| `dst_ip` | `dest_ip`, `destination_ip`, `id.resp_h`, `ip_dst` |
| `src_port` | `source_port`, `srcport`, `id.orig_p`, `sport` |
| `dst_port` | `dest_port`, `destination_port`, `id.resp_p`, `dport` |
| `protocol` | `proto`, `proto_name`, `transport_protocol` |
| `packet_count` | `tot_fwd_pkts`, `total_packets`, `packets`, `pkt_count` |
| `byte_count` | `totlen_fwd_pkts`, `total_bytes`, `bytes`, `flow_bytes` |
| `flow_duration` | `duration`, `flow_dur` |
| `packet_rate` | `flow_pkts_s`, `flow_packets_per_sec` |
| `byte_rate` | `flow_byts_s`, `flow_bytes_per_sec` |
| `tcp_flags` | `flags`, `flag`, `tcp_flag` |
| `avg_packet_size` | `pkt_size_avg`, `mean_packet_size` |

Derived fields (`packet_rate`, `byte_rate`, `avg_packet_size`) are auto-calculated if absent.

**Via API:**

```bash
curl -X POST http://127.0.0.1:8000/api/traffic/upload \
  -F "file=@/path/to/traffic.csv"
```

**Via JSON batch:**

```bash
curl -X POST http://127.0.0.1:8000/api/traffic/analyze \
  -H "Content-Type: application/json" \
  -d '{"flows": [{"src_ip":"192.168.1.1","dst_ip":"10.0.0.1","dst_port":80,"protocol":"TCP","packet_count":10,"byte_count":1500,"flow_duration":1.2}]}'
```

---

## PCAP Usage

Upload PCAP, PCAPNG, or CAP files through the dashboard or API. Scapy reconstructs 5-tuple
network flows directly — no tcpdump, tshark, or Wireshark required.

```bash
curl -X POST http://127.0.0.1:8000/api/traffic/upload \
  -F "file=@/path/to/capture.pcap"
```

Sentinel-X extracts: source/destination IP and port, protocol, packet count, byte count,
flow duration, packet rate, byte rate, TCP flags, and average packet size per flow.

---

## Live Capture Requirements

Live capture is an **optional** feature. The rest of the application works fully without it.

| Platform | Requirement |
|---|---|
| Linux | `CAP_NET_RAW` capability or run as root |
| Windows | [Npcap](https://npcap.com) installed (WinPcap API-compatible mode) |
| macOS | `sudo` or Terminal granted Full Disk Access in System Privacy settings |

The dashboard and `/api/system/status` always display the live capture status:
`AVAILABLE` or `UNAVAILABLE` with the specific reason.

**Start/stop via API:**

```bash
curl -X POST http://127.0.0.1:8000/api/traffic/capture/start
curl -X POST http://127.0.0.1:8000/api/traffic/capture/stop
curl      http://127.0.0.1:8000/api/traffic/capture/status
```

---

## API Reference

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/health` | Service health check |
| GET | `/api/system/status` | OS, hardware, DB, model, and capture telemetry |
| GET | `/api/dashboard` | Aggregated metrics and chart data |
| GET | `/api/alerts` | List alerts (filters: `severity`, `status`, `limit`) |
| GET | `/api/alerts/{id}` | Full alert details with explanation and feature breakdown |
| POST | `/api/alerts/{id}/resolve` | Mark alert as resolved |
| POST | `/api/traffic/upload` | Upload CSV or PCAP file |
| POST | `/api/traffic/analyze` | Analyze JSON flow batch |
| GET | `/api/traffic/recent` | Recent traffic flow records |
| POST | `/api/detection/predict` | Single-flow inference |
| GET | `/api/models` | Registered model list |
| GET | `/api/models/active` | Active model metrics and feature importances |
| POST | `/api/models/train` | Trigger background model retraining |
| POST | `/api/models/train/labeled` | Upload labeled flow CSV and evaluate on a held-out split |
| GET | `/api/drift` | Current and historical drift evaluation |
| POST | `/api/traffic/capture/start` | Start live packet capture |
| POST | `/api/traffic/capture/stop` | Stop live packet capture |
| GET | `/api/traffic/capture/status` | Live capture session state |

Interactive API docs: **http://127.0.0.1:8000/docs**

---

## Testing

```bash
# Run full test suite
python -m pytest tests/ -v

# Run a specific module
python -m pytest tests/test_detection.py -v

# Run with coverage (requires pytest-cov)
python -m pytest tests/ --cov=app --cov-report=term-missing
```

**Test coverage:**

| File | Tests | Covers |
|---|---|---|
| `test_database.py` | 4 | DB init, traffic insert/get, alert insert/resolve, drift events, logs |
| `test_api.py` | 7 | All API endpoints end-to-end |
| `test_traffic.py` | 2 | CSV parsing, aliased headers, derived fields |
| `test_preprocessing.py` | 3 | Protocol encoding, flag parsing, feature vector shape |
| `test_ml_models.py` | 4 | Model loading, flow prediction, anomaly scoring, feature weights |
| `test_detection.py` | 2 | Normal flow pipeline, DDoS detection and alert persistence |
| `test_scoring.py` | 2 | Severity thresholds at all boundaries, score formula |
| `test_explanation.py` | 2 | Feature attribution, narrative text generation |
| `test_drift.py` | 2 | PSI formula, drift classification |
| `test_pcap.py` | 2 | PCAP flow reconstruction, live capture manager resilience |
| `test_cross_platform.py` | 3 | No hardcoded paths, no OS-specific commands, pathlib usage |

---

## Troubleshooting

**Application fails to start — module not found**
Run `python setup/setup.py` to reinstall dependencies. Ensure the virtual environment is
activated or use the full `.venv/bin/python` / `.venv\Scripts\python` path.

**Models not found on startup**
`run.py` will attempt automatic training. If that fails, run `python scripts/train_models.py`
manually before starting.

**MySQL connection refused**
Check that MySQL is running and the credentials in `.env` are correct. Sentinel-X continues in
resilient in-memory fallback mode if MySQL is unreachable — no data is lost during a session,
but it will not persist across restarts.

**Live capture shows UNAVAILABLE**
This is expected on most environments without elevated permissions. CSV and PCAP processing are
unaffected. To enable live capture, see the Live Capture Requirements section above.

**Port 8000 already in use**
Use `python run.py --port 9000` (or any free port). Update your browser URL accordingly.

**Tests fail with import errors**
Ensure you are running pytest from the project root with the virtual environment active:
`python -m pytest tests/ -v` (not `pytest tests/ -v` with the system Python).

---

## Project Structure

```
sentinal-X/
├── app/
│   ├── main.py              # FastAPI application, all API + frontend routes
│   ├── config.py            # Cross-platform configuration (pathlib, .env)
│   ├── database.py          # MySQL + in-memory fallback data layer
│   ├── detection.py         # Unified detection pipeline coordinator
│   ├── anomaly.py           # Baseline deviation scoring & calibration
│   ├── scoring.py           # 0–100 threat score + severity classification
│   ├── explanation.py       # Feature importance explanation engine
│   ├── drift.py             # PSI-based feature drift monitoring
│   ├── traffic.py           # CSV parser, PCAP reader, live capture manager
│   ├── preprocessing.py     # Feature extraction & normalisation
│   ├── model_manager.py     # Model loading, metadata, feature importances
│   ├── lightweight_models.py # NumPy inference models for classification and anomaly scoring
│   ├── training.py          # Softmax training and held-out evaluation metrics
│   ├── templates/           # Jinja2 HTML templates (6 pages)
│   └── static/
│       ├── css/style.css    # Dark cyber-ops dashboard theme
│       └── js/              # Vanilla JS modules (dashboard, alerts, traffic, models)
│
├── database/
│   └── schema.sql           # MySQL 8+ schema (5 tables)
│
├── models/                  # Trained .joblib model files (generated by train_models.py)
│
├── data/
│   ├── uploads/             # Uploaded CSV/PCAP files
│   ├── processed/           # Intermediate processing artifacts
│   └── captures/            # Live capture outputs
│
├── scripts/
│   └── train_models.py      # Synthetic or labeled CSV training + evaluation
│
├── setup/
│   ├── setup.py             # Cross-platform automated installer
│   ├── detect_environment.py # OS/CPU/Python/MySQL/Git/disk/memory detection
│   └── requirements.txt     # Mirror of root requirements.txt
│
├── tests/                   # pytest test suite (33 tests)
├── logs/                    # Application log output
├── docs/
│   └── DEVELOPMENT_PROGRESS.md
│
├── run.py                   # Cross-platform application launcher
├── requirements.txt         # Python package dependencies
├── .env.example             # Configuration template
├── .env                     # Local configuration (not committed)
├── pytest.ini               # Test runner configuration
└── README.md                # This file
```

---

## Technology Stack

| Component | Technology | Version |
|---|---|---|
| Backend | FastAPI + Uvicorn | ≥ 0.110 / ≥ 0.28 |
| Frontend | HTML + CSS + Vanilla JS | — |
| Charts | Chart.js (bundled, offline) | 4.x |
| Templates | Jinja2 | ≥ 3.1 |
| Classifier | NumPy-based multi-signal flow rules | Built-in |
| Anomaly Detector | NumPy baseline deviation scorer | Built-in |
| Data Processing | NumPy + Python standard library | ≥ 1.26 |
| PCAP/Live Capture | Scapy | ≥ 2.5 |
| Model Serialisation | joblib | ≥ 1.3 |
| Database | MySQL 8+ via mysql-connector-python | ≥ 8.3 |
| Configuration | python-dotenv | ≥ 1.0 |
| System Info | psutil | ≥ 5.9 |
| Testing | pytest | ≥ 8.0 |

---

## Dashboard Pages

| URL | Page | Description |
|---|---|---|
| `/` | Dashboard | Live metrics, 4 Chart.js charts, recent high-priority alerts |
| `/alerts` | Alerts | Filterable triage console with severity/status filters |
| `/alerts/{id}` | Alert Details | Forensic view: explanation, feature attribution bars, flow telemetry |
| `/traffic` | Traffic | CSV/PCAP upload, live capture controls, ingested flow table |
| `/models` | Models | Model cards, accuracy metrics, feature importance chart, training history |
| `/system` | System | OS/CPU/memory/disk stats, MySQL status, audit log |

---

## Threat Scoring

| Score | Severity | Colour |
|---|---|---|
| 0 – 29 | LOW | Green |
| 30 – 59 | MEDIUM | Yellow |
| 60 – 79 | HIGH | Orange |
| 80 – 100 | CRITICAL | Red |

Score formula combines classifier confidence and calibrated baseline anomaly probability with
per-attack-type base penalties. Implementation: `app/scoring.py`.

---

## License

This project is provided for educational and research purposes.
